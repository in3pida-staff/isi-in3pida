<?php
/**
 * Plugin Name: Eletta
 * Description: Posiziona il tuo sito nelle ricerche AI. Gestione FAQ, Schema.org e AI Layer per hotel e strutture ricettive.
 * Version: 2.5.53
 * Author: in3pida
 * Text Domain: in3pida-sito-intelligente
 */

if (!defined('ABSPATH')) exit;

// Fix SSL detection dietro proxy/CDN (SiteGround, Cloudflare, ecc.)
if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
} elseif (!empty($_SERVER['HTTP_CF_VISITOR'])) {
    $cf = json_decode($_SERVER['HTTP_CF_VISITOR'], true);
    if (!empty($cf['scheme']) && $cf['scheme'] === 'https') $_SERVER['HTTPS'] = 'on';
}

final class In3pida_FAQ_Plugin {
    const VERSION = '2.5.53';
    const CPT = 'in3pida_faq';
    const OPTION = 'in3pida_faq_options';
    const PAGE_OPTION = 'in3pida_faq_page_id';
    const SCHEMA_OPTION = 'in3pida_schemaorg_settings';
    const CC_CHANNELS_OPTION = 'in3pida_content_consistency_channels';
    const CC_REPORT_OPTION = 'in3pida_content_consistency_report';
    const CC_LAST_SCAN_OPTION = 'in3pida_content_consistency_last_scan';
    const ACCESS_HASH_OPTION = 'in3pida_si_access_hash';
    const ACCESS_TOKEN_META = 'in3pida_si_access_token';
    const DEFAULT_ACCESS_CODE = 'in3pidaAi202-?!ihdmab';
    const LLM_OPTION = 'in3pida_llm_ready_settings';
    const LLM_QUALITY_OPTION = 'in3pida_llm_quality_state';
    const LLM_CACHE_TRANSIENT = 'in3pida_llm_ready_layer_cache';
    const CHUNKS_TRANSIENT = 'in3pida_chunks_cache';
    const ENTITY_GRAPH_OPTION = 'in3pida_entity_graph_settings';
    const ENTITY_GRAPH_TRANSIENT = 'in3pida_entity_graph_cache';
    const CITATION_TRANSIENT = 'in3pida_citation_cache';
    const ISI_SUPABASE_URL      = 'https://yyauvoqjdzrbmebeafit.supabase.co';
    const ISI_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl5YXV2b3FqZHpyYm1lYmVhZml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk3OTM2MDAsImV4cCI6MjA5NTM2OTYwMH0.M6kD56PEO_UcJ68Vjquo03vuORjv62MflIzGLzYKN9w';
    const ISI_SITE_ID_OPTION = 'in3pida_isi_site_id';
    const ISI_PING_TRANSIENT = 'in3pida_isi_last_ping';
    const LLM_CACHE_TTL = 43200;
    const LLM_CACHE_SIZE_OPTION = 'in3pida_llm_cache_size_bytes';
    const LLM_CACHE_MAX_BYTES = 1048576;
    const DEBUG_LOG_OPTION = 'in3pida_debug_log';
    const GEMINI_API_OPTION              = 'in3pida_gemini_api_key';
    const ISI_MONITOR_ENDPOINT_OPTION    = 'in3pida_isi_monitor_endpoint';
    const ISI_MONITOR_TOKEN_OPTION       = 'in3pida_isi_monitor_token';
    const ISI_MONITOR_CACHE_OPTION       = 'in3pida_isi_monitor_cache';
    const ISI_MONITOR_LAST_SYNC_OPTION   = 'in3pida_isi_monitor_last_sync';
    const ISI_MONITOR_LOG_OPTION         = 'in3pida_isi_monitor_log';
    const ISI_MONITOR_SUGGESTIONS_OPTION = 'in3pida_isi_monitor_suggestions';

    private $_opts_cache = null;
    private $_schema_opts_cache = null;
    private $_llm_opts_cache = null;

    public function __construct() {
        add_action('init', [$this, 'register_cpt']);
        add_action('add_meta_boxes', [$this, 'add_metaboxes']);
        add_action('save_post_' . self::CPT, [$this, 'invalidate_llm_cache_for_post'], 10, 3);
        add_action('deleted_post', [$this, 'maybe_invalidate_llm_cache_for_post']);
        add_action('trashed_post', [$this, 'maybe_invalidate_llm_cache_for_post']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('in3pida_faq', [$this, 'shortcode']);
        add_shortcode('site_faq', [$this, 'shortcode']);
        add_shortcode('in3pida_llm_layer', [$this, 'llm_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_head', [$this, 'schemaorg_output'], 30);
        add_action('wp_footer', [$this, 'llm_auto_output'], 30);
        add_action('wp_footer', [$this, 'faq_js_fallback'], 40);
        add_action('init', [$this, 'maybe_set_faq_page_option'], 20);
        add_action('template_redirect', [$this, 'maybe_nocache_faq_page']);
        add_action('template_redirect', [$this, 'faq_page_direct_render'], 1);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_filter('manage_' . self::CPT . '_posts_columns', [$this, 'columns']);
        add_action('manage_' . self::CPT . '_posts_custom_column', [$this, 'column_content'], 10, 2);
        add_filter('manage_edit-' . self::CPT . '_sortable_columns', [$this, 'sortable_columns']);
        add_filter('post_row_actions', [$this, 'remove_legacy_move_actions'], 10, 2);
        add_action('pre_get_posts', [$this, 'admin_order_query']);
        add_action('admin_notices', [$this, 'faq_list_header']);
        add_action('admin_notices', [$this, 'enterprise_admin_notices']);
        add_action('admin_post_in3pida_cc_save_channels', [$this, 'cc_save_channels']);
        add_action('admin_post_in3pida_cc_scan', [$this, 'cc_scan_action']);
        add_action('admin_post_in3pida_cc_clear_log', [$this, 'cc_clear_debug_log_action']);
        add_action('wp_ajax_in3pida_cc_scan_channel', [$this, 'cc_ajax_scan_channel']);
        add_action('wp_ajax_in3pida_faq_sort', [$this, 'ajax_sort_faqs']);
        add_action('wp_ajax_in3pida_create_faq_from_query', [$this, 'ajax_create_faq_from_query']);
        add_action('wp_ajax_in3pida_generate_faq_answer', [$this, 'ajax_generate_faq_answer']);
        add_action('save_post_' . self::CPT, [$this, 'save_faq_visibility_meta'], 20, 2);
        add_action('wp_ajax_in3pida_monitor_sync', [$this, 'ajax_monitor_sync']);
        add_action('wp_ajax_in3pida_monitor_apply_suggestion', [$this, 'ajax_monitor_apply_suggestion']);
        add_action('wp_ajax_in3pida_monitor_dismiss_suggestion', [$this, 'ajax_monitor_dismiss_suggestion']);
        add_action('in3pida_isi_monitor_hook', [$this, 'isi_monitor_sync']);
        if (!wp_next_scheduled('in3pida_isi_monitor_hook')) {
            wp_schedule_event(time(), 'daily', 'in3pida_isi_monitor_hook');
        }
        add_action('admin_init', [$this, 'admin_access_gate'], 1);
        add_action('admin_post_in3pida_si_login', [$this, 'access_login_action']);
        add_action('admin_post_in3pida_si_update_code', [$this, 'access_update_code_action']);
        add_action('init', [$this, 'retrieval_rewrite_rules']);
        add_filter('query_vars', [$this, 'retrieval_query_vars']);
        add_action('template_redirect', [$this, 'retrieval_template_redirect']);
        add_filter('robots_txt', [$this, 'robots_txt_ai_sitemap'], 10, 2);
        add_filter('wpseo_json_ld_output', [$this, 'maybe_disable_yoast_schema'], 20, 2);
        add_filter('rank_math/json_ld/output', [$this, 'maybe_disable_rankmath_schema'], 20, 1);
        add_filter('rank_math/json_ld', [$this, 'maybe_disable_rankmath_schema'], 20, 1);
        add_filter('aioseo_schema_disable', [$this, 'maybe_disable_aioseo_schema'], 20, 1);
        add_filter('aioseo_schema_output', [$this, 'maybe_disable_aioseo_schema_output'], 20, 1);
        add_action('updated_option', [$this, 'maybe_invalidate_llm_cache_for_option'], 10, 3);
        add_action('rest_api_init', [$this, 'register_chunk_rest_routes']);
        add_action('rest_api_init', [$this, 'register_entity_graph_rest_routes']);
        add_action('rest_api_init', [$this, 'register_citation_rest_routes']);
        add_action('rest_api_init', [$this, 'isi_register_update_route']);
        add_action('rest_api_init', [$this, 'register_ai_profile_rest_route']);
        register_activation_hook(__FILE__, [$this, 'isi_register']);
        add_action('admin_head', function() {
            echo '<style>#adminmenu #menu-posts-in3pida_faq .wp-menu-image:before{background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAUCAYAAACEYr13AAABcElEQVR4nKWUMUoEQRBFf3X3rIuBrAaK4AkMNtJEWDcQvIWxNzA3VDAxE48gIniBBXMvsIGRYGCggaAzU91fumdWV1l1Bh803Un9+tVVlLAotpCZTQAKHwwaYwBrL8EyP2ZC2Z5i2yAEVylatEa9cTByA2AeQbXy1RiB697j35A0JO2XMxo5khnJuXTG43h3ZhwzS1CiSPM6poiKIhLq9zKAIYJuIHAVQP3ZHwhcOJwOTlnJ50WSR/T60KCNQzcJFhFPFgN4uYDFCsykCn43+kmJVG+yzbLchXAflHNAc7ik/UNkmluBe7mddKFHr0/05Rla4qrs+QFcp4egb/VfxPRxsP4ixH4vQYu9utj6LyjxbuQAmg9g7FqlhzhIMXsUbhLvHcSsw9QtNngVEW1ov3bg/QJsBngNoN+hL08AZMnP7wgKPXUwJtbqEdQjy/qA7TfNDqdX0Xs3LYOs234hOBscKNfw5WOaq1b7IK607O4dnbQsL2nfGMQAAAAASUVORK5CYII=") !important;background-size:16px auto !important;background-position:center center !important;background-repeat:no-repeat !important;content:"" !important}#adminmenu #menu-posts-in3pida_faq .wp-menu-image img{display:none !important}</style>';
        });
        add_action('init', [$this, 'isi_maybe_ping'], 20);
        add_action('in3pida_isi_heartbeat_hook', [$this, 'isi_heartbeat']);
        add_action('wp_footer', [$this, 'isi_signals_script'], 99);
        add_action('in3pida_run_pending_update',  [$this, 'run_pending_update']);

        $next = wp_next_scheduled('in3pida_isi_heartbeat_hook');
        if (!$next) {
            wp_schedule_event(time(), 'hourly', 'in3pida_isi_heartbeat_hook');
        } elseif (wp_get_schedule('in3pida_isi_heartbeat_hook') !== 'hourly') {
            wp_unschedule_event($next, 'in3pida_isi_heartbeat_hook');
            wp_schedule_event(time(), 'hourly', 'in3pida_isi_heartbeat_hook');
        }

        add_filter('cron_schedules', function($schedules) {
            if (!isset($schedules['weekly'])) {
                $schedules['weekly'] = ['interval' => 604800, 'display' => 'Settimanale'];
            }
            return $schedules;
        });
        add_action('in3pida_pse_auto_hook', [$this, 'isi_pse_auto']);
        if (!wp_next_scheduled('in3pida_pse_auto_hook')) {
            wp_schedule_event(time(), 'weekly', 'in3pida_pse_auto_hook');
        }
    }

    public static function activate() {
        $self = new self();
        $self->register_cpt();
        flush_rewrite_rules();
        if (!get_option(self::OPTION)) add_option(self::OPTION, self::defaults());
        if (!get_option(self::SCHEMA_OPTION)) add_option(self::SCHEMA_OPTION, self::schema_defaults());
        if (get_option(self::CC_CHANNELS_OPTION, null) === null) add_option(self::CC_CHANNELS_OPTION, []);
        if (get_option(self::CC_REPORT_OPTION, null) === null) add_option(self::CC_REPORT_OPTION, []);
        if (get_option(self::LLM_OPTION, null) === null) add_option(self::LLM_OPTION, ['enabled' => 0]);
        if (get_option(self::LLM_QUALITY_OPTION, null) === null) add_option(self::LLM_QUALITY_OPTION, []);
        if (get_option(self::LLM_CACHE_SIZE_OPTION, null) === null) add_option(self::LLM_CACHE_SIZE_OPTION, 0);
        if (get_option(self::DEBUG_LOG_OPTION, null) === null) add_option(self::DEBUG_LOG_OPTION, [], '', false);
        delete_transient(self::LLM_CACHE_TRANSIENT);
        self::ensure_access_hash();
        self::maybe_create_page();
        // Reconcile site_id with Supabase record (fixes UUID mismatch on re-install).
        // Confronto tollerante su www / slash finale / http-https.
        $reconciled = self::isi_lookup_site_id_by_url();
        if ($reconciled) update_option(self::ISI_SITE_ID_OPTION, $reconciled, false);
        delete_transient('in3pida_plugin_perms');
        // Svuota cache pagina FAQ ad ogni aggiornamento
        $faq_page_id = absint(get_option(self::PAGE_OPTION));
        if ($faq_page_id) (new self())->clear_faq_page_cache($faq_page_id);
    }

    public static function deactivate() { delete_transient(self::LLM_CACHE_TRANSIENT); flush_rewrite_rules(); }

    public static function defaults() {
        return [
            'page_title' => 'Domande frequenti',
            'page_intro' => 'Trova rapidamente le risposte alle domande più comuni.',
            'primary_color' => '#171b33','primary_color_inherit' => 0,
            'accent_color' => '#cc236b','accent_color_inherit' => 0,
            'text_color' => '#202124','text_color_inherit' => 0,
            'background_color' => '#ffffff','background_color_inherit' => 0,
            'card_background' => '#ffffff','card_background_inherit' => 0,
            'show_kicker' => 1,
            'border_radius' => 16,'font_family' => '',
            'max_width' => 920,'max_width_mode' => 'custom',
            'order_by' => 'menu_order','order' => 'ASC',
            'open_first' => 0,'show_schema' => 1,'show_solo_ai' => 0,
        ];
    }

    public static function schema_defaults() {
        return [
            'enabled' => 0,
            'only_if_required' => 1,
            'disable_external_schema' => 0,
            'output_scope' => 'home',
            'selected_pages' => '',
            'include_website' => 1,
            'include_faq' => 1,
            'include_breadcrumb' => 1,
            'type' => 'Hotel',
            'name' => '', 'alternate_name' => '', 'description' => '', 'slogan' => '', 'url' => home_url('/'),
            'logo' => '', 'logo_id' => 0, 'price_range' => '', 'official_rating' => '', 'currencies_accepted' => 'EUR', 'payment_accepted' => '',
            'checkin_time' => '', 'checkout_time' => '', 'pets_allowed' => '',
            'telephone' => '', 'email' => '',
            'street' => '', 'city' => '', 'region' => '', 'postal_code' => '', 'country' => 'IT', 'latitude' => '', 'longitude' => '', 'map_url' => '',
            'images' => [], 'amenities' => [], 'distances' => [],
            'languages' => '', 'area_served' => '', 'nearby_attractions' => '', 'targets' => [], 'knows_about' => [], 'keywords' => '',
            'rooms' => [], 'offers' => [],
            'rating_value' => '', 'review_count' => '', 'rating_source' => '', 'google_rating' => '', 'google_reviews' => '', 'tripadvisor_rating' => '', 'tripadvisor_reviews' => '', 'booking_rating' => '', 'booking_reviews' => '',
            'faqs' => [], 'sameas' => [], 'sameas_guided' => [], 'breadcrumbs' => [],
        ];
    }

    private static function ensure_access_hash() {
        if (!get_option(self::ACCESS_HASH_OPTION)) {
            add_option(self::ACCESS_HASH_OPTION, wp_hash_password(self::DEFAULT_ACCESS_CODE), '', false);
        }
    }

    private function access_token() {
        self::ensure_access_hash();
        return hash('sha256', (string) get_option(self::ACCESS_HASH_OPTION));
    }

    private function user_has_plugin_access() {
        return current_user_can('manage_options');
    }

    private function grant_plugin_access() {
        update_user_meta(get_current_user_id(), self::ACCESS_TOKEN_META, $this->access_token());
    }

    private function is_protected_admin_area() {
        global $pagenow;
        if (!is_admin() || !current_user_can('manage_options')) return false;
        if ($pagenow === 'admin-post.php' || $pagenow === 'options.php') return false;
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        if ($page === 'in3pida-access') return false;
        if (in_array($page, ['in3pida-schemaorg','in3pida-coerenza-contenuti','in3pida-ai-layer','in3pida-guida','in3pida-faq-settings','in3pida-query-map','in3pida-ai-visibility'], true)) return true;
        $post_type = isset($_GET['post_type']) ? sanitize_key($_GET['post_type']) : '';
        if (in_array($pagenow, ['edit.php','post-new.php'], true) && $post_type === self::CPT) return true;
        if ($pagenow === 'post.php') {
            $post_id = absint($_GET['post'] ?? 0);
            return $post_id && get_post_type($post_id) === self::CPT;
        }
        return false;
    }

    // Permesso richiesto dalla schermata Eletta corrente (null = non e' una schermata Eletta).
    private function required_perm_for_current_screen() {
        global $pagenow;
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        $map = [
            'in3pida-schemaorg'          => 'schema_org',
            'in3pida-coerenza-contenuti' => 'coerenza',
            'in3pida-ai-layer'           => 'ai_layer',
            'in3pida-query-map'          => 'mappa_query',
            'in3pida-ai-visibility'      => 'ai_layer',
            'in3pida-faq-settings'       => 'config',
        ];
        if (isset($map[$page])) return $map[$page];
        if ($page === 'in3pida-guida') return 'ANY';
        $post_type = isset($_GET['post_type']) ? sanitize_key($_GET['post_type']) : '';
        if (in_array($pagenow, ['edit.php','post-new.php'], true) && $post_type === self::CPT) return 'faq';
        if ($pagenow === 'post.php') {
            $post_id = absint($_GET['post'] ?? 0);
            if ($post_id && get_post_type($post_id) === self::CPT) return 'faq';
        }
        return null;
    }

    public function admin_access_gate() {
        self::ensure_access_hash();
        if ($this->is_protected_admin_area() && !$this->user_has_plugin_access()) {
            wp_safe_redirect(admin_url('admin.php?page=in3pida-access&blocked=1'));
            exit;
        }
        // Se la funzione richiesta e' disattivata dai permessi, mostra un messaggio invece dei contenuti.
        $req = $this->required_perm_for_current_screen();
        if ($req !== null) {
            $p = $this->get_plugin_perms();
            $allowed = ($req === 'ANY')
                ? ($this->perm($p,'faq') || $this->perm($p,'schema_org') || $this->perm($p,'coerenza') || $this->perm($p,'ai_layer') || $this->perm($p,'mappa_query') || $this->perm($p,'config'))
                : $this->perm($p, $req);
            if (!$allowed) {
                wp_safe_redirect(admin_url('admin.php?page=in3pida-locked'));
                exit;
            }
        }
    }

    public function locked_page() {
        echo '<div class="wrap"><h1 style="font-family:\'Source Code Pro\',monospace;color:#0D5F75">Eletta</h1>'
           . '<div style="max-width:620px;margin-top:18px;padding:26px 28px;background:#fff;border:1px solid #e2e4e7;border-radius:10px">'
           . '<p style="font-size:15px;line-height:1.6;color:#0D5F75;margin:0">Le funzioni di Eletta sono gestite dall&rsquo;amministratore.</p></div></div>';
    }

    public function access_login_action() {
        if (!current_user_can('manage_options')) wp_die('Permessi insufficienti.');
        check_admin_referer('in3pida_si_login');
        self::ensure_access_hash();
        $code = isset($_POST['access_code']) ? (string) wp_unslash($_POST['access_code']) : '';
        if (wp_check_password($code, (string) get_option(self::ACCESS_HASH_OPTION))) {
            $this->grant_plugin_access();
            wp_safe_redirect(admin_url('edit.php?post_type=' . self::CPT));
            exit;
        }
        wp_safe_redirect(admin_url('admin.php?page=in3pida-access&access_error=1'));
        exit;
    }

    public function access_update_code_action() {
        if (!current_user_can('manage_options')) wp_die('Permessi insufficienti.');
        check_admin_referer('in3pida_si_update_code');
        self::ensure_access_hash();
        $old = isset($_POST['old_code']) ? (string) wp_unslash($_POST['old_code']) : '';
        $new = isset($_POST['new_code']) ? (string) wp_unslash($_POST['new_code']) : '';
        $confirm = isset($_POST['confirm_code']) ? (string) wp_unslash($_POST['confirm_code']) : '';
        if (!wp_check_password($old, (string) get_option(self::ACCESS_HASH_OPTION))) {
            wp_safe_redirect(admin_url('admin.php?page=in3pida-access&code_error=old'));
            exit;
        }
        if (strlen($new) < 10 || $new !== $confirm) {
            wp_safe_redirect(admin_url('admin.php?page=in3pida-access&code_error=new'));
            exit;
        }
        update_option(self::ACCESS_HASH_OPTION, wp_hash_password($new), false);
        $this->grant_plugin_access();
        wp_safe_redirect(admin_url('admin.php?page=in3pida-access&code_updated=1'));
        exit;
    }

    public static function maybe_create_page() {
        $page_id = absint(get_option(self::PAGE_OPTION));
        if ($page_id && get_post($page_id)) return $page_id;
        $existing = get_page_by_path('faq');
        if ($existing) { update_option(self::PAGE_OPTION, $existing->ID); return $existing->ID; }
        $page_id = wp_insert_post(['post_title'=>'FAQ','post_name'=>'faq','post_content'=>'[in3pida_faq]','post_status'=>'publish','post_type'=>'page']);
        if ($page_id && !is_wp_error($page_id)) update_option(self::PAGE_OPTION, $page_id);
        return $page_id;
    }

    public function register_cpt() {
        register_post_type(self::CPT, [
            'labels' => [
                'name' => 'FAQ','singular_name' => 'FAQ','add_new_item' => 'Aggiungi nuova FAQ','edit_item' => 'Modifica FAQ',
                'menu_name' => 'Eletta','all_items' => 'FAQ','add_new' => 'Aggiungi FAQ','search_items' => 'Cerca FAQ',
                'not_found' => 'Nessuna FAQ trovata','not_found_in_trash' => 'Nessuna FAQ nel cestino',
            ],
            'public' => false,'show_ui' => true,'show_in_menu' => true,'menu_icon' => 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNS4xNiAzLjUpIHNjYWxlKDAuMDE1NzQpIiBmaWxsPSIjZmZmZmZmIj48cmVjdCB3aWR0aD0iNjE0Ljk0IiBoZWlnaHQ9IjEzMC41NCIvPjxwYXRoIGQ9Ik02MTQuOTQsNDIyLjkydi0xMjYuOTJoLTIxNS42OUMxNzguNzUsMjk2LDAsNDc0Ljc1LDAsNjk1LjI1SDB2MTMwLjU0aDYxNC45NHYtMTMwLjU0SDEyOC40OXYtMjcyLjMzaDQ4Ni40NFoiLz48L2c+PC9zdmc+',
            'supports' => ['title','page-attributes'],'capability_type' => 'post',
        ]);
    }

    public function add_metaboxes() {
        add_meta_box('in3pida_faq_answer', 'Risposta', function($post) {
            echo '<textarea name="content" rows="10" style="width:100%;padding:10px;font-size:14px;line-height:1.6;border:1px solid #ddd;border-radius:4px;resize:vertical;box-sizing:border-box">' . esc_textarea($post->post_content) . '</textarea>';
        }, self::CPT, 'normal', 'high');
        add_meta_box('in3pida_faq_help', 'Come usare questa FAQ', function() {
            echo '<p><strong>Domanda:</strong> scrivila nel titolo.</p><p><strong>Risposta:</strong> scrivila nell editor principale.</p><p><strong>Ordine:</strong> usa il drag & drop nella lista FAQ.</p>';
        }, self::CPT, 'side');
        add_meta_box('in3pida_faq_visibility', 'Visibilità', function($post) {
            $llm_only = get_post_meta($post->ID, '_in3pida_llm_only', true);
            wp_nonce_field('in3pida_faq_visibility_' . $post->ID, 'in3pida_visibility_nonce');
            echo '<label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer">';
            echo '<input type="checkbox" name="_in3pida_llm_only" value="1" ' . checked($llm_only, '1', false) . ' style="margin-top:3px">';
            echo '<span><strong>Solo per AI</strong><br><span style="font-size:12px;color:#666">Visibile ai crawler AI (llms.txt, profilo AI) ma nascosta nella pagina FAQ pubblica del sito.</span></span>';
            echo '</label>';
        }, self::CPT, 'side');
    }

    public function save_faq_visibility_meta($post_id, $post) {
        if (!isset($_POST['in3pida_visibility_nonce'])) return;
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['in3pida_visibility_nonce'])), 'in3pida_faq_visibility_' . $post_id)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        if (!empty($_POST['_in3pida_llm_only'])) {
            update_post_meta($post_id, '_in3pida_llm_only', '1');
        } else {
            delete_post_meta($post_id, '_in3pida_llm_only');
        }
    }
    private function get_plugin_perms() {
        $cached = get_transient('in3pida_plugin_perms');
        if ($cached !== false) return $cached;
        $site_id = $this->isi_site_id();
        if (!$site_id) return [];
        // Ritorna: array di permessi | false = riga non trovata | null = errore di rete
        $fetch = function ($sid) {
            $resp = wp_remote_get(self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($sid) . '&select=features_override', [
                'timeout' => 8,
                'headers' => ['apikey' => self::ISI_SUPABASE_ANON_KEY, 'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY, 'Accept' => 'application/json'],
            ]);
            if (is_wp_error($resp)) return null;
            $rows = json_decode(wp_remote_retrieve_body($resp), true);
            if (!is_array($rows) || empty($rows)) return false;
            return $rows[0]['features_override']['plugin'] ?? [];
        };
        $perms = $fetch($site_id);
        // Nessuna riga per questo site_id → probabile disallineamento UUID: prova a riallinearti per URL.
        if ($perms === false) {
            $reconciled = self::isi_lookup_site_id_by_url();
            if ($reconciled && $reconciled !== $site_id) {
                update_option(self::ISI_SITE_ID_OPTION, $reconciled, false);
                $perms = $fetch($reconciled);
            }
        }
        // Solo errore di rete o sito non ancora registrato → non bloccare la UI (fail-open).
        if (!is_array($perms)) $perms = [];
        set_transient('in3pida_plugin_perms', $perms, 30);
        return $perms;
    }

    private function perm($perms, $key) {
        return !isset($perms[$key]) || $perms[$key] !== false;
    }

    public function admin_menu() {
        $p = $this->get_plugin_perms();
        add_submenu_page(null, 'Accesso Sito intelligente', 'Accesso Sito intelligente', 'manage_options', 'in3pida-access', [$this, 'access_page']);
        add_submenu_page(null, 'Eletta', 'Eletta', 'manage_options', 'in3pida-locked', [$this, 'locked_page']);
        if ($this->perm($p, 'schema_org'))  add_submenu_page('edit.php?post_type=' . self::CPT, 'Schema.org', 'Schema.org', 'manage_options', 'in3pida-schemaorg', [$this, 'schema_page']);
        if ($this->perm($p, 'coerenza'))    add_submenu_page('edit.php?post_type=' . self::CPT, 'Coerenza contenuti', 'Coerenza contenuti', 'manage_options', 'in3pida-coerenza-contenuti', [$this, 'content_consistency_page']);
        if ($this->perm($p, 'ai_layer'))    add_submenu_page('edit.php?post_type=' . self::CPT, 'AI Layer', 'AI Layer', 'manage_options', 'in3pida-ai-layer', [$this, 'ai_layer_page']);
        if ($this->perm($p, 'mappa_query')) add_submenu_page('edit.php?post_type=' . self::CPT, 'Mappa Query', 'Mappa Query', 'manage_options', 'in3pida-query-map', [$this, 'query_map_page']);
        // Guida solo se almeno una funzione e' attiva: con TUTTI i permessi OFF resta solo la voce "Eletta".
        if ($this->perm($p, 'faq') || $this->perm($p, 'schema_org') || $this->perm($p, 'coerenza') || $this->perm($p, 'ai_layer') || $this->perm($p, 'mappa_query') || $this->perm($p, 'config')) {
            add_submenu_page('edit.php?post_type=' . self::CPT, 'Guida', 'Guida', 'manage_options', 'in3pida-guida', [$this, 'guide_page']);
        }
        if ($this->perm($p, 'config'))      add_submenu_page(null, 'Impostazioni FAQ', 'Impostazioni FAQ', 'manage_options', 'in3pida-faq-settings', [$this, 'settings_page']);
        remove_submenu_page('edit.php?post_type=' . self::CPT, 'post-new.php?post_type=' . self::CPT);
        // Anche con TUTTI i permessi disattivati, la voce "Eletta" resta visibile nel menu:
        // se il permesso FAQ e' off togliamo solo la lista FAQ, NON l'intera voce di menu.
        if (!$this->perm($p, 'faq')) {
            remove_submenu_page('edit.php?post_type=' . self::CPT, 'edit.php?post_type=' . self::CPT);
        }
    }

    public function register_settings() {
        register_setting('in3pida_faq_settings', self::OPTION, [$this, 'sanitize_options']);
        register_setting('in3pida_schemaorg_settings_group', self::SCHEMA_OPTION, [$this, 'sanitize_schema_options']);
        register_setting('in3pida_llm_ready_settings_group', self::LLM_OPTION, [$this, 'sanitize_llm_options']);
        register_setting('in3pida_api_settings_group', self::GEMINI_API_OPTION, 'sanitize_text_field');
        register_setting('in3pida_api_settings_group', self::ISI_MONITOR_ENDPOINT_OPTION, 'sanitize_text_field');
        register_setting('in3pida_api_settings_group', self::ISI_MONITOR_TOKEN_OPTION, 'sanitize_text_field');
    }

    public function sanitize_llm_options($input) {
        return ['enabled' => !empty($input['enabled']) ? 1 : 0];
    }

    private function llm_opts() {
        if ($this->_llm_opts_cache === null) {
            $o = get_option(self::LLM_OPTION, ['enabled' => 0]);
            $this->_llm_opts_cache = is_array($o) ? array_merge(['enabled' => 0], $o) : ['enabled' => 0];
        }
        return $this->_llm_opts_cache;
    }

    public function sanitize_options($input) {
        $d = self::defaults();
        return [
            'page_title' => sanitize_text_field($input['page_title'] ?? $d['page_title']),
            'page_intro' => wp_kses_post($input['page_intro'] ?? $d['page_intro']),
            'primary_color' => sanitize_hex_color($input['primary_color'] ?? $d['primary_color']) ?: $d['primary_color'],
            'primary_color_inherit' => !empty($input['primary_color_inherit']) ? 1 : 0,
            'accent_color' => sanitize_hex_color($input['accent_color'] ?? $d['accent_color']) ?: $d['accent_color'],
            'accent_color_inherit' => !empty($input['accent_color_inherit']) ? 1 : 0,
            'text_color' => sanitize_hex_color($input['text_color'] ?? $d['text_color']) ?: $d['text_color'],
            'text_color_inherit' => !empty($input['text_color_inherit']) ? 1 : 0,
            'background_color' => sanitize_hex_color($input['background_color'] ?? $d['background_color']) ?: $d['background_color'],
            'background_color_inherit' => !empty($input['background_color_inherit']) ? 1 : 0,
            'card_background' => sanitize_hex_color($input['card_background'] ?? $d['card_background']) ?: $d['card_background'],
            'card_background_inherit' => !empty($input['card_background_inherit']) ? 1 : 0,
            'border_radius' => max(0, min(40, absint($input['border_radius'] ?? $d['border_radius']))),
            'font_family' => sanitize_text_field($input['font_family'] ?? ''),
            'max_width' => max(480, min(1400, absint($input['max_width'] ?? $d['max_width']))),
            'max_width_mode' => (($input['max_width_mode'] ?? 'custom') === 'site') ? 'site' : 'custom',
            'order_by' => in_array(($input['order_by'] ?? ''), ['menu_order','date','title'], true) ? $input['order_by'] : 'menu_order',
            'order' => in_array(($input['order'] ?? ''), ['ASC','DESC'], true) ? $input['order'] : 'ASC',
            'open_first' => !empty($input['open_first']) ? 1 : 0,
            'show_schema' => !empty($input['show_schema']) ? 1 : 0,
            'show_kicker' => !empty($input['show_kicker']) ? 1 : 0,
        ];
    }

    public function sanitize_schema_options($input) {
        $d = self::schema_defaults();
        $types = ['Hotel','Residence','BedAndBreakfast','Resort','Hostel','Campground','VacationRental','ApartmentComplex'];
        $out = $d;
        foreach (['enabled','only_if_required','disable_external_schema','include_website','include_faq','include_breadcrumb'] as $k) $out[$k] = !empty($input[$k]) ? 1 : 0;
        $out['output_scope'] = in_array(($input['output_scope'] ?? 'home'), ['home','all','pages'], true) ? $input['output_scope'] : 'home';
        $out['selected_pages'] = sanitize_text_field($input['selected_pages'] ?? '');
        $out['type'] = in_array(($input['type'] ?? 'Hotel'), $types, true) ? $input['type'] : 'Hotel';
        foreach (['name','alternate_name','slogan','price_range','official_rating','currencies_accepted','payment_accepted','checkin_time','checkout_time','pets_allowed','telephone','email','street','city','region','postal_code','country','latitude','longitude','languages','area_served','nearby_attractions','keywords','rating_value','review_count','rating_source','google_rating','google_reviews','tripadvisor_rating','tripadvisor_reviews','booking_rating','booking_reviews'] as $k) $out[$k] = sanitize_text_field($input[$k] ?? '');
        foreach (['description'] as $k) $out[$k] = wp_kses_post($input[$k] ?? '');
        foreach (['url','logo','map_url'] as $k) $out[$k] = esc_url_raw($input[$k] ?? '');
        $out['logo_id'] = absint($input['logo_id'] ?? 0);
        if ($out['logo_id']) {
            $logo_url = wp_get_attachment_image_url($out['logo_id'], 'full');
            if ($logo_url) $out['logo'] = esc_url_raw($logo_url);
        } elseif (!empty($out['logo']) && function_exists('attachment_url_to_postid')) {
            $maybe_logo_id = absint(attachment_url_to_postid($out['logo']));
            if ($maybe_logo_id) $out['logo_id'] = $maybe_logo_id;
        }
        $out['amenities'] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array)($input['amenities'] ?? [])), 'strlen')));
        $out['targets'] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array)($input['targets'] ?? [])), 'strlen')));
        $out['knows_about'] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array)($input['knows_about'] ?? [])), 'strlen')));
        $out['distances'] = $this->sanitize_assoc_text($input['distances'] ?? []);
        $out['images'] = $this->sanitize_image_rows($input['images'] ?? []);
        $out['sameas'] = $this->sanitize_url_rows($input['sameas'] ?? []);
        $out['sameas_guided'] = $this->sanitize_guided_sameas($input['sameas_guided'] ?? []);
        $out['faqs'] = $this->sanitize_repeater($input['faqs'] ?? [], ['question'=>'text','answer'=>'textarea']);
        $out['breadcrumbs'] = $this->sanitize_repeater($input['breadcrumbs'] ?? [], ['name'=>'text','url'=>'url']);
        $out['offers'] = $this->sanitize_repeater($input['offers'] ?? [], ['url'=>'url','name'=>'text','description'=>'textarea','price'=>'text','currency'=>'text','availability'=>'text']);
        $out['rooms'] = $this->sanitize_repeater($input['rooms'] ?? [], [
            'name'=>'text','url'=>'url','description'=>'textarea','min'=>'int','max'=>'int','bed'=>'text','price'=>'text','currency'=>'text','availability'=>'text','view'=>'text','amenities'=>'array_text'
        ]);
        update_option('in3pida_schema_last_saved', gmdate('c'), false);
        return $out;
    }

    private function sanitize_assoc_text($arr) { $out=[]; foreach ((array)$arr as $k=>$v) $out[sanitize_key($k)] = sanitize_text_field($v); return $out; }
    private function sanitize_url_rows($rows) { $out=[]; foreach ((array)$rows as $v) { $url = esc_url_raw(is_array($v) ? ($v['url'] ?? '') : $v); if ($url) $out[] = ['url'=>$url]; } return $out; }

    private function sanitize_image_rows($rows) {
        $out = [];
        foreach ((array)$rows as $v) {
            $id = is_array($v) ? absint($v['id'] ?? 0) : 0;
            $url = esc_url_raw(is_array($v) ? ($v['url'] ?? '') : $v);
            if (!$id && $url && function_exists('attachment_url_to_postid')) {
                $id = absint(attachment_url_to_postid($url));
            }
            if ($id) {
                $attachment_url = wp_get_attachment_image_url($id, 'full');
                if ($attachment_url) {
                    $out[] = ['id' => $id];
                    continue;
                }
            }
            if ($url) $out[] = ['url' => $url];
        }
        return $out;
    }

    private function image_row_url($row) {
        if (!is_array($row)) return '';
        $id = absint($row['id'] ?? 0);
        if ($id) {
            $url = wp_get_attachment_image_url($id, 'full');
            if ($url) return esc_url_raw($url);
        }
        return esc_url_raw($row['url'] ?? '');
    }
    private function sanitize_guided_sameas($rows) { $out=[]; foreach ((array)$rows as $k=>$v) { $key=sanitize_key($k); $url=esc_url_raw($v); if ($key && $url) $out[$key]=$url; } return $out; }
    private function sanitize_repeater($rows, $schema) {
        $out=[]; foreach ((array)$rows as $row) { if (!is_array($row)) continue; $clean=[]; $has=false;
            foreach ($schema as $k=>$type) { $v = $row[$k] ?? ''; if ($type === 'url') $v = esc_url_raw($v); elseif ($type === 'textarea') $v = wp_kses_post($v); elseif ($type === 'int') $v = absint($v); elseif ($type === 'array_text') { $v = array_values(array_filter(array_map('sanitize_text_field',(array)$v), function($item){ return trim((string)$item) !== ''; })); } else $v = sanitize_text_field($v); if (!empty($v)) $has=true; $clean[$k]=$v; }
            if ($has) $out[]=$clean;
        } return $out;
    }

    private function opts() { if($this->_opts_cache===null) $this->_opts_cache=wp_parse_args(get_option(self::OPTION,[]),self::defaults()); return $this->_opts_cache; }
    private function schema_opts() { if($this->_schema_opts_cache===null) $this->_schema_opts_cache=wp_parse_args(get_option(self::SCHEMA_OPTION,[]),self::schema_defaults()); return $this->_schema_opts_cache; }

    private function admin_header($subtitle='Posiziona il tuo sito nelle ricerche AI') {
        echo '<div class="in3pida-hero"><div><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZQAAABQCAYAAAA+y4O2AAAgnElEQVR4nO19C7RkVXnm95+9zzlVtx80T2lHHgJGRWcBwhJ1RtKNIWF0gg9sJmiUCS8fUVuZLEVIBozJ0mTNDFFjfE2CCQSkGzS6GBRcSKuj+CJxfCELBAWf0A3dt+lbVWfvff5Ze5997q3bfetx762qW/fU/lbf7nurq+qes2vv//1/P8GDmSUqDCLS/TyPmQmAWMRbGyJiVBDMd0lgEyqMJX92zGz3iN0rE7s2Szgrqww7QLS5L7kxTPD+67x9O2PLlryqcicgICAgYMSwTgAzRxgjOAuLn3hiA6ZqV0HKGFoB0Vhd43LAiEQEraeR1N5DRE2r7RfS7PaDIaKcOTsNubgQubKWycILkefFGkWUI0r+goge7fS+qxVuo+rm1ZDJodAqr5w1HhHQ1O+nNWt+vpTPjnXz3RDx0yq4NgwZR0B2DVH9gfJczHuCXy9mPhRZ479DCgFtKiY34gh59jhk7c+JSK3IRbBTFoxm8zgk8jIAu8D0IIT4LoAflFEX7y2PhcdSKJSZmaNQrz+MqkI1WojrTyGiPV0UirQfEOvWf4VIru3/zVsnEtXuXejgrUa0CQsJ3XoUMj0YVYVSp1GS3LOUz45V8yHI9FhUFVq/hOL4S1ZYEZFZ2PhqHA/UHkBVoZrTiGsbiWhmJQxG9mvPqvkxyPTS2f/ItVUz94JwCyJ9LVH9Qf/8FZdBRd6EOYdq7oUQdRjDFbK4GHFCQLTTfd8fWvY4QTVNl/gw26SMjTNDYsVjrEPE4wDWQTXtJq2M+elgrWlezmfHTwB4WgXXJkdci8Dch1VeM1DNGURRgjyvktwo1gBs9z+voHeS8759TwXofBilkTvZHIEgIGvPBvCnyGkrG/UhRI/+pVd8BxgAo0R7Il6CSLYJy9UPZrbpeGBRBQf23u3zCUSi4/vaNSqSZdVYq4Uh/FrkIKqS0Cy2Bdznt1RUc22scVkoyD7WpkkVlRt+DTqc/9EgchGTVuNSyMQadRpE8ez/FoZMDiHWIYqvgDniZbx37+uI6PsrqVSqcxACAgICKgAuDFXD/Ng6EF0665m0wxoxVpHbiJJqKgh5Euq1r/DM9BkuTFbkVUaOoFACAgICxgvC5WvU2vMRpxthss5esPUKrediPRgRbUBSv5VbT57slcrI5XtQKAEBAQFjAi5CjVYZ2DDiVv9Q71Ci9VayloGQ6xAlNzPzQW3ezsgQFEpAQEDAuOCuuwrvRLdeirh2IlTT5qb6k9NRJJA1NGR8PLLG+33F10hlfFAoAQEBAeOCTZvKsl/bd4JFV5nZQiKTWU/lEubWv3eVYrxtZPmUoFACAgICxgBcJNKZs+wFiMQZ0C2bO1mcMrA5FVvCLWIBzVuL3pktGBXay2mNq8svmneqUf7n7qWomBhKH4O2tAJs+1aqCrtudk9UrdeitPt42WtjSzeL5KfdZ7byZrRnh9n4MzsYzH3W/b6nAbNdB/Zl9MVajHIdXHuAK9/mwa4Bj7z0lmxTcda4DFGNYLT9bJdy7gRybdfiXObpy4lo56gaMwuFYi86Tte6MxFVkCOS+ZAhKcliI1cXtkteQqaoJHK1jM1OG9zaxLW2x4ztvi/6A+yhHoVQjWvDCWe09zx0RoS4VnfftV9FrgBjSmE8fCUrBCGKh7AOZPc/jbSRkfkEGHUOTGZzJ0u7J7veRhnE9Q1QfB6Av/Of0NCbsIsDVa/vgmn8ISCkLTCoDoGo3dO2Ux4NADP2kXHguxlntK2PgTGXQpq1yDKGqMqemAVhpvGQ/37xe8JgK6R5CpQ+AhQdi9w8BxE9G3HNCqHI6RRbdVOUdQ7Pu1OtK8D5z10TnoiWb9xYPZAkBCl/6B9Z6D2L9dr55KM4OPpDIF8Hjo4E+AQAJwL0TMS1qTblooeiYK1nIhOCzn4Dbd4NEdk9SxCCB7IGeb7PM2eMQm6Qo7NpzbwVST31jYzLMXjKmrELmfkjQ4nSdPitAfO5vF4Dkfyzo17p1ikvJUHrBmJ+JtHUI+PAoxOwsuC9e4/A2tppyPnlYDoHQh7p/kM1DOAa0QZ13ubC0mrf0TR16CMYI/DMzDFIxIsBOhfMvweZ1GGjYtqFcMRAO9otRYpu3kdx/VlYpeC50t7DYLL7QNEGWB28/P2SI5IRTPYiSqbuHkUHvZyQ2Re8kvw2qxVh5ke/a7PDlufY93oUwG32i5mvgFGvAehtiOsnwGTW8s0RDZiSVyQHM/OvfO4iH/Xa7DdHyZ0zmpr6GQD7dT1z8xnI9cVgfgPi2kEFZQgTyNI9DwokmB+qAcfqOdN8VckN4YzZrHkh4vTgnt6J1TMFd5rdTwIuhdRB4Vq2dYOLAdw9vMtvu7RR/JLVgOChBAzI0nQKoxREzLwORr0DwOUQcR1ZwzghsMxfNXt2c/VcStf9cJz2n88HFGRp/pqYG0+HFldDxq/3uableytzHsr9kN840Q7DWm1jJHjOO6lDte5FLI+CUp17T2wRhr1n1fwCiH4Kmb6po6yyckpIQm52Q6bPGEVyvlqVOwEBKwh7UJ2FXtBekDdS9pJM/tyGHWD0d5DUrUWpK74OuV8Hm2SOinWoP0RxcgF069Uw/KgrJsjzEDWAp1nJGlsQp0e7oo7eOTcC4YOQ9GHfSE+dk/NaQ6YbYJpl7fBQk6FBoQQEDE+5OIvZCdR07XchfnUGcn0d4poNZ1RaqeynXPSsYolrt0DoF8LoeyZBufaBnLdtswULb+8ZqnMeWRJBt34CWfsSkNwL3foxZGLHDXTyTi3buv1zUUk6iSEiKJSAgNEoFkF0dINE/Hrk2YcgU7m8eSyrVrFYb+VBiD1nwuivOuU6oUqFiyR5jt///d9BnJ7saVZE936biMD4OyLK3GuJbvTRz4UVin0/neWI4lMBdbofnjc0LyUolICAEaAtDCZIpG+Dbn0EcTpxwnROuR42DbH7ZdDZN71SmcTwF7u/I/5v5fDczs+0edvYeie7EKefnM29CNwEnemuebkiOQ8oPTf1cUgICiUgYETwyVCbVxAU194M1bxtEoVpOa+D6PC9aKlXwKhHIOJuYZvq0qxw6xSI+CXQrV6NjAaRtOGrfyQiO0lSFIUYtfsA/hpEQl32ke2ct5Xrr7Kl7aVxM4z7CgolIGD0SsWGHQiN7PXQ2c8h5EQJUwsv1CStXftr5Pq1BXVKZOlbVk2F1nJBbuZJ/g7/+Xc2KuyaWA/EqBY0PuKVwRwdEtE/++ehR3L+IKTSds5bDCXsFRTKUmELK4hagG76RybmIAQsDyWtOB100C6AL0UkbDf9xO2f2ZxKMvVV5Op/QCZiEhQrz9KszBwDil7taFa6C3jjPJDcfJbq9Qf8eGC7ToUSEtlnoVvTkLFdP+6anIfrnLe/fyhecVAoy4OzNlf6IgJWsYUe1z4P1fw0ZDqpZbTFZEG5+73Q2U97VCxVBVEx84Te7FgE7OferSvelhG7rcF/M//hIsFOtO5RMH8BkbSyyHRNzsv4FKjGC4eVnA8KJSBg5WDzKYQ4uhJGZa6reTJDgBHRxn3I8/c6b63CRhrPzovffTCYLixYgbv0ndhQmEwj5Or/evoUq4zMAe9JdJ33Qrq9V24p3wDXOT8UrOgG9lUvtj7dJphk25cY9NdK3mfAAPbEXXcNY1/QWIS+qPZj5OZzjuhwwqq+PIokcVK7Abr104qHvkSRO4kvQJweBm0bGbvI4XKHGiq9k/2fa8uxGTK9E7r1iFM+ndeuTM6/kpkPH0ZyfqQKpSyb9ELCUQC0ddXqti8z6K9R3mfAkvdE1HFPbN48jH0xFpawO9QGH/WG+aR6KVbQNm0VkzfY8+p6J5yCxB9bB7VrqMsqBhsC1Nl9SNPPLdSY6ENXlpGhAfAtXdeuPTlvmkNJzssV4DeaXRAu5pQcjdbMcZDiaWB6CsAHAVjjhhYt98Db/FScEDK1B0n6Lrvoq43rp4rosSfWAdnR0HwsKDoKzBuBfAPs4+Rq7Qf12RFk/mdEUw+v8J5wFibzD74KdcJPEKfHQ7lJfZOmWAohmOvtMOpPu5Ierl4Izxf4csj0hK58gXONjFYOfpiIVMk3uNAzi7/zG5HrrT3Kj33nPA2F1l4OWWi4BSwvmqenD0M9eSEi2gzG6TDZMxBFhyMtRicMDcS2EuvP/FyUgBVCsSd2zN8TzGsAPB+5PhOc/wfo7FkAbxzJUC+lPgjg4QEz1C4KhTK5SxI9N2PVvAOgN80rCZ0QeN4v+zn8CLr5A8jaSY6ZuFqKNXf3qJuX9UGzYme92EbGnZDp9d1oU9pCV9+BanwPce0k6Mw+V3RMzgv5PJecT6a+NkhaezlkRWLLAqegW2cjiv4LmDZDyMPnnp0DboqudiUMg74W957WQwFsI1DlzJ3V5pH4Tev4raD1mYii86CzsyGTo+cmhTKgMzjrbZifmWWRHxvqEz82gujLAN40wSzghQWvml8DcFKVFCt7oc2qsQkyOd0ryx6NjEIiV9cS0RN9CP2SAv8GgE5yCqlTNK1Izkc+OW/XemAYqEJpu2nNvO+pMPFFMOoCyPT44hmWttrOQ3AbZW4G9yCH7ux3QUXDSGVGUK46tO0Jw7xzPcyG18LoSyDlKe4JUQxkDbv5zUj2RAm3LVY2KX9AuEfw92GyXoKm+iD+V1QVjMsKHVnOre/WyJg12xoZua89ZHg7IvUeRKKG3HTK0bQn599JRI8NKuw7EIXiG2UcdbetHoDOtsLQGyDiw9wTCmsTXlhEVbE6AvrzSpi5BqPeCIO3Q4hj3BPmDIvID50aej5vjOEPcvoLcGsXZHw4lJspPi4Kb7TrkPH9qFenQIHLRsZWy46J/k8FzUrX/W4bGSVU8zNUrz/UT0iqHBVARA9xa+YrSOpnITd5h7AXQSuDpF4m5z88qJnzy/7AfKKoSCxqfSmM/i5kciVEdJibPFa6dsXXpB2QiYQ/AIWBoZovh9HfhoivgZDHuAFTZWzcTqWrVox8uZgG57v8seTJJUuMfuMKE6yhUQ0qFnLWP/FWiLg3d5s9E0YzYjGvkbEP2HJ7K2Ovb+uM7/Q7iuXOeaC09ks+zLPMqTZu15w+kU12J4T4GET01EKRuKljQWBMGLyBYZj3HsEm+yfI9F8g5HOLPeGEhDUswp44sPTTCx2a9g9XQZAuFsU9G7MXjJbLc61ysOfdYuanguh8GNWdZmW2kdF8mSj51kKNjF1QlMIn9Vuhs12+n4e7d84np0CpgXXOR8tw4YrqAt36I8j6NxDFZxZCIysVScW9EbcEGR5tlFxeE415BoZqnIW89i1E8etcuLPwSIJx0R8mUZHMR5FQ5ko1MurmGyCTtchND5qV2X87NTJ2fuksFQs9AfCtvive9Oycp3xgnfOLPuBzs6u3R6xaH4ZI/gHE66AaZjIUyTww8rwqG3+5Vpi1sA1nzT9BFN+OSBzjDIwi1BkUScDEgecaGdcBdIlLkneTuWUjo2r+GDK9zXuti85r2EokgK/vo1G2SM4zXsU8PZDOebkUZcI7d65Hvv5GyPilUE1VuHA0jvFON/tykVbfJCnEZaPcgG5fWANDJm+Gbhm4fCB1Yz9dWYzpZQVUCqIo5W28FnFtY89GRrcpXZzvb8tGxiUkynO/t78C1fgJ4lrnRtmycz6uHQTFA0nOy0UrE+bDoLPPI4pPg2oCcRxjXOGEnVvHxVxjNrwLqqZn4r5X2acg4/NgMkBKa2CMefQmAowKxkPAMGGcUtDZWz3NSudnWsNLJDav8RvEta6NjN3QRsWSsWpsB+jy7v089qKcT3Mh81XL7pyXi1QmG6Bbd0Cmp0A1fwOiGMo6KGMLRhwRCI/1Id08fQHPjOTKqkOfksOomyDjLW5PWOWdrwIapiLhOyaNjQFVAzv2A9ek+TLI9ETntfeaeTLXyLinC83KImhsohth1Du7ekWEcub886CufAEl9PXldM7LfkMajtBMZZ9BbJVJ4zOI6xcDewWwbryJF6enCevX22t80v7Ys3mHo93Fv45LbDTXuMrQzobAqvkJyHQLdPYjxLUXYzVBYE8b629AwACxqdxTl81Gszp3rjMiYQV7A5I/2jaRcUlo60n5Hrca30ZSO71ruK2YOR/BZDY5/3UM2UMpBccnEaeWIyJH5JhaLZ1JlVAomjjf5WKOQpQ5oaBVDoQvF5+5CjK9GM4lsa1IldsTAQFLp1nJZl6ISJ4B7XIYPSYyxraR8WaiqZ8NiFuriB4I2PHAp/eI0LR1zk+/azmd810Vip1BUSSVZq6ATP8AqtlEXKvZBujSSh3WKMlBo4/F8f/fegxIpiHkBhfOC17KPMz1Hu17BdL61dCtDDJNHGHGCs8XWSwC63TAkHEZLEG2sTNPulQ62gbOXFuj7IMDPEOezif/NHT2fgg55ZolF6rCnUvOb1hucl72FBzZzBkQyV/AZBo893yf/OHqHcr1T4CavwTEBsA1Ia0qITmaWdh8NIz6B9ek5XuSLKq3FwIClnhGms3fAkXnQGf9NDIKqMaXKFnznUU2MvYKe1kZ/gvWjS8iSs6BsUqr47W0z5xfcnJ+Qa1ZkpHxY4+tA6JrnQbL80rnFNqagnIw7vcPBwE5H4UbbFqfgIgP9hs09JgEBOx/RgTeAhkn4B7z4kuDlaJr5v08oGspmL3JU7F0vepy5ryltX/BUjvnOwmDonlxw5r3Ik6Pg85sg9okCA6/6PRv/uegUPaPC+vWRRDp77qmRUujEhAQMJ9mZe/eIwB6XTEvvqt3kiOu2fkoP4RMv+DzFoNMIRRULGl6u6vA7EbFMqCZ8wcoCd62rRAcrdbJIPkWmA6DWqqJYrGJv+l/nAQl2v9BsQPSGO/zLKZhbQICFqJZSeOLIJMNMLqHd+KLfggf8iXCYkhRl71g/hc/Htj0Ts6LV/L00jrnDxQKW7Z4oWr+GiIWyE2RtJkMFIksqe6Bak07GoSFNbpnN0ADu3aNdSPOgOBmvaMevxsyObxnkjEgYHJpVqZA9Eb7bU+aFeEmMv4aonbjIBl/FwTJ68F5wWTc8TnlzPlkA6biLf7RRSm5eW9e5hBYNc5EXDvLNeMUc7wnAl6jR0TrbSPkN737160enPGc5/BEJBlnZo4Gojc6ZTI5HmtAwOK8E5Od5yaQqp5Gl+39sFbp/6aCYbp4/YAx62XE8Tegs3u9kdxNphXJ+RxLorWPOnSLX168b6VlZa81udX/O5GLMIsdOwrvJKatkMmUC3dNjscaENAvcpfE5nxrX/PibSOjyfZB8ceX28jYB/xIdvqUTxN3/l2zM+ddcn7RtPbRAd4Jt05GJF9STBWbyFGkxWLH6eegs5ajQxhXgsMhwyUJN2+2M+APAUUX9EwyBgRMIGarQ3XzLMjayVBN7qOR0VbO3kxTU4/MFkEND56KBTfBKOWKaXol56OlJefbPZTC6szMJRCxdYtWRcPioNFGW/BTsLkLIrYLP6nUHMWhUM3zIJJDoZ0bH7yTgIAFIztU0Kz08lCsssm1AUcfKJKxI5Jptdp9YPN1iKSXRzSXnGc+bDHJ+WLWqOfdd7z9kXhVz+RN9VHcO8Uf91UYk4pi0zFe5/4OuiQgYB6KcBAxZ/tORSRe4sJF3byTopGRYMydlKb/hsGXCneXabmjYnFX0j05r4xLzltjskBfkQmvNHYUT9atzZDJkW5RJrsstNDIUt4G1Xqgj0RW5TDHMN38LUTR8x0t/WQbGQEBC4LICufo7RAyAvek2qb9JjKOykorlFamP+sqWIXsEcovx0/wRXzVVfbc96X0vIDY5F22/Bz/LhMlPPeHr7awcdEWwNfYEOcEVigUe0PhbMhEIrf14xPsqwUEdKqAbDSORSTO7Tkv3gpl28iomt+HTO8YQiNj756UdeseBfHnEUl7raZ3cj55Hq688vR+k/NReVPMbIdQnWEDgRPunZTw5Xa1T0K1fuZqxifJS9m+3StQPss/EpRJQMBCNCsR3gwR13vOiy9sUkKED3hFMuoCF0/g6qlYeuVDy+T8ImbOW8VRvGlr7zMQyeN8aGPihUfhpeywXsoMOL+qqBmfjBJiZ2Scd55VqGsAnNrHbOqAgMlkj+DdhyCK/sjPixddXmBLcSOo1i8hajcNvZGxGxWLTO+Eaj0CGdtqr97JediZ8/0l56NZQSHTk4vOeFfdNfEKxYLIlsxuE0jq10E3v4m4Jiak+s1X/O17JoTc6EvIw54ICJhD0YioahdAJnYset7jjBSNjESfIKInh9XI2Od44AY4v8WL/rx353zad3J+zurk/OTyu4FcfWWwpZjox+ItBeVIURiHasPvi+hERNJuuckJ9QUE9E+zkoLwx35ePHV7AYSbyPgkZDKKRsZ++Apv8PNReoXd2mbO9/aqrODwCXk8s3h5METb4d08QUnyHRj1fsfYWS4q8QwReS6vCq5bJPyeqLwCDQhYCs3KKyHT46GcdxJ1eb5BFBPY3EREvxxBI2MfVCxT9yDX/w8yoa5hrzI5H8WnQqmetPZzw1wIR7l/2wYmBexHq5BMXQ2T2dBX4vVwVQVtWfV33EpfSEDAmMoDAufv6EsGEAnHPMyinMi40nKj6OwH3dCTimVe57y+uN/GxhSgw4r7rKClvUz4WKcth1MQ+Wug1ePeE6xqKKis8DrS/xw2RUDAfJqVTRDJ83vSrLBvZMzVFylNv+crw1ZabhS/3/DNMKrZB71UOXO+Z3K+HOm7Fsxri9/jysp6XZD1e+wiitVCc7Xceu+2kZoPsmqcD8S3u/vftk1gi2V63kHMvp9nvJH3SgbObniiDYt546VMeBv3tQgI2A9liuAyl0+1ArB7moCKHAT9r7mfx4Ze6iHOml9GnP6un3G08PltnzlvlBV2H+k0c75QKDMzNcRRre/ePaLMC+hJqHiahdfMtkriDs5m/gQUvdWW16K6qC3iEFjhXOW1CJhweIPJEug+F4bOdtWP3aaWMttGxgiq+V3EtTtH2cjYB1xTJiK6DsDv9fF8T2tvLK39xzrJ/tJD6Rc2bgjk+dNYNWzDmwDkuCzQAtCAlASlWojrX/NT0ZYFz3lmPZX/ybr1C9atPwBHOwFthS4BrgN1HGGvS0LKHxDRz/3mPuBay8et4oRu1ft7Z2vc0DpWqmyCXAXQBFm7206z67QWAQH7w52NbGYr4rp0Y7CJeslQAuOD3iuwz122DBoQCrktktugW7sgY0v+2rlabY7W/lSoxumUTN1djgVfukIhCBgFCPEfQfIOjD3K21N7AVd0sGcQwsN5KnfdJUmmn2LV+CvI5J2L182jhs+PGfVWAH/byWXdD709E1vdYvdEFB2FaDXsiRISyLJTAfxrG3FRQEB3mhXmfwfdOr8nzQrbefFuIuMjeHz3thVqZOxnPPATnDVuBYnXA8pen+yRnI9gHK393Qs9ZWlSUNu5GG42xriDEVuqZtdINNjr3bSpKCcmehdnzV8iTv7G0buz47wax1yCjYHaz3s4I4stJ55prnSysX9EPZq6AgLmw+YcNKvGGyBra/rwTnLYJi7Gx2njxn0+VD4u3sl8kLwO4Av6YMPwI+Fdcv5dRLRzfwN9aQqlcItWPLnUE65iwF3rwEuh/SKWOZUPcGvm15DJ3yNK1kA1NMh2BI4RCgtrjmpnGFhNbMRuW6wGmyhgbBoZd+5cD9AlfdCsMIQU0K29iPXfj5t3UqKtWuur0K0HEKcnQLU699S45HxmENc3wDQXTM6vHgEwpvA5FUnp1E0w+W8jNz9y8VWbkJskMsmAgKo3Mq5f81rI9Mg+aFYMImnzzTcSrf2V9254jO/NEjhu76snpYwOd5g5HxTKIJVKktyDPdMvQq6udbxfcWoZivWkjhAOCKgISjb2t/WkWZltZFR6rpFxO8YYhQKRuLGglupBxTI/OX9A53xQKAPCbPXXIYfsIZFcCN16NfL8QZe3EMLSGwTFEhCwyuBD2ozWzH9GXHuW9046y01mS6Zo+zZupzT9IbZvj4jGt7XAV58RUfp9GPMtd+29CHBnae2ji/b/r6BQhhCTdIolrt2CaO+pyPVfgbFvnmIJyeCAgNWC4qwKYWlWeqfdyHU72iDXNe5n1/Q89ig8DMIN/uded+lp7elVzNPzOueDQhkwrDUzSyhJB+8mEV8OnZ+CXH9sVrEUI4WN/wpeS0DAGMKFclzfSfYiRPLF0C5h3ZtmRTXvgax9yXejj613MoerC6Wp8k9DZ/t6jgeemzl/MFRcaky3LkGhjMJbqdXuJxG/ESI+CcjfB6MfLnIs9suzfRYhsaBgAgLGBtt9e7i5zIV4+iuyIbCbyMirRb4SvSe3FFK0Zs0vwPkXe44HLl5VOjLzkvPtpa0GDFtbXR2GSHcvK1ey11Za7Mp1iegnAK5g5vcB5mxofS4o2oy4dsTc5ssBrQprZ57r2Q/FWleUa8CLfI3dE/lqORyLZmQaP5Rrvt/n3wa7r0pyvuoaIL3l0dy+HPj5Lr0LbjSORxS9FCZTXlnoDleTuwGFuvUwkvrN41oq3BFbthR3RXY8ML/C0V8w7EjjzvtLZwpCngSlTqMk+bY1nuVs3C9O17rPbczaJwaEg1dSSZZki16x2I1qO/dt6cd23rPnUEzRCxDht8F4Pjh/NqLoCETxoJsjyw827f8lbNdNQi7iJasJuRrHzX6QX3O5iu9heWg2I6w5ZF3f8ojd+R40CnkhcDVEUlAQ9XMijf6onYg41o2MC6NQfjK9Haq12/Wa9P3K5uUAznUvdw8oNQNJ2yBEAmOq46HMdsrz7qF1iC9esRSzFLzFT0S7APwf/2WVjv0gj4XWTwebp0PQRuR8KJjXL7MD3xLVCQi6z//cy7K1TaE3AzgCJsuR59XyUGynvMkf9z+Nk5Vv98H9UI51YOE1jyJGnhdnNBFPjOE9LA9SzkBlN0FEaVd5FEU5RBLBDa16bGD3X5I4MnMduqWB/DNQGbpcR8E4zKzRUmPbyNgNvvzXGrtPcta82nKBQDV7sX4wRGxvfJofeqhGRM0RXnLAQijzLNai4auuqpbQDggIWFXoNOekX8y+uGhO2UHYgWph0yb7t6u8wmr5QLdvj2ZjmrPY4f4sGZvcrBZnOfXbtesblgg7qrYpnP1l/+p7LUaF2TW31t+OHb0P96bxu4dBoG95NOTzvagzsMldy6r/PBa1B/db//8P2w4xiGkhUDoAAAAASUVORK5CYII=" alt="Eletta" style="height:28px;width:auto;display:block"><div class="in3pida-subtitle">'.esc_html($subtitle).'</div></div><span class="in3pida-version">v'.self::VERSION.'</span></div>';
    }
    private function top_actions($active='faq') {
        $page_id = self::maybe_create_page();
        echo '<div class="in3pida-top-actions">';
        if ($active === 'schema' || $active === 'consistency') {
            // Nelle sezioni Schema.org e Coerenza contenuti non mostriamo pulsanti incrociati:
            // la navigazione avviene dal menu principale del plugin.
        } else {
            echo '<a class="in3pida-btn in3pida-btn-blue" href="'.esc_url(get_permalink($page_id)).'" target="_blank">Apri pagina FAQ</a>';
            echo '<a class="in3pida-btn" href="'.esc_url(admin_url('post-new.php?post_type=' . self::CPT)).'">Aggiungi FAQ</a>';
            echo '<a class="in3pida-btn in3pida-btn-light" href="'.esc_url(admin_url('edit.php?post_type=' . self::CPT . '&orderby=menu_order&order=asc')).'">Ordina FAQ</a>';
            echo '<a class="in3pida-btn in3pida-btn-light" href="'.esc_url(admin_url('admin.php?page=in3pida-faq-settings')).'">Impostazioni</a>';
        }
        echo '</div>';
    }

    public function access_page() {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap in3pida-admin in3pida-admin-pro in3pida-access-page">';
        $this->admin_header('Accesso autorizzato a Eletta');
        if (!empty($_GET['blocked'])) echo '<div class="in3pida-note in3pida-alert"><strong>Accesso richiesto:</strong> inserisci il codice per accedere a Eletta — FAQ, Schema.org e Coerenza contenuti.</div>';
        if (!empty($_GET['access_error'])) echo '<div class="in3pida-note in3pida-alert"><strong>Codice non corretto.</strong> Controlla il codice e riprova.</div>';
        if (!empty($_GET['code_updated'])) echo '<div class="in3pida-note"><strong>Codice aggiornato.</strong> L\'accesso al plugin è stato aggiornato.</div>';
        if (isset($_GET['code_error']) && $_GET['code_error'] === 'old') echo '<div class="in3pida-note in3pida-alert"><strong>Vecchio codice non corretto.</strong> Il codice non è stato modificato.</div>';
        if (isset($_GET['code_error']) && $_GET['code_error'] === 'new') echo '<div class="in3pida-note in3pida-alert"><strong>Nuovo codice non valido.</strong> Deve avere almeno 10 caratteri e coincidere con la conferma.</div>';
        echo '<div class="in3pida-grid">';
        echo '<section class="in3pida-card"><h2>🔐 Accesso Sito intelligente</h2><p class="in3pida-card-desc">Inserisci il codice autorizzazione in3pida per sbloccare le sezioni operative del plugin.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('in3pida_si_login');
        echo '<input type="hidden" name="action" value="in3pida_si_login"><div class="in3pida-fields"><div class="in3pida-field"><label>Codice accesso</label><input type="password" name="access_code" autocomplete="current-password" required></div></div><div class="in3pida-savebar-inline"><button type="submit" class="button button-primary in3pida-save">Accedi</button></div></form></section>';
        echo '<section class="in3pida-card"><h2>🔁 Aggiorna codice</h2><p class="in3pida-card-desc">Per modificare il codice devi conoscere quello attuale. Il nuovo codice verrà salvato in modo hashato nel database WordPress.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('in3pida_si_update_code');
        echo '<input type="hidden" name="action" value="in3pida_si_update_code"><div class="in3pida-fields"><div class="in3pida-field"><label>Vecchio codice</label><input type="password" name="old_code" required></div><div class="in3pida-field"><label>Nuovo codice</label><input type="password" name="new_code" minlength="10" required></div><div class="in3pida-field"><label>Conferma nuovo codice</label><input type="password" name="confirm_code" minlength="10" required></div></div><div class="in3pida-savebar-inline"><button type="submit" class="in3pida-btn">Aggiorna codice</button></div></form></section>';
        echo '</div></div>';
    }

    public function guide_page() {
        $layer = $this->llm_get_layer_cached();
        echo '<div class="wrap in3pida-admin in3pida-admin-pro in3pida-guide-page">';
        $this->admin_header('Guida operativa Eletta — Posiziona il tuo sito nelle ricerche AI');
        echo '<div class="in3pida-grid">';

        echo '<section class="in3pida-card"><h2>📌 A cosa serve il plugin</h2><p class="in3pida-card-desc"><strong>Eletta</strong> rende il sito della struttura ricettiva leggibile e citabile da ChatGPT, Gemini, Perplexity e altri assistenti AI. Gestisce FAQ, dati strutturati Schema.org, controllo di coerenza sui canali esterni e un layer semantico completo per sistemi AI.</p><div class="in3pida-kpi-grid"><div><strong>1. FAQ</strong><span>Domande e risposte — con visibilità Solo AI</span></div><div><strong>2. Schema.org</strong><span>JSON-LD automatico</span></div><div><strong>3. Coerenza contenuti</strong><span>Controllo canali esterni</span></div><div><strong>4. AI Layer</strong><span>llms.txt + AI sitemap + knowledge base + Mappa Query + Visibilità AI</span></div><div><strong>5. Profilo AI pubblico</strong><span>Pagina leggibile dai crawler AI</span></div><div><strong>6. Score completezza</strong><span>Quanto è completo il profilo per le AI</span></div><div><strong>7. Missing Answer Detector</strong><span>Domande senza risposta nel sito</span></div><div><strong>8. Mappa Query</strong><span>Query conversazionali per categoria ospite (in AI Layer)</span></div><div><strong>9. Visibilità AI</strong><span>Monitor query, competitor, cluster, suggerimenti (in AI Layer)</span></div><div><strong>10. Dashboard iSI</strong><span>Monitor punteggi e aggiornamenti</span></div></div></section>';

        echo '<section class="in3pida-card"><h2>❓ FAQ</h2><p class="in3pida-card-desc">Qui inserisci le domande frequenti del sito. Ogni FAQ ha una domanda e una risposta.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come usarla:</strong><br>1. Vai su <strong>FAQ</strong>.<br>2. Clicca <strong>Aggiungi FAQ</strong>.<br>3. Inserisci la domanda nel titolo.<br>4. Scrivi la risposta nel box <strong>Risposta</strong> (editor testuale classico).<br>5. Pubblica.<br>6. Usa il <strong>drag & drop</strong> nella lista FAQ per ordinare le domande.</div><div class="in3pida-note"><strong>FAQ Solo AI:</strong> nella colonna destra dell\'editor trovi il box <strong>Visibilità</strong> con la spunta <em>Solo per AI</em>. Se attivata, la FAQ è visibile ai crawler AI (llms.txt, profilo AI, chunks) ma <strong>non compare nella pagina FAQ pubblica</strong> del sito. Usala per FAQ generate da Mappa Query o Visibilità AI che vuoi tenere nel layer AI senza mostrarle agli utenti.</div><div class="in3pida-note"><strong>Dove compaiono:</strong> nella pagina FAQ collegata allo shortcode <code>[in3pida_faq]</code> oppure <code>[site_faq]</code>. Le FAQ Solo AI sono escluse dallo shortcode ma incluse in llms.txt, ai-profile e chunks.</div><div class="in3pida-note"><strong>Impostazioni FAQ:</strong><br>Apri <strong>Impostazioni</strong> dalla schermata FAQ per controllare il frontend.<br><br><strong>Titolo pagina FAQ</strong>: modifica il titolo visibile sopra le domande.<br><strong>Testo sotto il titolo</strong>: aggiunge una breve introduzione sotto il titolo.<br><strong>Colore principale</strong>: colore usato per titoli e parti principali della sezione FAQ.<br><strong>Colore testo</strong>: colore dei testi delle domande e risposte.<br><strong>Colore dettagli/interazioni</strong>: colore di dettagli, icone, stati hover e micro-interazioni.<br><strong>Sfondo sezione</strong>: sfondo dell\'area completa delle FAQ.<br><strong>Sfondo box FAQ</strong>: sfondo dei singoli blocchi domanda/risposta.<br><strong>Eredita dal sito</strong>: lascia che colore, font o sfondo vengano presi dal tema installato, così la FAQ si adatta graficamente al sito.<br><strong>Larghezza massima</strong>: imposta una larghezza personalizzata in pixel; scegli <strong>Adatta al sito</strong> per seguire la larghezza delle altre pagine del tema.<br><strong>Font family opzionale</strong>: se vuoto eredita il font del sito; se compilato forza un font specifico.<br><strong>Raggio angoli</strong>: controlla quanto sono arrotondati i box FAQ.<br><strong>Apri la prima FAQ</strong>: apre automaticamente la prima domanda nel frontend.<br><strong>Dati strutturati FAQPage</strong>: aggiunge lo schema FAQ SEO alla pagina FAQ.</div></div></section>';

        echo '<section class="in3pida-card"><h2>🧩 Schema.org</h2><p class="in3pida-card-desc">Questa sezione crea automaticamente il codice Schema.org JSON-LD per hotel, residence, B&B e strutture ricettive. I dati salvati qui sono la fonte ufficiale del plugin.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come configurarla:</strong><br>1. Compila le informazioni della struttura: nome, descrizione, sito, contatti e indirizzo.<br>2. Aggiungi servizi, camere/appartamenti, offerte, recensioni, social e breadcrumb.<br>3. Salva.<br>4. Il plugin genera automaticamente il JSON-LD e lo inserisce nel frontend se l\'output è abilitato.</div><div class="in3pida-note"><strong>FAQ nello Schema.org:</strong> non devi riscriverle. Vengono prese automaticamente dalla tab <strong>FAQ</strong>.</div><div class="in3pida-note"><strong>Impostazioni output:</strong> scegli dove pubblicare lo Schema.org: solo homepage, tutto il sito o pagine selezionate. Usa “solo se campi obbligatori compilati” per evitare output incompleti.</div></div></section>';

        echo '<section class="in3pida-card"><h2>🔎 Coerenza contenuti</h2><p class="in3pida-card-desc">Confronta le informazioni ufficiali salvate in Schema.org con quelle presenti sui canali dove la struttura è presente.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come usarla:</strong><br>1. Prima compila e salva <strong>Schema.org</strong>.<br>2. Aggiungi i canali da controllare: tipo, nome scheda e URL della pagina specifica.<br>3. Salva i canali e clicca <strong>Avvia scansione</strong>.<br>4. Leggi il report con punteggio, incongruenze e azioni consigliate.</div><div class="in3pida-note"><strong>Cosa puoi scansionare:</strong> pagine del tuo sito web (home, camere, servizi, contatti), pagine Facebook pubbliche, Bing Places, Hotels.com, Venere, Agoda, portali regionali del turismo, siti di consorzi e associazioni, blog e stampa online, siti partner.<br><strong>Booking, Tripadvisor, Google Business Profile, Expedia, Airbnb</strong> bloccano le scansioni automatiche: aggiungili comunque come promemoria per la verifica manuale.</div></div></section>';


        $authority = $layer['entity_authority'] ?? [];
        echo '<section class="in3pida-card"><h2>🏛️ Entity Authority score</h2><p class="in3pida-card-desc">Punteggio automatico che valuta quanto l\'entità è riconoscibile e collegata a profili ufficiali. Usa i dati sameAs guidati, i dati Schema.org e, se disponibile, il report di coerenza contenuti.</p><div class="in3pida-kpi-grid"><div><strong>Indice autorevolezza entità</strong><span>'.esc_html($authority['score'] ?? 0).'/100</span></div><div><strong>Profili collegati</strong><span>'.esc_html(count((array)($authority['profiles'] ?? []))).'</span></div><div><strong>Profili consigliati mancanti</strong><span>'.esc_html(count((array)($authority['missing'] ?? []))).'</span></div></div>';
        if(!empty($authority['signals'])){ echo '<div class="in3pida-report-list">'; foreach($authority['signals'] as $sig){ echo '<div class="in3pida-note"><strong>'.esc_html($sig['label']).':</strong> '.esc_html($sig['value']).'</div>'; } echo '</div>'; }
        if(!empty($authority['missing'])) echo '<div class="in3pida-note in3pida-alert"><strong>Consigliati da aggiungere:</strong> '.esc_html(implode(', ', array_slice($authority['missing'],0,8))).'</div>';
        echo '</section>';
        echo '<section class="in3pida-card"><h2>🧠 AI Layer — LLM ready layer</h2><p class="in3pida-card-desc">Un LLM ready layer è uno strato di contenuto pensato per essere letto in modo chiaro da motori di ricerca, assistenti AI e sistemi basati su modelli linguistici. Non sostituisce le pagine del sito: riorganizza i dati già presenti in una forma più pulita, segmentata e facile da interpretare.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Da dove prende i dati:</strong><br>Il plugin legge automaticamente le informazioni salvate in <strong>Schema.org</strong>, le FAQ pubblicate in <strong>FAQ</strong> e, se disponibile, il riepilogo della tab <strong>Coerenza contenuti</strong>.</div><div class="in3pida-note"><strong>Cosa genera:</strong><br>Riassunto breve, riassunto esteso, key facts, blocchi semantici, servizi principali, target clienti, temi rilevanti, keyword e domande frequenti organizzate in modo più chiaro.</div><div class="in3pida-note"><strong>Come si usa:</strong><br>1. Apri la tab <strong>AI Layer</strong>.<br>2. Espandi la sezione <strong>Attivazione LLM ready layer</strong>.<br>3. Attiva il toggle e salva.<br>Il plugin inserisce automaticamente il layer nel frontend. Non devi copiare shortcode o incollare codice.</div><div class="in3pida-note"><strong>Cosa si attiva in automatico con il layer:</strong><br>Appena abiliti il layer, il plugin espone automaticamente anche <strong>llms.txt</strong>, <strong>AI sitemap</strong> e i file <strong>knowledge</strong>. Non devi fare nulla di extra.</div></div></section>';

        $llms_url = esc_url($this->retrieval_base_url('llms.txt'));
        $sitemap_url = esc_url($this->retrieval_base_url('ai-sitemap.xml'));
        $knowledge_url = esc_url($this->retrieval_base_url('knowledge/'));
        echo '<section class="in3pida-card"><h2>🛰️ llms.txt, AI sitemap e knowledge base</h2><p class="in3pida-card-desc">File e endpoint generati automaticamente dal plugin per permettere ai crawler AI (ChatGPT, Perplexity, ClaudeBot, Googlebot AI) di leggere, indicizzare e citare le informazioni della struttura.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come attivarli:</strong><br>1. Vai nella tab <strong>AI Layer</strong>.<br>2. Espandi la sezione <strong>Attivazione LLM ready layer</strong>.<br>3. Attiva il toggle e salva.<br>I file vengono esposti automaticamente, senza creare file fisici sul server.</div><div class="in3pida-note"><strong>Cosa viene generato automaticamente:</strong><br><strong>llms.txt</strong> — file leggibile dagli AI con riassunto struttura, key facts, servizi e FAQ principali. URL: <code>'.esc_html($llms_url).'</code><br><br><strong>AI sitemap</strong> — sitemap XML ottimizzata per crawler AI con priorità e tipo di contenuto per ogni URL. URL: <code>'.esc_html($sitemap_url).'</code><br><br><strong>Knowledge index</strong> — pagina indice con tutti i file Markdown. URL: <code>'.esc_html($knowledge_url).'</code><br><br><strong>File Markdown</strong> — file separati per: overview struttura, FAQ, Schema.org facts, servizi, contenuti citation-friendly, answer extraction.</div><div class="in3pida-note"><strong>Non devi fare nulla di manuale:</strong> il plugin genera tutto dai dati già inseriti in Schema.org e FAQ. Ogni volta che aggiorni quei dati, i file si aggiornano automaticamente.</div><div class="in3pida-note"><strong>robots.txt:</strong> se hai un robots.txt personalizzato, aggiungi manualmente la riga: <code>Sitemap: '.esc_html($sitemap_url).'</code><br>Se non hai un robots.txt fisico, il plugin aggiunge le istruzioni automaticamente.</div></div></section>';

        $ai_profile_url = esc_html(rest_url('in3pida/v1/ai-profile'));
        echo '<section class="in3pida-card"><h2>🌐 Profilo AI pubblico (/ai-profile)</h2><p class="in3pida-card-desc">Una pagina pubblica in testo pulito con tutte le informazioni della struttura: nome, descrizione, contatti, servizi, camere e FAQ. I crawler AI di ChatGPT, Perplexity e Gemini leggono questa pagina e la usano per citare l\'hotel nelle risposte.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Completamente automatico:</strong> non devi fare nulla. Il profilo si aggiorna ogni volta che modifichi Schema.org o FAQ. Non è una pagina da aprire nel browser — è destinata ai robot AI, non agli utenti.</div><div class="in3pida-note"><strong>Come funziona:</strong> quando un crawler AI visita il sito (es. Perplexity, ChatGPT con browsing attivo), trova questa pagina e la legge. Il testo è in formato semplice — niente HTML complesso, niente JavaScript — per massimizzare la comprensione da parte delle AI.</div><div class="in3pida-note"><strong>Cosa contiene:</strong> nome struttura, tipologia, descrizione, sito web, telefono, email, indirizzo, orari check-in/check-out, fascia di prezzo, elenco servizi, elenco camere, tutte le FAQ in formato domanda/risposta diretta.</div><div class="in3pida-note"><strong>URL pubblico:</strong> <code>'.$ai_profile_url.'</code><br>Attivo solo quando il LLM ready layer è abilitato.</div><div class="in3pida-note"><strong>Come migliorarlo:</strong> più campi compili in Schema.org e più FAQ pubblichi, più ricco e completo sarà il profilo. Lo score completezza qui sotto ti dice esattamente cosa manca.</div></div></section>';

        echo '<section class="in3pida-card"><h2>🎯 AI Layer — Citation Engine</h2><p class="in3pida-card-desc">Il Citation Engine genera blocchi strutturati question→answer da Schema.org e FAQ. Ogni blocco e formulato come un\'affermazione singola, verificabile, nella forma che gli AI tendono a citare nelle risposte.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Differenza rispetto ai chunk:</strong> i chunk sono segmenti di contenuto generici. I citation block sono affermazioni precise con domanda e risposta diretta, costruiti per massimizzare la probabilita di essere estratti e citati da ChatGPT, Perplexity e Gemini.</div><div class="in3pida-note"><strong>Come si attiva:</strong> automatico. Legge da Schema.org e FAQ senza configurazione. Si aggiorna ogni volta che salvi.</div><div class="in3pida-note"><strong>Dove si vede:</strong> apri la tab <strong>AI Layer</strong> e espandi la sezione <strong>Citation Engine</strong> per vedere tutti i blocchi con il relativo citability score.<br>REST endpoint: <code>'.esc_html(rest_url('in3pida/v1/citation')).'</code> (attivo quando LLM ready layer è abilitato).</div><div class="in3pida-note"><strong>Come migliorare il citability score:</strong><br>• Compila orari check-in/check-out in Schema.org.<br>• Aggiungi prezzi e fascia di prezzo.<br>• Inserisci rating con fonte (Google, Tripadvisor).<br>• Scrivi FAQ con risposte brevi, dirette, con dati concreti.</div></div></section>';

        $completeness = $this->compute_completeness();
        $score = $completeness['score'];
        $missing = $completeness['checklist'];
        $score_color = $score >= 80 ? '#0D5F75' : ($score >= 50 ? '#0D5F75' : '#0D5F75');
        echo '<section class="in3pida-card"><h2>Score completezza profilo</h2><p class="in3pida-card-desc">Misura quanti campi fondamentali sono compilati. Non è un punteggio stilistico: è una verifica concreta di quante informazioni le AI possono estrarre e citare su questa struttura. Più è alto, più l\'hotel è posizionato.</p>';
        echo '<div style="display:flex;align-items:center;gap:20px;padding:16px 0 8px"><div style="font-size:48px;font-weight:800;color:'.$score_color.'">'.$score.'<span style="font-size:22px;color:#666b84">/100</span></div><div style="flex:1"><div style="height:8px;background:#f0f0f4;border-radius:4px"><div style="height:8px;width:'.$score.'%;background:'.$score_color.';border-radius:4px"></div></div><div style="font-size:12px;color:#666b84;margin-top:6px">'.count(array_filter($missing, fn($v)=>!empty($v))).' campi mancanti su 12 verificati</div></div></div>';
        if ($missing) {
            echo '<div class="in3pida-fields"><div class="in3pida-note in3pida-alert"><strong>Cosa manca:</strong><ul style="margin:8px 0 0 16px;padding:0">';
            foreach ($missing as $item) echo '<li style="margin-bottom:4px">'.esc_html($item).'</li>';
            echo '</ul></div>';
            echo '<div class="in3pida-note"><strong>Come migliorare:</strong> compila i campi mancanti in <strong>Schema.org</strong> e aggiungi FAQ in <strong>FAQ</strong>. Ogni campo aggiunto aumenta immediatamente lo score e il profilo AI si aggiorna in automatico.</div></div>';
        } else {
            echo '<div class="in3pida-fields"><div class="in3pida-note" style="background:#fff;border-color:#e4e4ec"><strong>Profilo completo.</strong> Tutti i campi fondamentali sono compilati. Ottimo posizionamento per le AI.</div></div>';
        }
        echo '</section>';

        echo '<section class="in3pida-card"><h2>🕸️ AI Layer — Entity Graph</h2><p class="in3pida-card-desc">Il grafo delle entita mappa le relazioni semantiche tra tutti gli elementi della struttura. E usato internamente dal plugin per migliorare i chunk e il layer AI, ed e esposto come endpoint pubblico leggibile dai crawler AI.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Completamente automatico:</strong> il grafo legge da Schema.org senza nessun inserimento extra. Hotel, localita, servizi, camere, offerte e FAQ vengono mappati automaticamente. Query target, POI vicini e topic cluster vengono presi dai campi <strong>Keywords semantiche</strong>, <strong>Attrazioni vicine</strong>, <strong>Zone turistiche</strong>, <strong>Target clienti</strong> e <strong>KnowsAbout</strong> gia presenti in Schema.org.</div><div class="in3pida-note"><strong>Per arricchire il grafo:</strong> vai su <strong>Schema.org → Audience e posizionamento AI</strong> e compila Keywords semantiche, Attrazioni vicine, Target clienti e KnowsAbout. Piu dati inserisci in Schema.org, piu ricco diventa il grafo.</div><div class="in3pida-note"><strong>Endpoint pubblico:</strong> quando il LLM ready layer e abilitato, il grafo e disponibile a: <code>'.esc_html(rest_url('in3pida/v1/graph')).'</code></div></div></section>';

        echo '<section class="in3pida-card"><h2>📦 AI Layer — Chunk Engine</h2><p class="in3pida-card-desc">Il Chunk Engine segmenta automaticamente i dati Schema.org e FAQ in blocchi semantici ottimizzati per il retrieval AI. Ogni blocco ha un citation score che indica quanto e probabile venga citato da un assistente AI.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Cosa fa:</strong> divide i dati della struttura in chunk indipendenti — identita, contatti, servizi, camere, offerte, FAQ. Ogni chunk viene valutato con un punteggio di citation likelihood.</div><div class="in3pida-note"><strong>Come si attiva:</strong> automatico. Non richiede nessuna configurazione. Si aggiorna ogni volta che salvi Schema.org o FAQ.</div><div class="in3pida-note"><strong>Dove si vede:</strong> apri la tab <strong>AI Layer</strong> e espandi la sezione <strong>Chunk Engine</strong> per vedere tutti i blocchi con i relativi score.<br>REST endpoint: <code>'.esc_html(rest_url('in3pida/v1/chunks')).'</code> (attivo quando LLM ready layer è abilitato).</div></div></section>';

        echo '<section class="in3pida-card"><h2>🎯 Missing Answer Detector</h2><p class="in3pida-card-desc">Analizza le domande reali che gli utenti potrebbero fare sulla struttura e verifica quante trovano una risposta diretta nelle FAQ pubblicate. Ti dice esattamente quali domande restano senza risposta.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come funziona:</strong> il plugin genera automaticamente un set di domande tipiche basate su Schema.org (città, servizi, target, attrazioni vicine). Per ogni domanda verifica se una FAQ pubblicata risponde in modo pertinente. Calcola la percentuale di copertura.</div><div class="in3pida-note"><strong>Come migliorarlo:</strong><br>1. Leggi le domande senza risposta nella tab <strong>AI Layer → Missing Answers</strong>.<br>2. Crea nuove FAQ che rispondano a quelle domande.<br>3. Pubblica e il punteggio si aggiorna al prossimo heartbeat (ogni ora) o subito dalla dashboard iSI cliccando <strong>⚡ Sync</strong>.</div><div class="in3pida-note"><strong>Dove si vede:</strong> il punteggio "% coperto" è visibile nella <strong>dashboard iSI</strong> nella colonna <em>Missing Answer</em>. Il dettaglio delle domande senza risposta è nella tab <strong>AI Layer → Missing Answers</strong> di questo pannello.</div><div class="in3pida-note"><strong>Soglie:</strong> ≥ 80% ottimo — tra 50% e 79% da migliorare — sotto 50% critico: molte domande restano senza risposta.</div></div></section>';

        echo '<section class="in3pida-card"><h2>🗺️ Mappa Query — AI Query Intelligence</h2><p class="in3pida-card-desc">Analizza le domande conversazionali che gli utenti fanno agli assistenti AI per categoria di ospite (famiglie, coppie, business, pet friendly, benessere, mare, montagna, senior). Confronta quelle query con le FAQ pubblicate e mostra esattamente quali mancano.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come funziona:</strong><br>Il plugin contiene una libreria di oltre 40 query tipiche organizzate in 8 categorie. Per ognuna verifica se una FAQ pubblicata risponde al tema (analisi segnali semantici). Il risultato è un punteggio di copertura con la lista delle query scoperte.</div><div class="in3pida-note"><strong>Come usarla:</strong><br>1. Vai su <strong>Mappa Query</strong> nel menu del plugin.<br>2. Guarda il punteggio complessivo (quante query sono coperte).<br>3. Espandi le categorie con query scoperte (✗ rosso).<br>4. Clicca <strong>+ Crea FAQ</strong> su ogni query scoperta: viene creata una FAQ bozza con quella domanda come titolo.<br>5. Apri la bozza, scrivi la risposta e pubblica.<br>6. Usa <strong>⚡ Sync</strong> in dashboard iSI per aggiornare subito i punteggi.</div><div class="in3pida-note"><strong>Perché è utile:</strong> gli LLM rispondono a domande, non a descrizioni. Strutturare i contenuti attorno alle query reali degli utenti massimizza la probabilità di essere citati nelle risposte AI.</div><div class="in3pida-note"><strong>Soglie:</strong> ≥ 70% buona copertura — sotto 70% ci sono categorie di ospiti senza risposta.</div></div></section>';

        echo '<section class="in3pida-card"><h2>👁️ Visibilità AI — Monitor iSI</h2><p class="in3pida-card-desc">Sezione nella tab <strong>AI Layer</strong> che riceve da isi.in3pida.it dati reali su dove compare la struttura nelle risposte degli assistenti AI.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Cosa mostra:</strong><br>• <strong>Score visibilità</strong> — quanto spesso l\'hotel compare nelle risposte AI monitorate.<br>• <strong>Query monitorate</strong> — le domande su cui isi.in3pida.it verifica la presenza.<br>• <strong>Presenze</strong> — query in cui l\'hotel viene citato dagli AI.<br>• <strong>Assenze</strong> — query in cui non compare (competitor citati al posto suo).<br>• <strong>Competitor rilevati</strong> — strutture citate al posto dell\'hotel con frequenza.<br>• <strong>Cluster semantici</strong> — aree tematiche forti e deboli nei risultati AI.<br>• <strong>Suggerimenti operativi</strong> — azioni concrete da fare per migliorare.</div><div class="in3pida-note"><strong>Come si attiva:</strong><br>1. Vai su <strong>AI Layer</strong> e scorri fino alla sezione <strong>Visibilità AI</strong>.<br>2. Inserisci l\'endpoint e il token forniti da isi.in3pida.it.<br>3. Salva e premi <strong>⚡ Sincronizza ora</strong>.<br>Il plugin sincronizza automaticamente ogni giorno via cron.</div><div class="in3pida-note"><strong>Azioni sui suggerimenti:</strong><br>• <strong>Crea FAQ bozza</strong> — crea automaticamente una FAQ bozza Solo AI con il titolo suggerito.<br>• <strong>Crea pagina bozza</strong> — crea una pagina WordPress bozza con il titolo suggerito.<br>• <strong>Ignora</strong> — nasconde il suggerimento; puoi ripristinarlo in seguito.<br>Una volta creata la bozza, un link <em>Apri bozza</em> ti porta direttamente all\'editor per completarla.</div></div></section>';

        echo '<section class="in3pida-card"><h2>📊 Dashboard iSI</h2><p class="in3pida-card-desc">La dashboard iSI (<strong>isi.in3pida.it</strong>) è il pannello di controllo esterno per monitorare tutti i siti con il plugin installato. Non richiede accesso all\'admin WordPress.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Cosa mostra per ogni sito:</strong><br>• <strong>Stato</strong> — pallino colorato: teal = tutto OK, magenta = attenzione, rosso = problemi. Passa il mouse per vedere i dettagli.<br>• <strong>Ultimo segnale</strong> — da quanto tempo il plugin ha comunicato con la piattaforma.<br>• <strong>GEO Score</strong> — punteggio medio di ottimizzazione AI.<br>• <strong>Missing Answer</strong> — percentuale di domande coperte dalle FAQ.<br>• <strong>Completezza AI</strong> — quanti campi fondamentali del profilo sono compilati.</div><div class="in3pida-note"><strong>Azioni disponibili:</strong><br>• <strong>Aggiorna</strong> — installa la versione più recente del plugin sul sito.<br>• <strong>⚡ Sync</strong> — forza la sincronizzazione immediata dei punteggi senza aspettare il cron orario.<br>• <strong>Disattiva</strong> — rimuove il sito dal monitoraggio.</div><div class="in3pida-note"><strong>Heartbeat automatico:</strong> il plugin invia automaticamente i punteggi aggiornati alla piattaforma ogni volta che WordPress esegue il suo cron (tipicamente ogni ora, con traffico sul sito). Se il sito non riceve visite per giorni il cron non gira — usa <strong>⚡ Sync</strong> dalla dashboard per forzare la sincronizzazione.</div></div></section>';

        echo '<section class="in3pida-card"><h2>🔐 Accesso con codice</h2><p class="in3pida-card-desc">Il plugin è protetto da codice di accesso. Senza codice non si possono aprire le sezioni operative.</p><div class="in3pida-fields"><div class="in3pida-note"><strong>Come funziona:</strong> il codice si inserisce nella schermata iniziale. Dopo l\'accesso, le tab restano disponibili finché la sessione WordPress resta attiva.</div><div class="in3pida-note"><strong>Aggiorna codice:</strong> per cambiarlo devi inserire il codice attuale, poi il nuovo codice e la conferma. Il codice viene salvato hashato nel database.</div></div></section>';

        echo '<section class="in3pida-card"><h2>✅ Ordine consigliato di configurazione</h2><div class="in3pida-fields"><div class="in3pida-note"><strong>Nota:</strong> i passi dal 7 in poi si attivano automaticamente dopo il passo 6. Non richiedono azioni extra.</div><div class="in3pida-note"><strong>1. Inserisci le FAQ</strong><br>Vai su <strong>FAQ → Aggiungi FAQ</strong>. Scrivi domanda nel titolo e risposta nel testo. Pubblica. Ordina con drag &amp; drop.</div><div class="in3pida-note"><strong>2. Compila in3pida schemaorg</strong><br>Vai su <strong>Schema.org</strong>. Compila nome, descrizione, indirizzo, contatti, servizi, camere, offerte. Salva. Questi dati sono la fonte ufficiale di tutto il plugin.</div><div class="in3pida-note"><strong>3. Abilita output JSON-LD</strong><br>Nelle impostazioni Schema.org scegli dove pubblicare il JSON-LD: solo homepage, tutto il sito o pagine selezionate.</div><div class="in3pida-note"><strong>4. Aggiungi i canali in Coerenza contenuti</strong><br>Vai su <strong>Coerenza contenuti</strong>. Aggiungi tipo, nome e URL di ogni canale esterno dove la struttura è presente. Salva.</div><div class="in3pida-note"><strong>5. Avvia la scansione</strong><br>Clicca <strong>Avvia scansione</strong>. Leggi il report e correggi le incongruenze segnalate tra i dati ufficiali e quelli sui canali.</div><div class="in3pida-note"><strong>6. Abilita LLM ready layer</strong><br>Vai su <strong>AI Layer</strong>. Espandi la sezione <strong>Attivazione LLM ready layer</strong>, attiva il toggle e salva.<br>Questo passo attiva automaticamente: layer semantico nel frontend, <strong>llms.txt</strong>, <strong>AI sitemap</strong>, file <strong>knowledge</strong>, Chunk Engine, Entity Graph e Citation Engine. Non serve altro.</div><div class="in3pida-note"><strong>7. Verifica i file AI (automatico dopo il passo 6)</strong><br>Dopo aver abilitato il layer, apri nel browser:<br>• <code>'.esc_html(home_url('/llms.txt')).'</code> — informazioni struttura leggibili dagli AI<br>• <code>'.esc_html(home_url('/ai-sitemap.xml')).'</code> — sitemap XML per crawler AI<br>• <code>'.esc_html(home_url('/knowledge/')).'</code> — knowledge index con file Markdown<br>Se una pagina da 404, vai su <strong>Impostazioni → Permalink</strong> e salva senza modifiche.</div><div class="in3pida-note"><strong>7. Controlla lo score completezza (automatico dopo il passo 6)</strong><br>Apri la tab <strong>Guida</strong> e guarda lo <strong>Score completezza profilo</strong>. Ti mostra esattamente cosa manca e cosa aggiungere per migliorare il posizionamento su ChatGPT, Gemini e Perplexity. Ogni campo aggiunto aggiorna automaticamente il profilo AI pubblico.</div><div class="in3pida-note"><strong>8. Verifica il profilo AI pubblico</strong><br>Visita nel browser: <code>'.esc_html(rest_url('in3pida/v1/ai-profile')).'</code><br>Questa è la pagina che i crawler AI leggono quando cercano informazioni su questa struttura. Se è ricca e completa, le AI la citano. Se è vuota o incompleta, non viene usata.</div><div class="in3pida-note"><strong>9. Controlla Missing Answer Detector</strong><br>Vai nella tab <strong>AI Layer → Missing Answers</strong>. Leggi le domande senza risposta e creaci delle FAQ dedicate. Poi clicca <strong>⚡ Sync</strong> nella dashboard iSI per vedere subito il punteggio aggiornato senza aspettare il cron.</div><div class="in3pida-note"><strong>10. Attiva Visibilità AI</strong><br>Vai su <strong>AI Layer → Visibilità AI</strong>. Inserisci endpoint e token forniti da isi.in3pida.it e salva. Premi <strong>⚡ Sincronizza ora</strong> per ricevere subito dati di visibilità, competitor rilevati e suggerimenti operativi. Applica i suggerimenti creando FAQ o pagine bozza con un click.</div><div class="in3pida-note"><strong>11. Monitora dalla dashboard iSI</strong><br>Apri <strong>isi.in3pida.it</strong>. Tieni d\'occhio i pallini colorati: teal = tutto OK. Se vedi rosso, passa il mouse sul pallino per leggere i problemi rilevati.</div></div></section>';

        echo '</div></div>';
    }

    public function settings_page() {
        $o = $this->opts(); $faq_count = wp_count_posts(self::CPT); $published = isset($faq_count->publish) ? intval($faq_count->publish) : 0;
        echo '<div class="wrap in3pida-admin in3pida-admin-pro">'; $this->admin_header(); $this->top_actions('settings');
        echo '<form method="post" action="options.php">'; settings_fields('in3pida_faq_settings'); echo '<div class="in3pida-grid">';
        echo '<section class="in3pida-card"><h2>📝 Contenuto pagina</h2><p class="in3pida-card-desc">Qui controlli titolo e testo introduttivo mostrati sopra le FAQ nel frontend.</p><div class="in3pida-fields">';
        $this->field_text('Titolo pagina FAQ', 'page_title', $o['page_title']); $this->field_textarea('Testo sotto il titolo', 'page_intro', $o['page_intro']); echo '</div></section>';
        echo '<section class="in3pida-card"><h2>🎨 Stile grafico</h2><p class="in3pida-card-desc">Imposta i colori principali. Se lasci vuoto il font, il plugin eredita il font del tema.</p><div class="in3pida-fields in3pida-two-cols">';
        $this->field_color('Colore principale', 'primary_color', $o['primary_color'], $o['primary_color_inherit']);
        $this->field_color('Colore dettagli/interazioni', 'accent_color', $o['accent_color'], $o['accent_color_inherit'], 'Controlla dettagli come etichetta FAQ, icona + e micro-interazioni.');
        $this->field_color('Colore testo', 'text_color', $o['text_color'], $o['text_color_inherit']);
        $this->field_color('Sfondo sezione', 'background_color', $o['background_color'], $o['background_color_inherit']);
        $this->field_color('Sfondo box FAQ', 'card_background', $o['card_background'], $o['card_background_inherit']);
        $this->field_number('Raggio angoli', 'border_radius', $o['border_radius'], 'px'); $this->field_text('Font family opzionale', 'font_family', $o['font_family'], 'Vuoto = eredita il font del tema'); $this->field_width($o); echo '</div></section>';
        echo '<section class="in3pida-card"><h2>↕️ Ordinamento FAQ</h2><p class="in3pida-card-desc">Per l\'ordine manuale usa il drag & drop nella lista FAQ. Il salvataggio avviene via AJAX quando sposti le domande.</p><div class="in3pida-fields">';
        echo '<div class="in3pida-field"><label>Ordina FAQ per</label><div class="in3pida-inline"><select name="'.self::OPTION.'[order_by]"><option value="menu_order" '.selected($o['order_by'],'menu_order',false).'>Ordine manuale</option><option value="date" '.selected($o['order_by'],'date',false).'>Data</option><option value="title" '.selected($o['order_by'],'title',false).'>Titolo</option></select> <select name="'.self::OPTION.'[order]"><option value="ASC" '.selected($o['order'],'ASC',false).'>Crescente</option><option value="DESC" '.selected($o['order'],'DESC',false).'>Decrescente</option></select></div></div>';
        echo '<div class="in3pida-note"><strong>FAQ pubblicate:</strong> '.esc_html($published).' &nbsp; <a href="'.esc_url(admin_url('edit.php?post_type=' . self::CPT)).'">Vai alla lista per ordinare</a></div></div></section>';
        echo '<section class="in3pida-card"><h2>⚙️ Comportamento</h2><div class="in3pida-fields"><label class="in3pida-check"><input type="checkbox" name="'.self::OPTION.'[open_first]" value="1" '.checked($o['open_first'],1,false).'> Apri la prima FAQ</label><label class="in3pida-check"><input type="checkbox" name="'.self::OPTION.'[show_kicker]" value="1" '.checked($o['show_kicker'] ?? 1,1,false).'> Mostra etichetta FAQ sopra il titolo</label><label class="in3pida-check"><input type="checkbox" name="'.self::OPTION.'[show_schema]" value="1" '.checked($o['show_schema'],1,false).'> Aggiungi dati strutturati FAQPage per SEO nella pagina FAQ</label></div></section>';
        echo '</div><div class="in3pida-savebar">'; submit_button('Salva impostazioni', 'primary in3pida-save', 'submit', false); echo '<span>Shortcode: <code>[in3pida_faq]</code> oppure <code>[site_faq]</code></span></div></form></div>';
    }

    private function field_text($label,$key,$val,$help='') { echo '<div class="in3pida-field"><label>'.esc_html($label).'</label><input type="text" name="'.self::OPTION.'['.$key.']" value="'.esc_attr($val).'">'.($help?'<p class="in3pida-help">'.esc_html($help).'</p>':'').'</div>'; }
    private function field_textarea($label,$key,$val) { echo '<div class="in3pida-field in3pida-field-full"><label>'.esc_html($label).'</label><textarea rows="4" name="'.self::OPTION.'['.$key.']">'.esc_textarea($val).'</textarea></div>'; }
    private function field_color($label,$key,$val,$inherit=0,$help='') { echo '<div class="in3pida-field"><label>'.esc_html($label).'</label><div><div class="in3pida-inline"><input class="in3pida-color" type="color" name="'.self::OPTION.'['.$key.']" value="'.esc_attr($val).'"><label class="in3pida-mini-check"><input type="checkbox" name="'.self::OPTION.'['.$key.'_inherit]" value="1" '.checked($inherit,1,false).'> Eredita dal sito</label></div>'.($help?'<p class="in3pida-help in3pida-help-local">'.esc_html($help).'</p>':'').'</div></div>'; }
    private function field_number($label,$key,$val,$suffix='') { echo '<div class="in3pida-field"><label>'.esc_html($label).'</label><div class="in3pida-inline"><input type="number" name="'.self::OPTION.'['.$key.']" value="'.esc_attr($val).'"><span>'.esc_html($suffix).'</span></div></div>'; }
    private function field_width($o) { echo '<div class="in3pida-field"><label>Larghezza</label><div><div class="in3pida-inline"><select name="'.self::OPTION.'[max_width_mode]"><option value="site" '.selected($o['max_width_mode'],'site',false).'>Adatta al sito</option><option value="custom" '.selected($o['max_width_mode'],'custom',false).'>Personalizzata</option></select><input type="number" name="'.self::OPTION.'[max_width]" value="'.esc_attr($o['max_width']).'"><span>px</span></div><p class="in3pida-help in3pida-help-local">Adatta al sito = usa la larghezza del contenitore della pagina/tema.</p></div></div>'; }

    public function schema_page() {
        if (!current_user_can('manage_options')) return;
        $o = $this->schema_opts(); $json = $this->build_schema_graph($o); $missing = $this->schema_missing_required($o);
        echo '<div class="wrap in3pida-admin in3pida-admin-pro in3pida-schema-page">'; $this->admin_header(); $this->top_actions('schema');
        if ($missing) echo '<div class="in3pida-note in3pida-alert"><strong>Campi essenziali mancanti:</strong> '.esc_html(implode(', ', $missing)).'</div>';
        echo '<form method="post" action="options.php">'; settings_fields('in3pida_schemaorg_settings_group');
        echo '<div class="in3pida-grid">';
        $this->schema_section_structure($o); $this->schema_section_contacts($o); $this->schema_section_address($o); $this->schema_section_images($o); $this->schema_section_amenities($o); $this->schema_section_audience($o); $this->schema_section_rooms($o); $this->schema_section_offers($o); $this->schema_section_reviews($o); $this->schema_section_faq_source(); $this->schema_section_social($o); $this->schema_section_breadcrumb($o); $this->schema_section_output($o);
        echo '<section class="in3pida-card"><h2>👀 Anteprima JSON-LD</h2><p class="in3pida-card-desc">Anteprima generata dai campi salvati o appena compilati dopo il salvataggio.</p><textarea class="in3pida-json-preview" readonly id="in3pida-json-preview">'.esc_textarea(wp_json_encode($json, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)).'</textarea><p><button type="button" class="in3pida-btn in3pida-copy-json" data-target="in3pida-json-preview">Copia JSON-LD</button></p></section>';
        echo '</div><div class="in3pida-savebar">'; submit_button('Salva Schema.org', 'primary in3pida-save', 'submit', false); echo '<span>I dati sono salvati in <code>in3pida_schemaorg_settings</code>.</span></div></form></div>';
    }

    private function sname($k){ return self::SCHEMA_OPTION.'['.$k.']'; }
    private function input($label,$key,$val,$type='text',$help='') { echo '<div class="in3pida-field"><label>'.esc_html($label).'</label><div><input type="'.esc_attr($type).'" name="'.esc_attr($this->sname($key)).'" value="'.esc_attr($val).'">'.($help?'<p class="in3pida-help in3pida-help-local">'.esc_html($help).'</p>':'').'</div></div>'; }
    private function textarea_s($label,$key,$val,$help='') { echo '<div class="in3pida-field in3pida-field-full"><label>'.esc_html($label).'</label><div><textarea rows="4" name="'.esc_attr($this->sname($key)).'">'.esc_textarea($val).'</textarea>'.($help?'<p class="in3pida-help in3pida-help-local">'.esc_html($help).'</p>':'').'</div></div>'; }
    private function check_s($label,$key,$checked){ echo '<label class="in3pida-check"><input type="checkbox" name="'.esc_attr($this->sname($key)).'" value="1" '.checked($checked,1,false).'> '.esc_html($label).'</label>'; }

    private function logo_media_field($o) {
        $logo_id = absint($o['logo_id'] ?? 0);
        $logo_url = '';
        if ($logo_id) $logo_url = wp_get_attachment_image_url($logo_id, 'full');
        if (!$logo_url) $logo_url = esc_url_raw($o['logo'] ?? '');
        echo '<div class="in3pida-field in3pida-logo-field"><label>Logo</label><div>';
        echo '<div class="in3pida-repeat-row in3pida-logo-row in3pida-logo-control">';
        echo '<input type="hidden" class="in3pida-logo-id" name="'.esc_attr($this->sname('logo_id')).'" value="'.esc_attr($logo_id).'">';
        echo '<input type="text" class="in3pida-logo-url" name="'.esc_attr($this->sname('logo')).'" value="'.esc_attr($logo_url).'" placeholder="URL logo">';
        echo '<button type="button" class="in3pida-media-select-logo in3pida-media-select">Seleziona logo</button>';
        echo '<button type="button" class="in3pida-media-remove-logo">Rimuovi</button>';
        echo '</div>';
        echo '<p class="in3pida-help in3pida-help-local">Seleziona il logo ufficiale dalla Libreria Media. Consigliato: PNG trasparente, almeno 300x300 px.</p>';
        echo '</div></div>';
    }

    private function schema_section_structure($o) {
        $types=['Hotel','Residence','BedAndBreakfast','Resort','Hostel','Campground','VacationRental','ApartmentComplex'];
        echo '<section class="in3pida-card"><h2>🏨 Informazioni struttura</h2><div class="in3pida-fields in3pida-two-cols">';
        echo '<div class="in3pida-field"><label>Tipo struttura *</label><select name="'.esc_attr($this->sname('type')).'">'; foreach($types as $t) echo '<option value="'.esc_attr($t).'" '.selected($o['type'],$t,false).'>'.esc_html($t).'</option>'; echo '</select></div>';
        $this->input('Nome struttura *','name',$o['name']); $this->input('Nome alternativo','alternate_name',$o['alternate_name']); $this->input('URL sito *','url',$o['url'],'url'); $this->logo_media_field($o); $this->input('Slogan','slogan',$o['slogan']); $this->input('Fascia prezzo','price_range',$o['price_range']); $this->input('Stelle / rating ufficiale','official_rating',$o['official_rating']); $this->input('Valuta accettata','currencies_accepted',$o['currencies_accepted']); $this->input('Metodi di pagamento','payment_accepted',$o['payment_accepted']); $this->input('Check-in','checkin_time',$o['checkin_time'],'time'); $this->input('Check-out','checkout_time',$o['checkout_time'],'time'); $this->input('Animali ammessi','pets_allowed',$o['pets_allowed'],'text','Scrivi sì/no e, se serve, una nota breve. Esempio: Sì, animali ammessi su richiesta.');
        echo '</div><div class="in3pida-fields">'; $this->textarea_s('Descrizione AI-oriented *','description',$o['description'],'Scrivi una descrizione concreta della struttura. Consigliato: 400-700 caratteri. Evita frasi generiche e keyword stuffing.'); echo '<div class="in3pida-char-hint" data-target="description">Lunghezza consigliata: 400-700 caratteri.</div></div></section>';
    }
    private function schema_section_contacts($o){ echo '<section class="in3pida-card"><h2>☎️ Contatti</h2><div class="in3pida-fields in3pida-two-cols">'; $this->input('Telefono *','telephone',$o['telephone']); $this->input('Email *','email',$o['email'],'email'); echo '</div></section>'; }
    private function schema_section_address($o){ echo '<section class="in3pida-card"><h2>📍 Indirizzo e geolocalizzazione</h2><div class="in3pida-fields in3pida-two-cols">'; $this->input('Via e numero *','street',$o['street']); $this->input('Città *','city',$o['city']); $this->input('Regione','region',$o['region']); $this->input('CAP','postal_code',$o['postal_code']); $this->input('Paese *','country',$o['country']); $this->input('Latitudine','latitude',$o['latitude'],'text','Da Google Maps: clic destro sul punto della struttura e copia il primo numero. Esempio: 42.8841'); $this->input('Longitudine','longitude',$o['longitude'],'text','Da Google Maps: copia il secondo numero. Esempio: 13.9136'); $this->input('Link Google Maps','map_url',$o['map_url'],'url','Campo opzionale. Incolla il link della scheda Google Maps. Esempio: https://maps.app.goo.gl/xxxxx oppure https://www.google.com/maps/place/Nome+Hotel/...'); echo '</div></section>'; }
    private function schema_section_images($o){ echo '<section class="in3pida-card"><h2>🖼️ Immagini</h2><p class="in3pida-card-desc">Seleziona le immagini direttamente dalla libreria media del sito. Il plugin salva l\'ID allegato quando disponibile e genera dinamicamente l\'URL per lo Schema.org, mantenendo compatibili eventuali URL già salvati.</p>'.$this->repeater_urls('images',$o['images'],'URL immagine', true).'</section>'; }
    private function schema_section_amenities($o){ $list=['Wi-Fi gratuito','Parcheggio','Piscina','Colazione','Ristorante','Bar','Aria condizionata','Camere familiari','Camere non fumatori','Accessibilità per ospiti con disabilità','Ascensore','Reception','Reception 24 ore','Self check-in','Late check-in','Ricarica auto elettriche']; $custom=array_values(array_unique(array_diff((array)$o['amenities'],$list))); echo '<section class="in3pida-card"><h2>✅ Servizi / amenities</h2><p class="in3pida-card-desc">Seleziona i servizi già presenti oppure aggiungi servizi specifici della struttura.</p><div class="in3pida-check-grid">'; foreach($list as $v) echo '<label class="in3pida-check"><input type="checkbox" name="'.esc_attr($this->sname('amenities')).'[]" value="'.esc_attr($v).'" '.checked(in_array($v,$o['amenities'],true),true,false).'> '.esc_html($v).'</label>'; foreach($custom as $v) echo '<label class="in3pida-check in3pida-custom-check"><input type="checkbox" name="'.esc_attr($this->sname('amenities')).'[]" value="'.esc_attr($v).'" checked> '.esc_html($v).'</label>'; echo '</div><div class="in3pida-repeater in3pida-mt" data-name="'.esc_attr($this->sname('amenities')).'" data-kind="textlist">'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi servizi</button></div><div class="in3pida-fields in3pida-two-cols in3pida-mt">'; foreach(['center'=>'Distanza dal centro','attraction'=>'Distanza da attrazione principale','station'=>'Distanza dalla stazione','airport'=>'Distanza dall\'aeroporto'] as $k=>$l) echo '<div class="in3pida-field"><label>'.esc_html($l).'</label><input type="text" name="'.esc_attr(self::SCHEMA_OPTION.'[distances]['.$k.']').'" value="'.esc_attr($o['distances'][$k] ?? '').'"></div>'; echo '</div></section>'; }
    private function schema_section_audience($o){ $targets=['Famiglie','Coppie','Business traveler','Turisti internazionali','Gruppi','Cicloturisti','Digital nomad']; $knows=['Vacanze in famiglia','Weekend romantici','Viaggi business','Turismo locale','Soggiorni con parcheggio','Hotel con colazione','Soggiorni vicino a [attrazione]']; $custom_targets=array_values(array_diff((array)$o['targets'],$targets)); $custom_knows=array_values(array_diff((array)$o['knows_about'],$knows)); echo '<section class="in3pida-card"><h2>🧠 Audience e posizionamento AI</h2><p class="in3pida-card-desc">Questa sezione aiuta motori di ricerca e assistenti AI a capire per chi è adatta la struttura e su quali temi è rilevante.</p><div class="in3pida-fields in3pida-two-cols">'; $this->input('Lingue parlate','languages',$o['languages'],'text','Separate da virgola. Esempio: Italiano, Inglese, Tedesco.'); $this->input('Zone turistiche collegate','area_served',$o['area_served'],'text','Inserisci località e aree turistiche vicine per cui l\'hotel è rilevante. Esempio: Villa Rosa, Martinsicuro, Alba Adriatica, Riviera Adriatica, Abruzzo. Separa ogni voce con una virgola.'); $this->input('Attrazioni vicine','nearby_attractions',$o['nearby_attractions'],'text','Separate da virgola. Esempio: centro storico, stazione, spiaggia, fiera.'); $this->input('Keywords semantiche','keywords',$o['keywords'],'text','Sono parole e frasi che descrivono il contesto della struttura, non solo keyword secche. Inserisci ricerche naturali e temi: hotel per famiglie a Riccione, residence vicino al mare, hotel con parcheggio, weekend romantico. Separate da virgola.'); echo '</div><h3>Target clienti</h3><div class="in3pida-check-grid">'; foreach($targets as $v) echo '<label class="in3pida-check"><input type="checkbox" name="'.esc_attr($this->sname('targets')).'[]" value="'.esc_attr($v).'" '.checked(in_array($v,$o['targets'],true),true,false).'> '.esc_html($v).'</label>'; foreach($custom_targets as $v) echo '<label class="in3pida-check in3pida-custom-check"><input type="checkbox" name="'.esc_attr($this->sname('targets')).'[]" value="'.esc_attr($v).'" checked> '.esc_html($v).'</label>'; echo '</div><div class="in3pida-repeater in3pida-mt" data-name="'.esc_attr($this->sname('targets')).'" data-kind="textlist">'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi target</button></div><h3>KnowsAbout / temi rilevanti</h3><div class="in3pida-check-grid">'; foreach($knows as $v) echo '<label class="in3pida-check"><input type="checkbox" name="'.esc_attr($this->sname('knows_about')).'[]" value="'.esc_attr($v).'" '.checked(in_array($v,$o['knows_about'],true),true,false).'> '.esc_html($v).'</label>'; foreach($custom_knows as $v) echo '<label class="in3pida-check in3pida-custom-check"><input type="checkbox" name="'.esc_attr($this->sname('knows_about')).'[]" value="'.esc_attr($v).'" checked> '.esc_html($v).'</label>'; echo '</div><div class="in3pida-repeater in3pida-mt" data-name="'.esc_attr($this->sname('knows_about')).'" data-kind="textlist">'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi KnowsAbout / tema rilevante</button></div></section>'; }
    private function schema_section_rooms($o){ echo '<section class="in3pida-card in3pida-rooms-card"><h2>🛏️ Camere / appartamenti</h2>'.$this->rooms_repeater($o['rooms']).'</section>'; }
    private function schema_section_offers($o){ echo '<section class="in3pida-card in3pida-offers-card"><h2>💶 Offerte / prenotazione</h2>'.$this->offers_repeater($o['offers']).'</section>'; }
    private function schema_section_reviews($o){ echo '<section class="in3pida-card"><h2>⭐ Recensioni</h2><p class="in3pida-card-desc in3pida-alert-text">Usa solo dati reali e visibili anche nella pagina del sito. Il dato inserito nello Schema.org deve corrispondere a recensioni realmente mostrate agli utenti.</p><div class="in3pida-note"><strong>Rating medio nello Schema.org:</strong> è il punteggio aggregato pubblico che vuoi dichiarare. Se hai fonti diverse, compila Google, Tripadvisor e Booking; poi scegli quale valore usare come rating principale oppure inserisci un aggregato reale visibile sul sito.</div><div class="in3pida-fields in3pida-two-cols">'; $this->input('Fonte rating principale','rating_source',$o['rating_source'],'text','Esempio: Google, Tripadvisor, Booking, oppure Aggregato sito.'); $this->input('Rating medio principale','rating_value',$o['rating_value']); $this->input('Numero recensioni principale','review_count',$o['review_count']); $this->input('Google rating','google_rating',$o['google_rating']); $this->input('Google numero recensioni','google_reviews',$o['google_reviews']); $this->input('Tripadvisor rating','tripadvisor_rating',$o['tripadvisor_rating']); $this->input('Tripadvisor numero recensioni','tripadvisor_reviews',$o['tripadvisor_reviews']); $this->input('Booking rating','booking_rating',$o['booking_rating']); $this->input('Booking numero recensioni','booking_reviews',$o['booking_reviews']); echo '</div></section>'; }
    private function schema_section_faq_source(){ $count = wp_count_posts(self::CPT); $published = isset($count->publish) ? intval($count->publish) : 0; echo '<section class="in3pida-card"><h2>❓ FAQ</h2><p class="in3pida-card-desc">Le FAQ Schema.org vengono prese automaticamente dalla tab <strong>FAQ</strong>. Non devi riscriverle qui: modifica domanda e risposta dalla lista FAQ.</p><div class="in3pida-note"><strong>FAQ pubblicate usate nel JSON-LD:</strong> '.esc_html($published).' &nbsp; <a href="'.esc_url(admin_url('edit.php?post_type=' . self::CPT)).'">Gestisci FAQ</a></div><div class="in3pida-note in3pida-alert"><strong>Nota anti-duplicazione FAQ:</strong> se il sito usa Elementor, Divi, moduli FAQ del tema o altri plugin che generano dati strutturati FAQPage, usa un solo sistema FAQ structured data. Per ottenere score AI coerenti e ridurre duplicazioni Schema, consigliamo di gestire le FAQ strutturate da in3pida FAQ.</div></section>'; }
    private function schema_section_social($o){
        $guided = (array)($o['sameas_guided'] ?? []);
        $fields = [
            'google_business' => 'Google Business Profile / Google Maps',
            'facebook' => 'Facebook',
            'instagram' => 'Instagram',
            'linkedin' => 'LinkedIn',
            'youtube' => 'YouTube',
            'tiktok' => 'TikTok',
            'tripadvisor' => 'Tripadvisor',
            'booking' => 'Booking',
            'wikidata' => 'Wikidata',
            'crunchbase' => 'Crunchbase',
            'github' => 'GitHub',
            'trustpilot' => 'Trustpilot',
        ];
        echo '<section class="in3pida-card"><h2>🔗 Social e profili esterni</h2><p class="in3pida-card-desc">Compila i profili ufficiali: il plugin li inserisce automaticamente nel <code>sameAs</code> dello Schema.org e li usa per calcolare l\'Entity Authority score.</p><div class="in3pida-fields in3pida-two-cols">';
        foreach($fields as $key=>$label){
            echo '<div class="in3pida-field"><label>'.esc_html($label).'</label><input type="url" name="'.esc_attr(self::SCHEMA_OPTION.'[sameas_guided]['.$key.']').'" value="'.esc_attr($guided[$key] ?? '').'" placeholder="https://"></div>';
        }
        echo '</div><h3>Altri link custom</h3>'.$this->repeater_urls('sameas',$o['sameas'],'URL profilo custom').'</section>';
    }
    private function schema_section_breadcrumb($o){ echo '<section class="in3pida-card"><h2>🍞 Breadcrumb</h2><p class="in3pida-card-desc">Il breadcrumb serve a indicare il percorso principale della pagina più importante della struttura. Non devi inserire tutte le pagine del sito, né le pagine più cercate. Inserisci solo il percorso logico che porta alla pagina hotel o alla pagina camere. Esempio: Home → Hotel Hawaii oppure Home → Camere → Camera Family.</p><div class="in3pida-note"><strong>Cosa inserire:</strong> di solito basta Home + pagina principale della struttura. Aggiungi altri livelli solo se hai una gerarchia reale, ad esempio Home → Camere → Camera Deluxe. Se non sai cosa mettere, lascia solo Home e la pagina principale.</div>'.$this->breadcrumb_repeater($o['breadcrumbs']).'</section>'; }
    private function schema_section_output($o){ echo '<section class="in3pida-card"><h2>⚙️ Dati strutturati Google & AI</h2><p class="in3pida-card-desc">Il plugin pubblica automaticamente i dati strutturati Schema.org usati da Google e dai sistemi AI per capire struttura, servizi e FAQ.</p><div class="in3pida-fields">'; $this->check_s('Abilita Schema.org','enabled',$o['enabled']); echo '<div class="in3pida-note"><strong>Impostazione consigliata:</strong> lascia attivo Schema.org e lascia le opzioni avanzate così come sono, salvo esigenze tecniche particolari.</div>'; echo '<details class="in3pida-advanced"><summary>Impostazioni avanzate</summary><div class="in3pida-fields in3pida-mt">'; $this->check_s('Mostra JSON-LD solo se i campi obbligatori sono compilati','only_if_required',$o['only_if_required']); $this->check_s('Evita conflitti Schema con plugin SEO compatibili','disable_external_schema',$o['disable_external_schema']); echo '<div class="in3pida-note"><strong>Opzione avanzata:</strong> se attiva, il plugin prova a disabilitare lo Schema generato da Yoast, RankMath e AIOSEO solo quando lo Schema.org in3pida è attivo.</div>'; $this->check_s('Genera WebSite','include_website',$o['include_website']); $this->check_s('Genera FAQPage se sono presenti FAQ','include_faq',$o['include_faq']); $this->check_s('Genera BreadcrumbList se compilato','include_breadcrumb',$o['include_breadcrumb']); echo '<div class="in3pida-field"><label>Dove mostrarlo</label><select name="'.esc_attr($this->sname('output_scope')).'"><option value="home" '.selected($o['output_scope'],'home',false).'>Solo homepage</option><option value="all" '.selected($o['output_scope'],'all',false).'>Tutto il sito</option><option value="pages" '.selected($o['output_scope'],'pages',false).'>Solo pagine selezionate</option></select></div>'; $this->input('ID pagine selezionate','selected_pages',$o['selected_pages'],'text','Inserisci ID pagina separati da virgola.'); echo '</div></details></div></section>'; }

    private function repeater_urls($key,$rows,$placeholder,$media=false){
        ob_start();
        echo '<div class="in3pida-repeater" data-name="'.esc_attr(self::SCHEMA_OPTION.'['.$key.']').'" data-kind="url" data-media="'.($media?'1':'0').'">';
        if (!$rows) $rows=[['url'=>'']];
        foreach($rows as $i=>$r) {
            $id = $media ? absint($r['id'] ?? 0) : 0;
            $url = $media ? $this->image_row_url($r) : (is_array($r) ? ($r['url'] ?? '') : '');
            echo '<div class="in3pida-repeat-row">';
            if($media) {
                $legacy_url_value = $id ? '' : $url;
                echo '<input type="hidden" class="in3pida-media-id" name="'.esc_attr(self::SCHEMA_OPTION.'['.$key.']['.$i.'][id]').'" value="'.esc_attr($id).'">';
                echo '<input type="hidden" class="in3pida-media-url" name="'.esc_attr(self::SCHEMA_OPTION.'['.$key.']['.$i.'][url]').'" value="'.esc_attr($legacy_url_value).'">';
                echo '<input type="text" class="in3pida-media-preview" value="'.esc_attr($url).'" placeholder="'.esc_attr($placeholder).'">';
                echo '<button type="button" class="in3pida-media-select">Seleziona immagine</button>';
            } else {
                echo '<input type="url" name="'.esc_attr(self::SCHEMA_OPTION.'['.$key.']['.$i.'][url]').'" value="'.esc_attr($url).'" placeholder="'.esc_attr($placeholder).'">';
            }
            echo '<button type="button" class="in3pida-remove">Rimuovi</button></div>';
        }
        echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi</button></div>';
        return ob_get_clean();
    }
    private function faq_repeater($rows){ ob_start(); echo '<div class="in3pida-repeater" data-name="'.esc_attr(self::SCHEMA_OPTION.'[faqs]').'" data-kind="faq">'; if(!$rows)$rows=[['question'=>'','answer'=>'']]; foreach($rows as $i=>$r) echo '<div class="in3pida-repeat-box"><input type="text" name="'.esc_attr(self::SCHEMA_OPTION.'[faqs]['.$i.'][question]').'" value="'.esc_attr($r['question'] ?? '').'" placeholder="Domanda"><textarea name="'.esc_attr(self::SCHEMA_OPTION.'[faqs]['.$i.'][answer]').'" placeholder="Risposta">'.esc_textarea($r['answer'] ?? '').'</textarea><button type="button" class="in3pida-remove">Rimuovi</button></div>'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi FAQ</button></div>'; return ob_get_clean(); }
    private function breadcrumb_repeater($rows){ ob_start(); echo '<div class="in3pida-repeater" data-name="'.esc_attr(self::SCHEMA_OPTION.'[breadcrumbs]').'" data-kind="breadcrumb">'; if(!$rows)$rows=[['name'=>'Home','url'=>home_url('/')]]; foreach($rows as $i=>$r) echo '<div class="in3pida-repeat-row in3pida-repeat-two"><input type="text" name="'.esc_attr(self::SCHEMA_OPTION.'[breadcrumbs]['.$i.'][name]').'" value="'.esc_attr($r['name'] ?? '').'" placeholder="Nome livello"><input type="url" name="'.esc_attr(self::SCHEMA_OPTION.'[breadcrumbs]['.$i.'][url]').'" value="'.esc_attr($r['url'] ?? '').'" placeholder="URL livello"><button type="button" class="in3pida-remove">Rimuovi</button></div>'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi livello</button></div>'; return ob_get_clean(); }
    private function offers_repeater($rows){ ob_start(); echo '<div class="in3pida-repeater" data-name="'.esc_attr(self::SCHEMA_OPTION.'[offers]').'" data-kind="offer">'; if(!$rows)$rows=[[]]; foreach($rows as $i=>$r) echo '<div class="in3pida-repeat-box"><input name="'.esc_attr(self::SCHEMA_OPTION.'[offers]['.$i.'][url]').'" value="'.esc_attr($r['url'] ?? '').'" placeholder="URL prenotazione"><input name="'.esc_attr(self::SCHEMA_OPTION.'[offers]['.$i.'][name]').'" value="'.esc_attr($r['name'] ?? '').'" placeholder="Nome offerta/servizio"><textarea name="'.esc_attr(self::SCHEMA_OPTION.'[offers]['.$i.'][description]').'" placeholder="Descrizione offerta">'.esc_textarea($r['description'] ?? '').'</textarea><input name="'.esc_attr(self::SCHEMA_OPTION.'[offers]['.$i.'][price]').'" value="'.esc_attr($r['price'] ?? '').'" placeholder="Prezzo da"><input name="'.esc_attr(self::SCHEMA_OPTION.'[offers]['.$i.'][currency]').'" value="'.esc_attr($r['currency'] ?? 'EUR').'" placeholder="Valuta"><button type="button" class="in3pida-remove">Rimuovi</button></div>'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi offerta</button></div>'; return ob_get_clean(); }
    private function rooms_repeater($rows){ $amen=['Bagno privato','Aria condizionata','Wi-Fi','TV','Minibar','Balcone','Cucina','Frigorifero','Accessibile']; ob_start(); echo '<div class="in3pida-repeater" data-name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]').'" data-kind="room">'; if(!$rows)$rows=[[]]; foreach($rows as $i=>$r){ $room_amen=(array)($r['amenities'] ?? []); $custom=array_values(array_filter(array_diff($room_amen,$amen), function($item){ return trim((string)$item) !== ''; })); echo '<div class="in3pida-repeat-box in3pida-room-box"><div class="in3pida-room-name-url-row"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][name]').'" value="'.esc_attr($r['name'] ?? '').'" placeholder="Nome camera"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][url]').'" value="'.esc_attr($r['url'] ?? '').'" placeholder="URL pagina camera"></div><textarea name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][description]').'" placeholder="Descrizione AI-oriented" style="width:100%;max-width:100%">'.esc_textarea($r['description'] ?? '').'</textarea><div class="in3pida-repeat-grid"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][min]').'" value="'.esc_attr($r['min'] ?? '').'" placeholder="Capienza min"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][max]').'" value="'.esc_attr($r['max'] ?? '').'" placeholder="Capienza max"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][bed]').'" value="'.esc_attr($r['bed'] ?? '').'" placeholder="Tipo letto"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][price]').'" value="'.esc_attr($r['price'] ?? '').'" placeholder="Prezzo da"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][currency]').'" value="'.esc_attr($r['currency'] ?? 'EUR').'" placeholder="Valuta"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][availability]').'" value="'.esc_attr($r['availability'] ?? '').'" placeholder="Disponibilità / note"><input name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][view]').'" value="'.esc_attr($r['view'] ?? '').'" placeholder="Vista"></div><h4>Servizi camera</h4><div class="in3pida-check-grid in3pida-room-amenities">'; foreach($amen as $a) echo '<label class="in3pida-check"><input type="checkbox" name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][amenities][]').'" value="'.esc_attr($a).'" '.checked(in_array($a,$room_amen,true),true,false).'> '.esc_html($a).'</label>'; foreach($custom as $v) echo '<label class="in3pida-check in3pida-custom-check"><input type="checkbox" name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][amenities][]').'" value="'.esc_attr($v).'" checked> '.esc_html($v).'</label>'; echo '</div><div class="in3pida-repeater in3pida-room-service-repeater in3pida-mt" data-name="'.esc_attr(self::SCHEMA_OPTION.'[rooms]['.$i.'][amenities]').'" data-kind="textlist">'; echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi servizio camera</button></div><button type="button" class="in3pida-remove in3pida-remove-room">Rimuovi camera/appartamento</button></div>'; } echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi camera/appartamento</button></div>'; return ob_get_clean(); }


    private function csv_items($value) {
        $parts = preg_split('/[,\n]+/', (string) $value);
        $out = [];
        foreach ((array) $parts as $part) {
            $part = trim(wp_strip_all_tags($part));
            if ($part !== '') $out[] = $part;
        }
        return array_values(array_unique($out));
    }

    private function schema_missing_required($o) {
        $missing = [];
        // Only name and url are truly required to output a valid Hotel JSON-LD
        if (empty($o['name'])) $missing[] = 'Nome struttura';
        if (empty($o['url']))  $missing[] = 'URL sito';
        return $missing;
    }

    private function site_id_base($url){ $base = trailingslashit($url ?: home_url('/')); return $base; }
    public function build_schema_graph($o=null){ $o=$o?:$this->schema_opts(); $base=$this->site_id_base($o['url']); $hotel_id=$base.'#hotel'; $images=array_values(array_filter(array_map(function($r){ return $this->image_row_url($r); }, (array)$o['images']))); $same_custom=array_values(array_filter(array_map(function($r){ return is_array($r) ? ($r['url'] ?? '') : ''; }, (array)$o['sameas']))); $same_guided=array_values(array_filter((array)($o['sameas_guided'] ?? []))); $same=array_values(array_unique(array_merge($same_guided,$same_custom))); $hotel=['@type'=>$o['type'],'@id'=>$hotel_id];
        foreach(['name','alternateName'=>'alternate_name','description','url','logo','telephone','email','priceRange'=>'price_range','currenciesAccepted'=>'currencies_accepted','paymentAccepted'=>'payment_accepted','checkinTime'=>'checkin_time','checkoutTime'=>'checkout_time','petsAllowed'=>'pets_allowed','slogan','keywords'] as $schemaK=>$optK){ if(is_int($schemaK)){$schemaK=$optK;} if(!empty($o[$optK])) $hotel[$schemaK]=$o[$optK]; }
        if($images) $hotel['image']=$images; if(!empty($o['languages'])) $hotel['availableLanguage']=$this->csv_items($o['languages']); if(!empty($o['area_served'])) $hotel['areaServed']=array_map(function($v){ return ['@type'=>'Place','name'=>$v]; }, $this->csv_items($o['area_served'])); if(!empty($o['nearby_attractions'])) $hotel['areaServed']=array_merge($hotel['areaServed']??[],array_map(function($v){ return ['@type'=>'Place','name'=>$v]; }, $this->csv_items($o['nearby_attractions']))); if(!empty($o['knows_about'])) $hotel['knowsAbout']=$o['knows_about']; if(!empty($o['targets'])) $hotel['audience']=array_map(function($v){ return ['@type'=>'Audience','audienceType'=>$v]; }, $o['targets']); if(!empty($o['official_rating'])) $hotel['starRating']=['@type'=>'Rating','ratingValue'=>$o['official_rating']];
        if($o['street']||$o['city']||$o['country']) $hotel['address']=['@type'=>'PostalAddress','streetAddress'=>$o['street'],'addressLocality'=>$o['city'],'addressRegion'=>$o['region'],'postalCode'=>$o['postal_code'],'addressCountry'=>$o['country']]; if($o['latitude']||$o['longitude']) $hotel['geo']=['@type'=>'GeoCoordinates','latitude'=>$o['latitude'],'longitude'=>$o['longitude']]; if($o['map_url']) $hotel['hasMap']=$o['map_url']; if($same) $hotel['sameAs']=$same;
        $amen=[]; foreach(array_unique((array)$o['amenities']) as $a) $amen[]=['@type'=>'LocationFeatureSpecification','name'=>$a,'value'=>true]; foreach((array)$o['distances'] as $k=>$v) if($v) $amen[]=['@type'=>'LocationFeatureSpecification','name'=>ucfirst(str_replace('_',' ',$k)),'value'=>$v]; if($amen) $hotel['amenityFeature']=$amen;
        $rooms=[]; foreach((array)$o['rooms'] as $r){ if(empty($r['name'])) continue; $room=['@type'=>'HotelRoom','name'=>$r['name']]; if(!empty($r['url'])) $room['@id']=$r['url'].'#room'; if(!empty($r['description'])) $room['description']=$r['description']; if(!empty($r['min'])||!empty($r['max'])) $room['occupancy']=['@type'=>'QuantitativeValue','minValue'=>absint($r['min']??0),'maxValue'=>absint($r['max']??0)]; if(!empty($r['bed'])) $room['bed']=['@type'=>'BedDetails','typeOfBed'=>$r['bed']]; $ra=[]; foreach((array)($r['amenities']??[]) as $a) $ra[]=['@type'=>'LocationFeatureSpecification','name'=>$a,'value'=>true]; if(!empty($r['view'])) $ra[]=['@type'=>'LocationFeatureSpecification','name'=>'Vista','value'=>$r['view']]; if($ra) $room['amenityFeature']=$ra; if(!empty($r['price'])||!empty($r['url'])){ $room_offer=['@type'=>'Offer','url'=>$r['url']??'','priceCurrency'=>$r['currency']?:$o['currencies_accepted'],'price'=>$r['price']??'']; if(!empty($r['availability'])) $room_offer['availability']=$r['availability']; $room['offers']=$room_offer; } $rooms[]=$room; } if($rooms) $hotel['containsPlace']=$rooms;
        $offers=[]; foreach((array)$o['offers'] as $of){ if(empty($of['url'])&&empty($of['name'])) continue; $offers[]=['@type'=>'Offer','url'=>$of['url']??'','priceCurrency'=>$of['currency']?:$o['currencies_accepted'],'price'=>$of['price']??'','itemOffered'=>['@type'=>'Service','name'=>$of['name']??'Prenotazione','description'=>$of['description']??'']]; } if(count($offers)===1)$hotel['makesOffer']=$offers[0]; elseif($offers)$hotel['makesOffer']=$offers;
        if($o['rating_value']&&$o['review_count']) $hotel['aggregateRating']=['@type'=>'AggregateRating','ratingValue'=>$o['rating_value'],'reviewCount'=>$o['review_count']];
        $graph=[$hotel]; if(!empty($o['include_website'])) $graph[]=['@type'=>'WebSite','@id'=>$base.'#website','url'=>$base,'name'=>$o['name'],'description'=>$o['description'],'inLanguage'=>get_locale(),'publisher'=>['@id'=>$hotel_id],'potentialAction'=>['@type'=>'SearchAction','target'=>$base.'?s={search_term_string}','query-input'=>'required name=search_term_string']];
        if(!empty($o['include_faq'])){ $ents=[]; $faq_posts=get_posts(['post_type'=>self::CPT,'post_status'=>'publish','numberposts'=>-1,'orderby'=>'menu_order','order'=>'ASC']); foreach($faq_posts as $fp){ $q=get_the_title($fp); $a=wp_strip_all_tags(apply_filters('the_content',$fp->post_content)); if($q && $a) $ents[]=['@type'=>'Question','name'=>$q,'acceptedAnswer'=>['@type'=>'Answer','text'=>$a]]; } if($ents)$graph[]=['@type'=>'FAQPage','@id'=>$base.'#faq','mainEntity'=>$ents]; }
        if(!empty($o['include_breadcrumb'])&&!empty($o['breadcrumbs'])){ $els=[]; $p=1; foreach($o['breadcrumbs'] as $b) if(!empty($b['name'])&&!empty($b['url'])) $els[]=['@type'=>'ListItem','position'=>$p++,'name'=>$b['name'],'item'=>$b['url']]; if($els)$graph[]=['@type'=>'BreadcrumbList','@id'=>$base.'#breadcrumb','itemListElement'=>$els]; }
        return ['@context'=>'https://schema.org','@graph'=>$graph]; }

    public function schemaorg_output(){ $o=$this->schema_opts(); if(empty($o['enabled'])) return; if(!empty($o['only_if_required']) && $this->schema_missing_required($o)) return; if(!$this->schema_should_output($o)) return; echo "\n<script type=\"application/ld+json\">".wp_json_encode($this->build_schema_graph($o), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."</script>\n"; }
    private function schema_should_output($o){ if($o['output_scope']==='all') return true; if($o['output_scope']==='home') return is_front_page() || is_home(); if($o['output_scope']==='pages'){ $ids=array_filter(array_map('absint',explode(',',(string)$o['selected_pages']))); return is_page($ids); } return false; }


    private function cc_get_channels(){
        $channels = get_option(self::CC_CHANNELS_OPTION, []);
        return is_array($channels) ? $channels : [];
    }
    private function cc_get_report(){
        $report = get_option(self::CC_REPORT_OPTION, []);
        return is_array($report) ? $report : [];
    }
    private function cc_channel_types(){
        return ['Sito ufficiale','Pagina camere','Pagina servizi','Pagina contatti','Facebook','Instagram','LinkedIn','Bing Places','Hotels.com','Venere.com','Agoda','Consorzio / Associazione','Portale regionale turismo','Blog / Stampa','Sito partner','Booking','Tripadvisor','Google Business Profile','Expedia','Airbnb','Altro'];
    }
    private function cc_manual_only_types(){
        return ['Booking','Tripadvisor','Google Business Profile','Expedia','Airbnb'];
    }
    private function cc_official_site_types(){
        return ['Sito ufficiale','Pagina camere','Pagina servizi','Pagina contatti'];
    }
    private function cc_official_summary($schema){
        $faq_count = wp_count_posts(self::CPT); $published = isset($faq_count->publish) ? intval($faq_count->publish) : 0;
        return [
            'configured' => !empty($schema['name']) && !empty($schema['url']) && !empty($schema['description']),
            'name' => $schema['name'] ?? '',
            'url' => $schema['url'] ?? '',
            'amenities' => count((array)($schema['amenities'] ?? [])),
            'faqs' => $published,
        ];
    }


    private function llm_get_faq_items(){
        $items = [];
        $posts = get_posts(['post_type'=>self::CPT,'post_status'=>'publish','numberposts'=>-1,'orderby'=>'menu_order','order'=>'ASC']);
        foreach($posts as $post){
            $question = wp_strip_all_tags(get_the_title($post));
            $answer = wp_trim_words(wp_strip_all_tags(apply_filters('the_content', $post->post_content)), 36, '...');
            if($question) $items[] = ['question'=>$question,'answer'=>$answer];
        }
        return $items;
    }

    private function llm_csv_items($value, $limit=8){
        $items = $this->csv_items($value);
        return array_slice(array_values(array_filter(array_map('trim', $items))), 0, $limit);
    }

    private function entity_authority_score($schema=null){
        $schema = $schema ?: $this->schema_opts();
        $guided = array_filter((array)($schema['sameas_guided'] ?? []));
        $custom = array_filter(array_map(function($r){ return is_array($r) ? ($r['url'] ?? '') : ''; }, (array)($schema['sameas'] ?? [])));
        $all = array_values(array_unique(array_filter(array_merge(array_values($guided), $custom))));
        $score = 0; $signals = [];
        $count = count($all);
        $score += min(35, $count * 5);
        $signals[] = ['label'=>'Profili sameAs compilati','value'=>$count, 'status'=>$count ? 'ok' : 'mancante'];
        $important = ['google_business'=>'Google Business/Maps','facebook'=>'Facebook','instagram'=>'Instagram','linkedin'=>'LinkedIn','youtube'=>'YouTube','tripadvisor'=>'Tripadvisor','booking'=>'Booking','wikidata'=>'Wikidata'];
        $important_count = 0;
        foreach($important as $key=>$label){ if(!empty($guided[$key])) $important_count++; }
        $score += min(30, $important_count * 4);
        $signals[] = ['label'=>'Profili autorevoli guidati','value'=>$important_count.'/'.count($important), 'status'=>$important_count ? 'ok' : 'mancante'];
        $identity = 0;
        foreach(['name','url','telephone','email','street','city','country'] as $k){ if(!empty($schema[$k])) $identity++; }
        $score += min(25, $identity * 4);
        $signals[] = ['label'=>'Dati identità completati','value'=>$identity.'/7', 'status'=>$identity >= 5 ? 'ok' : 'attenzione'];
        $report = $this->cc_get_report();
        if(!empty($report) && isset($report['score'])){ $score += min(10, max(0, intval($report['score'])) / 10); $signals[]=['label'=>'Coerenza contenuti','value'=>intval($report['score']).'/100','status'=>intval($report['score'])>=70?'ok':'attenzione']; }
        else { $signals[]=['label'=>'Coerenza contenuti','value'=>'Report non disponibile','status'=>'neutro']; }
        // FAQ count contributes to entity authority (published content = authoritative knowledge)
        $faq_ids = get_posts(['post_type'=>self::CPT,'post_status'=>'publish','numberposts'=>-1,'fields'=>'ids']);
        $faq_count = count($faq_ids);
        $faq_pts = min(10, $faq_count * 2);
        $score += $faq_pts;
        $signals[] = ['label'=>'FAQ pubblicate','value'=>$faq_count,'status'=>$faq_count>=5?'ok':($faq_count>0?'attenzione':'mancante')];
        // AI Profile active (structured knowledge publicly accessible)
        if(!empty($this->retrieval_is_enabled())) { $score += 5; $signals[] = ['label'=>'AI Profile attivo','value'=>'Sì','status'=>'ok']; }
        $score = max(0, min(100, (int)round($score)));
        $missing = [];
        foreach($important as $key=>$label){ if(empty($guided[$key])) $missing[] = $label; }
        return ['score'=>$score,'profiles'=>$all,'signals'=>$signals,'missing'=>$missing];
    }



    private function llm_quality_last_updated($schema, $faq_items, $report){
        $payload = [
            'schema' => $schema,
            'faq' => $faq_items,
            'report' => $report,
        ];
        $hash = md5(wp_json_encode($payload));
        $state = get_option(self::LLM_QUALITY_OPTION, []);
        if(!is_array($state)) $state = [];
        if(empty($state['content_hash']) || $state['content_hash'] !== $hash || empty($state['updated_at'])){
            $state['content_hash'] = $hash;
            $state['updated_at'] = current_time('Y-m-d H:i');
            update_option(self::LLM_QUALITY_OPTION, $state, false);
        }
        return $state['updated_at'];
    }

    private function llm_schema_validator($schema){
        $checks = [];
        $required = [
            'name' => 'Nome struttura',
            'description' => 'Descrizione',
            'url' => 'URL sito ufficiale',
            'telephone' => 'Telefono',
            'email' => 'Email',
            'street' => 'Indirizzo',
            'city' => 'Città',
            'country' => 'Paese',
        ];
        foreach($required as $key=>$label){
            $checks[] = [
                'label' => $label,
                'status' => !empty($schema[$key]) ? 'ok' : 'attenzione',
                'message' => !empty($schema[$key]) ? 'Compilato.' : 'Campo consigliato mancante in Schema.org.',
            ];
        }
        if(empty($schema['amenities'])) $checks[] = ['label'=>'Servizi', 'status'=>'attenzione', 'message'=>'Aggiungi almeno alcuni servizi principali.'];
        if(empty($schema['price_range']) && empty($schema['offers'])) $checks[] = ['label'=>'Prezzi/offerte', 'status'=>'neutro', 'message'=>'Se usi prezzi o offerte pubbliche, compila priceRange o offerte.'];
        if(!empty($schema['rating_value']) && empty($schema['review_count'])) $checks[] = ['label'=>'Rating recensioni', 'status'=>'attenzione', 'message'=>'Hai inserito un rating ma manca il numero recensioni.'];
        return $checks;
    }

    private function llm_entity_consistency_check($schema, $faq_items){
        $warnings = [];
        $schema_name = trim((string)($schema['name'] ?? ''));
        $schema_city = trim((string)($schema['city'] ?? ''));
        $schema_price = trim((string)($schema['price_range'] ?? ''));
        $faq_text = '';
        foreach((array)$faq_items as $faq){
            $faq_text .= ' '.wp_strip_all_tags(($faq['question'] ?? '').' '.($faq['answer'] ?? ''));
        }
        $faq_text_l = function_exists('mb_strtolower') ? mb_strtolower($faq_text) : strtolower($faq_text);
        if($schema_name !== ''){
            $name_l = function_exists('mb_strtolower') ? mb_strtolower($schema_name) : strtolower($schema_name);
            if($faq_text_l !== '' && strpos($faq_text_l, $name_l) === false){
                $warnings[] = 'Il nome struttura non compare nelle FAQ: non è un errore, ma può ridurre la coerenza entity.';
            }
        }
        if($schema_city !== ''){
            $city_l = function_exists('mb_strtolower') ? mb_strtolower($schema_city) : strtolower($schema_city);
            if($faq_text_l !== '' && strpos($faq_text_l, $city_l) === false){
                $warnings[] = 'La località Schema.org non compare nelle FAQ: valuta se aggiungerla quando rilevante.';
            }
        }
        if($schema_price !== ''){
            $price_l = function_exists('mb_strtolower') ? mb_strtolower($schema_price) : strtolower($schema_price);
            $has_price_topic = preg_match('/prezz|tariff|costo|cost|€|euro/i', $faq_text);
            if($has_price_topic && strpos($faq_text_l, $price_l) === false){
                $warnings[] = 'Le FAQ parlano di prezzi/tariffe ma non riportano la stessa fascia prezzo di Schema.org.';
            }
        }
        return $warnings;
    }

    private function llm_quality_layer($layer, $schema, $faq_items){
        $schema_checks = $this->llm_schema_validator($schema);
        $schema_ok = 0;
        foreach($schema_checks as $check){ if(($check['status'] ?? '') === 'ok') $schema_ok++; }
        $consistency_warnings = $this->llm_entity_consistency_check($schema, $faq_items);
        $duplicate_safety = [
            'status' => 'ok',
            'message' => 'Knowledge index impostato in modo conservativo: noindex, follow. I file Markdown restano export AI-readable e non modificano le pagine principali del sito.',
        ];
        $score = 60;
        $score += min(25, $schema_ok * 3);
        $score -= min(20, count($consistency_warnings) * 5);
        if(!empty($layer['citation_friendly'])) $score += 5;
        if(!empty($layer['answer_extraction']['score'])) $score += min(10, intval($layer['answer_extraction']['score']) / 10);
        $score = max(0, min(100, (int)round($score)));
        return [
            'score' => $score,
            'schema_checks' => $schema_checks,
            'consistency_warnings' => $consistency_warnings,
            'duplicate_safety' => $duplicate_safety,
            'updated_at' => $layer['updated_at'] ?? '',
        ];
    }

    private function llm_ai_readiness_score($layer){
        $qs = $layer['quality_safety'] ?? [];
        $ae = $layer['answer_extraction'] ?? [];
        $warnings = [];

        $text_blob = wp_strip_all_tags(
            (string)($layer['name'] ?? '').' '.
            (string)($layer['summary_short'] ?? '').' '.
            (string)($layer['summary_extended'] ?? '')
        );
        foreach((array)($layer['faqs'] ?? []) as $faq){
            $text_blob .= ' '.wp_strip_all_tags((string)($faq['question'] ?? '').' '.(string)($faq['answer'] ?? ''));
        }
        foreach((array)($layer['semantic_sections'] ?? []) as $section){
            $text_blob .= ' '.wp_strip_all_tags((string)($section['title'] ?? ''));
            foreach((array)($section['items'] ?? []) as $item){ if(is_scalar($item)) $text_blob .= ' '.wp_strip_all_tags((string)$item); }
        }
        $text_len = function_exists('mb_strlen') ? mb_strlen(trim($text_blob)) : strlen(trim($text_blob));
        $text_l = function_exists('mb_strtolower') ? mb_strtolower($text_blob) : strtolower($text_blob);
        $placeholder_hits = 0;
        foreach(['test','demo','prova','lorem ipsum','placeholder','esempio','ciao mondo','hello world'] as $needle){
            if(strpos($text_l, $needle) !== false) $placeholder_hits++;
        }

        $schema_checks = (array)($qs['schema_checks'] ?? []);
        $schema_ok = 0;
        foreach($schema_checks as $check){ if(($check['status'] ?? '') === 'ok') $schema_ok++; }
        $structured = $schema_checks ? (int)round(($schema_ok / max(1, count($schema_checks))) * 100) : 20;

        $faq_count = count((array)($layer['faqs'] ?? []));
        $direct_faq = 0;
        foreach((array)($layer['faqs'] ?? []) as $faq){
            $q = trim((string)($faq['question'] ?? ''));
            $a = trim(wp_strip_all_tags((string)($faq['answer'] ?? '')));
            $len = function_exists('mb_strlen') ? mb_strlen($a) : strlen($a);
            if($q !== '' && $a !== '' && $len >= 40 && $len <= 500) $direct_faq++;
        }

        $content = 0;
        if($text_len >= 400) $content += 15;
        if($text_len >= 1200) $content += 15;
        if($text_len >= 2500) $content += 10;
        if($faq_count >= 3) $content += 15; elseif($faq_count > 0) $content += 7;
        if($direct_faq >= 3) $content += 15; elseif($direct_faq > 0) $content += 7;
        if(!empty($layer['semantic_sections'])) $content += 10;
        if(count((array)($layer['key_facts'] ?? [])) >= 6) $content += 10; elseif(!empty($layer['key_facts'])) $content += 4;
        if(!empty($layer['citation_friendly']['tables']) || !empty($layer['citation_friendly']['definitions'])) $content += 10;
        $content = min(100, $content);

        $retrieval = 0;
        if(!empty($layer['summary_short'])) $retrieval += 10;
        if(!empty($layer['summary_extended'])) $retrieval += 10;
        if(!empty($layer['key_facts'])) $retrieval += 15;
        if(!empty($layer['semantic_sections'])) $retrieval += 15;
        if(!empty($layer['faqs'])) $retrieval += 15;
        if(!empty($layer['citation_friendly'])) $retrieval += 15;
        if(!empty($layer['citation_friendly']['tables'])) $retrieval += 10;
        if(!empty($layer['citation_friendly']['definitions']) || !empty($layer['citation_friendly']['glossary'])) $retrieval += 10;
        $retrieval = min(100, $retrieval);

        $answer = intval($ae['score'] ?? 0);
        if($faq_count < 2) $answer = min($answer, 55);
        if($text_len < 600) $answer = min($answer, 50);

        $consistency_penalty = min(40, count((array)($qs['consistency_warnings'] ?? [])) * 10);
        $consistency = max(0, 100 - $consistency_penalty);
        if(count((array)($layer['key_facts'] ?? [])) < 5) $consistency = min($consistency, 65);

        if($placeholder_hits > 0){
            $content = max(0, $content - min(35, $placeholder_hits * 12));
            $retrieval = max(0, $retrieval - min(25, $placeholder_hits * 8));
            $answer = max(0, $answer - min(25, $placeholder_hits * 8));
            $warnings[] = 'Rilevati contenuti test/demo o placeholder: lo score viene abbassato finché non inserisci dati reali.';
        }
        if($text_len < 600){
            $content = min($content, 45);
            $retrieval = min($retrieval, 60);
            $warnings[] = 'Contenuti reali ancora scarsi: aggiungi descrizione, servizi e FAQ complete.';
        }
        if($schema_ok < 5){
            $structured = min($structured, 55);
            $consistency = min($consistency, 60);
            $warnings[] = 'Schema.org incompleto: completa almeno nome, descrizione, contatti, indirizzo e località.';
        }
        if($faq_count < 3){
            $warnings[] = 'Aggiungi almeno 3 FAQ reali con risposte dirette per rendere più credibile l\'answer extraction.';
        }

        $score = (int)round(($structured * 0.25) + ($content * 0.30) + ($retrieval * 0.20) + ($answer * 0.15) + ($consistency * 0.10));
        $score = max(0, min(100, $score));
        if($text_len < 600 || $placeholder_hits > 0) $score = min($score, 60);
        if($schema_ok < 5 && $faq_count < 3) $score = min($score, 62);

        if($structured < 70) $warnings[] = 'Completa i campi Schema.org principali per migliorare i dati strutturati.';
        if($content < 70) $warnings[] = 'Lo score ora pesa la qualità reale dei contenuti, non solo le funzioni attive del plugin.';
        if($retrieval < 70) $warnings[] = 'Aggiungi FAQ, key facts o blocchi semantici per migliorare il retrieval AI.';
        if($answer < 70) $warnings[] = 'Rendi le risposte più dirette e concise nei primi paragrafi.';
        foreach((array)($qs['consistency_warnings'] ?? []) as $warn) $warnings[] = $warn;
        if(empty($warnings)) $warnings[] = 'Il sito ha una buona preparazione tecnica e contenutistica per lettura AI, retrieval e answer extraction.';
        return [
            'score'=>$score,
            'breakdown'=>[
                'Structured Data'=>$structured,
                'Content Quality'=>$content,
                'Retrieval AI-ready'=>$retrieval,
                'Answer Extraction'=>$answer,
                'Consistency'=>$consistency,
            ],
            'warnings'=>array_values(array_unique($warnings)),
            'legend'=>[
                ['Stato sito'=>'WordPress standard','Score indicativo'=>'15-35'],
                ['Stato sito'=>'SEO plugin classico','Score indicativo'=>'25-45'],
                ['Stato sito'=>'Schema + FAQ base','Score indicativo'=>'40-60'],
                ['Stato sito'=>'vostro plugin iniziale','Score indicativo'=>'55-70'],
                ['Stato sito'=>'plugin attuale completo con contenuti reali','Score indicativo'=>'75-90'],
            ],
        ];
    }

    private function llm_answer_extraction_analyzer($layer, $schema, $faq_items, $updated_at=''){
        $checks = [];
        $suggestions = [];
        $score = 0;
        $max = 0;
        $summary_short = trim((string)($layer['summary_short'] ?? ''));
        $summary_extended = trim((string)($layer['summary_extended'] ?? ''));
        $faq_count = count((array)$faq_items);
        $direct_answers = 0;
        foreach((array)$faq_items as $faq){
            $q = trim((string)($faq['question'] ?? ''));
            $a = trim((string)($faq['answer'] ?? ''));
            $answer_len = function_exists('mb_strlen') ? mb_strlen($a) : strlen($a);
            if($q !== '' && $a !== '' && $answer_len <= 320) $direct_answers++;
        }
        $add_check = function($label, $ok, $points, $message) use (&$checks, &$score, &$max, &$suggestions){
            $max += $points;
            if($ok) $score += $points;
            else $suggestions[] = $message;
            $checks[] = ['label'=>$label, 'status'=>$ok ? 'ok' : 'attenzione', 'message'=>$message];
        };
        $add_check('Risposta diretta nel summary breve', $summary_short !== '' && (function_exists('mb_strlen') ? mb_strlen($summary_short) <= 240 : strlen($summary_short) <= 240), 18, 'Crea un summary breve con risposta diretta entro circa 240 caratteri.');
        $add_check('Summary esteso leggibile nei primi paragrafi', $summary_extended !== '' && (function_exists('mb_strlen') ? mb_strlen($summary_extended) <= 900 : strlen($summary_extended) <= 900), 12, 'Riduci introduzioni troppo lunghe e porta la risposta nei primi 2-3 paragrafi.');
        $add_check('Domande naturali presenti', $faq_count > 0, 16, 'Aggiungi FAQ con domande naturali, simili a quelle che farebbe un utente.');
        $add_check('FAQ con risposte concise', $faq_count > 0 && $direct_answers >= max(1, min($faq_count, 3)), 16, 'Mantieni le risposte FAQ brevi, autonome e subito verificabili.');
        $add_check('Heading e blocchi semantici chiari', !empty($layer['semantic_sections']), 14, 'Usa heading descrittivi e sezioni semantiche facili da isolare.');
        $add_check('Key facts disponibili', !empty($layer['key_facts']), 12, 'Compila i campi principali di Schema.org per generare key facts estraibili.');
        $add_check('Contenuti citation-friendly disponibili', !empty($layer['citation_friendly']['statistics']) || !empty($layer['citation_friendly']['tables']) || !empty($layer['citation_friendly']['definitions']), 12, 'Aggiungi dati verificabili, tabelle o definizioni brevi per aumentare la citabilità.');
        $computed = $max ? (int)round(($score / $max) * 100) : 0;
        $optimized_answers = [];
        if($summary_short !== '') $optimized_answers[] = ['question'=>'Cos\'è '.$layer['name'].'?', 'answer'=>$summary_short];
        foreach(array_slice((array)$faq_items, 0, 6) as $faq){
            if(!empty($faq['question']) && !empty($faq['answer'])) $optimized_answers[] = ['question'=>$faq['question'], 'answer'=>$faq['answer']];
        }
        if(empty($suggestions)) $suggestions[] = 'La struttura è già adatta all\'answer extraction AI.';
        return [
            'score'=>$computed,
            'checks'=>$checks,
            'suggestions'=>array_values(array_unique($suggestions)),
            'optimized_answers'=>$optimized_answers,
            'updated_at'=>$updated_at ?: current_time('Y-m-d H:i'),
        ];
    }


    private function llm_ai_visibility_monitor($layer, $schema, $faq_items){
        $name = trim((string)($schema['name'] ?? $layer['name'] ?? get_bloginfo('name')));
        $city = trim((string)($schema['city'] ?? ''));
        $type = trim((string)($schema['type'] ?? ''));
        $keywords = [];
        foreach($this->llm_csv_items($schema['keywords'] ?? '', 8) as $kw){ $keywords[] = $kw; }
        foreach(array_slice((array)($schema['amenities'] ?? []), 0, 8) as $amenity){ if(is_scalar($amenity) && trim((string)$amenity) !== '') $keywords[] = trim((string)$amenity); }
        foreach(array_slice((array)($schema['knows_about'] ?? []), 0, 6) as $topic){ if(is_scalar($topic) && trim((string)$topic) !== '') $keywords[] = trim((string)$topic); }
        foreach(array_slice((array)($schema['targets'] ?? []), 0, 4) as $target){ if(is_scalar($target) && trim((string)$target) !== '') $keywords[] = trim((string)$target); }
        if($city !== '') $keywords[] = $city;
        if($type !== '') $keywords[] = $type;
        $keywords = array_values(array_unique(array_filter(array_map('sanitize_text_field', $keywords))));

        $faq_ready = [];
        foreach(array_slice((array)$faq_items, 0, 8) as $faq){
            $q = trim((string)($faq['question'] ?? ''));
            $a = trim((string)($faq['answer'] ?? ''));
            if($q !== '' && $a !== '') $faq_ready[] = wp_trim_words(wp_strip_all_tags($q), 14, '');
        }

        $readiness = intval($layer['ai_readiness_score']['score'] ?? 0);
        $answer = intval($layer['answer_extraction']['score'] ?? 0);
        $has_retrieval = !empty($layer['summary_short']) && !empty($layer['key_facts']) && !empty($layer['citation_friendly']);
        $has_brand = $name !== '' && strtolower($name) !== 'wordpress';
        $has_keywords = count($keywords) >= 3;
        $has_faq_ready = count($faq_ready) >= 3;
        $has_citation = !empty($layer['citation_friendly']['tables']) || !empty($layer['citation_friendly']['definitions']) || !empty($layer['citation_friendly']['statistics']);

        $score = 0;
        $score += $has_brand ? 12 : 0;
        $score += min(22, (int)round($readiness * 0.22));
        $score += min(18, (int)round($answer * 0.18));
        $score += $has_retrieval ? 14 : 0;
        $score += $has_citation ? 12 : 0;
        $score += $has_keywords ? 10 : 0;
        $score += $has_faq_ready ? 12 : 0;
        if(!$has_brand || !$has_keywords) $score = min($score, 65);
        if(!$has_faq_ready) $score = min($score, 70);
        $score = max(0, min(100, $score));
        $level = $score >= 75 ? 'alto' : ($score >= 55 ? 'medio' : 'basso');
        $checks = [
            ['label'=>'Brand/entità rilevata', 'status'=>$has_brand ? 'ok' : 'attenzione', 'value'=>$has_brand ? $name : 'mancante o generico'],
            ['label'=>'Keyword da Schema.org e servizi', 'status'=>$has_keywords ? 'ok' : 'attenzione', 'value'=>count($keywords)],
            ['label'=>'FAQ extraction-ready', 'status'=>$has_faq_ready ? 'ok' : 'attenzione', 'value'=>count($faq_ready)],
            ['label'=>'Retrieval layer disponibile', 'status'=>$has_retrieval ? 'ok' : 'attenzione', 'value'=>$has_retrieval ? 'attivo' : 'da completare'],
            ['label'=>'Answer extraction score', 'status'=>$answer >= 70 ? 'ok' : 'attenzione', 'value'=>$answer.'/100'],
            ['label'=>'Contenuti citation-ready', 'status'=>$has_citation ? 'ok' : 'attenzione', 'value'=>$has_citation ? 'presenti' : 'scarsi'],
            ['label'=>'Monitor esterno AI', 'status'=>'informativo', 'value'=>'non eseguito: nessuna API, scraping o query esterna'],
        ];
        $intents = [];
        if($name !== ''){
            if($city !== '') $intents[] = $name.' '.$city;
            if($type !== '') $intents[] = $name.' '.$type;
        }
        foreach(array_slice($keywords, 0, 5) as $kw){
            if($name !== '' && $kw !== $name) $intents[] = $name.' '.$kw;
            else $intents[] = $kw;
        }
        $suggestions = [];
        if(!$has_brand) $suggestions[] = 'Compila il nome attività in Schema.org: è la base per valutare l\'entità/brand.';
        if(!$has_keywords) $suggestions[] = 'Aggiungi servizi, keyword o temi reali in Schema.org per rendere più utile la stima interna.';
        if(!$has_faq_ready) $suggestions[] = 'Aggiungi almeno 3 FAQ reali con risposta: non vengono trattate come query, ma come contenuti extraction-ready.';
        if($answer < 70) $suggestions[] = 'Rendi le risposte più dirette e concise per migliorare l\'answer extraction.';
        if(!$has_citation) $suggestions[] = 'Aggiungi dati verificabili, tabelle o definizioni per aumentare la citabilità.';
        if(empty($suggestions)) $suggestions[] = 'Segnali interni buoni: questa è una stima tecnica, non una misurazione reale di citazioni su ChatGPT, Gemini o Perplexity.';
        return [
            'score'=>$score,
            'level'=>$level,
            'brand'=>$name,
            'keywords'=>array_slice($keywords, 0, 12),
            'intents'=>array_values(array_unique(array_slice($intents, 0, 10))),
            'faq_ready'=>$faq_ready,
            'checks'=>$checks,
            'suggestions'=>array_values(array_unique($suggestions)),
            'note'=>'Stima interna leggera: non misura citazioni reali su motori AI, non interroga ChatGPT/Gemini/Perplexity, non fa scraping e non aggiunge carico al frontend.',
            'updated_at'=>$layer['updated_at'] ?? current_time('Y-m-d H:i'),
        ];
    }

    private function llm_get_layer_cached($force = false){
        if(!$force){
            $cached = get_transient(self::LLM_CACHE_TRANSIENT);
            if(is_array($cached)) return $cached;
        }
        $layer = $this->llm_build_layer();
        if(is_array($layer)){
            $cache_size = strlen(maybe_serialize($layer));
            update_option(self::LLM_CACHE_SIZE_OPTION, $cache_size, false);
            // Enterprise safety: avoid storing very large diagnostic layers in wp_options on shared hosting.
            if($cache_size <= self::LLM_CACHE_MAX_BYTES){
                set_transient(self::LLM_CACHE_TRANSIENT, $layer, self::LLM_CACHE_TTL);
            } else {
                delete_transient(self::LLM_CACHE_TRANSIENT);
            }
        }
        return $layer;
    }

    public function invalidate_llm_cache(){
        delete_transient(self::LLM_CACHE_TRANSIENT);
    }

    public function invalidate_llm_cache_for_post($post_id = 0, $post = null, $update = null){
        if($post_id && wp_is_post_revision($post_id)) return;
        if($post_id && get_post_type($post_id) !== self::CPT) return;
        $this->invalidate_llm_cache();
        $this->chunks_invalidate();
    }

    public function maybe_invalidate_llm_cache_for_post($post_id){
        if($post_id && get_post_type($post_id) === self::CPT) $this->invalidate_llm_cache();
    }

    public function maybe_invalidate_llm_cache_for_option($option, $old_value, $value){
        $watched = [self::OPTION, self::SCHEMA_OPTION, self::CC_REPORT_OPTION, self::CC_LAST_SCAN_OPTION, self::LLM_OPTION, self::LLM_QUALITY_OPTION];
        if(in_array($option, $watched, true)){
            $this->invalidate_llm_cache();
            $this->chunks_invalidate();
            $this->entity_graph_invalidate();
            $this->citation_invalidate();
        }
    }

    private function should_disable_external_schema(){
        $o = $this->schema_opts();
        return !empty($o['enabled']) && !empty($o['disable_external_schema']) && $this->schema_should_output($o) && (empty($o['only_if_required']) || !$this->schema_missing_required($o));
    }

    public function maybe_disable_yoast_schema($data, $context = null){
        return $this->should_disable_external_schema() ? false : $data;
    }

    public function maybe_disable_rankmath_schema($data){
        return $this->should_disable_external_schema() ? [] : $data;
    }

    public function maybe_disable_aioseo_schema($disabled){
        return $this->should_disable_external_schema() ? true : $disabled;
    }

    public function maybe_disable_aioseo_schema_output($schema){
        return $this->should_disable_external_schema() ? [] : $schema;
    }

    public function robots_txt_ai_sitemap($output, $public){
        if(!$this->retrieval_is_enabled()) return $output;
        $sitemap_line = 'Sitemap: '.$this->retrieval_base_url('ai-sitemap.xml');
        if(strpos((string)$output, $sitemap_line) === false){
            $output = rtrim((string)$output)."\n".$sitemap_line."\n";
        }
        if(strpos((string)$output, 'User-agent: GPTBot') === false){
            $allow = "\nAllow: /llms.txt\nAllow: /knowledge/\nAllow: /ai-sitemap.xml\n";
            $output = rtrim((string)$output)."\n\n# AI crawlers\nUser-agent: GPTBot".$allow."\nUser-agent: ClaudeBot".$allow."\nUser-agent: PerplexityBot".$allow."\nUser-agent: Googlebot".$allow;
        }
        return $output;
    }

    private function has_physical_robots_txt(){
        $file = trailingslashit(ABSPATH).'robots.txt';
        return file_exists($file) && is_readable($file);
    }

    private function physical_robots_has_ai_sitemap(){
        $file = trailingslashit(ABSPATH).'robots.txt';
        if(!file_exists($file) || !is_readable($file)) return true;
        $contents = (string) file_get_contents($file);
        return stripos($contents, 'ai-sitemap.xml') !== false;
    }

    public function enterprise_admin_notices(){
        if(!current_user_can('manage_options')) return;
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $is_plugin_area = $screen && (
            $screen->post_type === self::CPT ||
            strpos((string)$screen->id, 'in3pida') !== false
        );
        if(!$is_plugin_area) return;


        $cache_size = intval(get_option(self::LLM_CACHE_SIZE_OPTION, 0));
        if($cache_size > self::LLM_CACHE_MAX_BYTES){
            echo '<div class="notice notice-warning"><p><strong>Eletta:</strong> il LLM Ready Layer supera '.esc_html(size_format(self::LLM_CACHE_MAX_BYTES)).' e non viene salvato nel transient per evitare di appesantire <code>wp_options</code>. Valuta di ridurre contenuti duplicati o FAQ non necessarie.</p></div>';
        } elseif($cache_size > 0 && $cache_size > (self::LLM_CACHE_MAX_BYTES * 0.75)){
            echo '<div class="notice notice-info"><p><strong>Eletta:</strong> la cache del LLM Ready Layer è circa '.esc_html(size_format($cache_size)).'. È ancora entro il limite di sicurezza, ma monitora il numero di FAQ/contenuti se il sito cresce molto.</p></div>';
        }
    }

    private function llm_build_layer(){
        $schema = $this->schema_opts();
        $faq_items = $this->llm_get_faq_items();
        $report = $this->cc_get_report();
        $layer_updated_at = $this->llm_quality_last_updated($schema, $faq_items, $report);
        $name = trim((string)($schema['name'] ?? get_bloginfo('name')));
        if(!$name) $name = get_bloginfo('name');
        $city = trim((string)($schema['city'] ?? ''));
        $type = trim((string)($schema['type'] ?? 'struttura ricettiva'));
        $description = trim((string)($schema['description'] ?? ''));
        $summary_short_parts = [];
        $summary_short_parts[] = $name;
        if($type) $summary_short_parts[] = 'è una struttura di tipo '.$type;
        if($city) $summary_short_parts[] = 'a '.$city;
        $summary_short = trim(implode(' ', $summary_short_parts));
        if($summary_short && substr($summary_short, -1) !== '.') $summary_short .= '.';
        if($description){
            $summary_extended = wp_trim_words($description, 70, '...');
        } else {
            $summary_extended = $summary_short;
            $amenities = array_slice((array)($schema['amenities'] ?? []), 0, 6);
            if($amenities) $summary_extended .= ' Servizi principali: '.implode(', ', array_map('sanitize_text_field', $amenities)).'.';
        }
        $key_facts = [];
        foreach([
            'Nome struttura'=>$name,
            'Tipologia'=>$type,
            'Località'=>$city,
            'Sito ufficiale'=>$schema['url'] ?? '',
            'Telefono'=>$schema['telephone'] ?? '',
            'Email'=>$schema['email'] ?? '',
            'Check-in'=>$schema['checkin_time'] ?? '',
            'Check-out'=>$schema['checkout_time'] ?? '',
            'Animali'=>$schema['pets_allowed'] ?? '',
            'Fascia prezzo'=>$schema['price_range'] ?? '',
        ] as $label=>$value){
            $value = is_scalar($value) ? trim((string)$value) : '';
            if($value !== '') $key_facts[] = ['label'=>$label,'value'=>$value];
        }
        $semantic_sections = [];
        if(!empty($schema['amenities'])) $semantic_sections[] = ['id'=>'servizi-principali','title'=>'Servizi principali','items'=>array_slice((array)$schema['amenities'],0,12)];
        if(!empty($schema['targets'])) $semantic_sections[] = ['id'=>'target-clienti','title'=>'Target clienti','items'=>array_slice((array)$schema['targets'],0,10)];
        $knows = array_slice((array)($schema['knows_about'] ?? []),0,10);
        if($knows) $semantic_sections[] = ['id'=>'temi-rilevanti','title'=>'Temi rilevanti','items'=>$knows];
        $keywords = $this->llm_csv_items($schema['keywords'] ?? '', 12);
        if($keywords) $semantic_sections[] = ['id'=>'keyword-semantiche','title'=>'Keyword semantiche','items'=>$keywords];
        if($faq_items){
            $semantic_sections[] = ['id'=>'domande-frequenti','title'=>'Domande frequenti','items'=>array_map(function($f){ return $f['question']; }, array_slice($faq_items,0,8))];
        }
        $consistency = [];
        if(!empty($report)){
            $consistency['score'] = isset($report['score']) ? intval($report['score']) : null;
            $consistency['channels_checked'] = isset($report['channels_checked']) ? intval($report['channels_checked']) : 0;
            $consistency['critical'] = intval($report['counts']['critical'] ?? 0);
            $consistency['medium'] = intval($report['counts']['medium'] ?? 0);
            $consistency['low'] = intval($report['counts']['low'] ?? 0);
        }
        $citation_friendly = [
            'source_note' => 'Fonte: dati inseriti nel pannello Schema.org, FAQ e Coerenza contenuti.',
            'updated_at' => $layer_updated_at,
            'statistics' => [],
            'tables' => [],
            'definitions' => [],
            'glossary' => [],
            'comparisons' => [],
        ];
        $citation_friendly['statistics'][] = ['label'=>'FAQ pubblicate','value'=>count($faq_items)];
        $citation_friendly['statistics'][] = ['label'=>'Servizi dichiarati','value'=>count((array)($schema['amenities'] ?? []))];
        $citation_friendly['statistics'][] = ['label'=>'Camere/appartamenti dichiarati','value'=>count(array_filter((array)($schema['rooms'] ?? []), function($r){ return is_array($r) && !empty($r['name']); }))];
        $citation_friendly['statistics'][] = ['label'=>'Offerte dichiarate','value'=>count(array_filter((array)($schema['offers'] ?? []), function($r){ return is_array($r) && (!empty($r['name']) || !empty($r['url'])); }))];
        if(!empty($schema['rating_value'])) $citation_friendly['statistics'][] = ['label'=>'Rating principale dichiarato','value'=>$schema['rating_value'].(!empty($schema['review_count']) ? ' su '.$schema['review_count'].' recensioni' : '')];
        $rooms_table = [];
        foreach((array)($schema['rooms'] ?? []) as $r){
            if(!is_array($r) || empty($r['name'])) continue;
            $rooms_table[] = [
                'Nome'=>$r['name'] ?? '',
                'Capienza'=>trim(($r['min'] ?? '').(!empty($r['max']) ? ' - '.$r['max'] : '')),
                'Letto'=>$r['bed'] ?? '',
                'Prezzo da'=>trim(($r['price'] ?? '').' '.($r['currency'] ?? '')),
                'Disponibilità'=>$r['availability'] ?? '',
            ];
        }
        if($rooms_table) $citation_friendly['tables'][] = ['id'=>'tabella-camere-appartamenti','title'=>'Camere / appartamenti','headers'=>['Nome','Capienza','Letto','Prezzo da','Disponibilità'],'rows'=>$rooms_table];
        $offers_table = [];
        foreach((array)($schema['offers'] ?? []) as $of){
            if(!is_array($of) || (empty($of['name']) && empty($of['url']))) continue;
            $offers_table[] = ['Nome'=>$of['name'] ?? 'Prenotazione','Prezzo da'=>trim(($of['price'] ?? '').' '.($of['currency'] ?? '')),'URL'=>$of['url'] ?? ''];
        }
        if($offers_table) $citation_friendly['tables'][] = ['id'=>'tabella-offerte','title'=>'Offerte / prenotazione','headers'=>['Nome','Prezzo da','URL'],'rows'=>$offers_table];
        $amenities_table = [];
        foreach(array_slice((array)($schema['amenities'] ?? []), 0, 20) as $a){ if(is_scalar($a) && trim((string)$a) !== '') $amenities_table[] = ['Servizio'=>trim((string)$a)]; }
        if($amenities_table) $citation_friendly['tables'][] = ['id'=>'tabella-servizi','title'=>'Servizi principali','headers'=>['Servizio'],'rows'=>$amenities_table];
        if($name) $citation_friendly['definitions'][] = ['term'=>$name,'definition'=>$summary_short];
        if($type) $citation_friendly['glossary'][] = ['term'=>'Tipologia struttura','definition'=>$type];
        if($city) $citation_friendly['glossary'][] = ['term'=>'Località','definition'=>$city];
        if(!empty($schema['price_range'])) $citation_friendly['glossary'][] = ['term'=>'Fascia prezzo','definition'=>$schema['price_range']];
        if(!empty($schema['checkin_time']) || !empty($schema['checkout_time'])) $citation_friendly['comparisons'][] = ['label'=>'Orari soggiorno','left'=>'Check-in: '.($schema['checkin_time'] ?? ''),'right'=>'Check-out: '.($schema['checkout_time'] ?? '')];
        $entity_authority = $this->entity_authority_score($schema);
        $answer_extraction = $this->llm_answer_extraction_analyzer([
            'name'=>$name,
            'summary_short'=>$summary_short,
            'summary_extended'=>$summary_extended,
            'key_facts'=>$key_facts,
            'semantic_sections'=>$semantic_sections,
            'citation_friendly'=>$citation_friendly,
        ], $schema, $faq_items, $layer_updated_at);
        $layer = [
            'name'=>$name,
            'summary_short'=>$summary_short,
            'summary_extended'=>$summary_extended,
            'key_facts'=>$key_facts,
            'semantic_sections'=>$semantic_sections,
            'faqs'=>$faq_items,
            'consistency'=>$consistency,
            'citation_friendly'=>$citation_friendly,
            'entity_authority'=>$entity_authority,
            'answer_extraction'=>$answer_extraction,
            'updated_at'=>$layer_updated_at,
        ];
        $layer['quality_safety'] = $this->llm_quality_layer($layer, $schema, $faq_items);
        $layer['ai_readiness_score'] = $this->llm_ai_readiness_score($layer);
        $layer['ai_visibility_monitor'] = $this->llm_ai_visibility_monitor($layer, $schema, $faq_items);
        return $layer;
    }

    public function retrieval_rewrite_rules(){
        add_rewrite_rule('^llms\.txt$', 'index.php?in3pida_ai_resource=llms', 'top');
        add_rewrite_rule('^ai-sitemap\.xml$', 'index.php?in3pida_ai_resource=ai_sitemap', 'top');
        add_rewrite_rule('^knowledge/?$', 'index.php?in3pida_ai_resource=knowledge_index', 'top');
        add_rewrite_rule('^knowledge/([a-z0-9\-]+)\.md$', 'index.php?in3pida_ai_resource=knowledge_md&in3pida_ai_slug=$matches[1]', 'top');
    }

    public function retrieval_query_vars($vars){
        $vars[] = 'in3pida_ai_resource';
        $vars[] = 'in3pida_ai_slug';
        return $vars;
    }

    private function retrieval_is_enabled(){
        $llm_o = $this->llm_opts();
        return !empty($llm_o['enabled']);
    }

    private function retrieval_base_url($path=''){
        return home_url('/'.ltrim($path, '/'));
    }

    private function retrieval_md_pages(){
        return [
            'overview' => ['title'=>'Overview struttura', 'url'=>$this->retrieval_base_url('knowledge/overview.md')],
            'faq' => ['title'=>'FAQ', 'url'=>$this->retrieval_base_url('knowledge/faq.md')],
            'schema' => ['title'=>'Schema.org facts', 'url'=>$this->retrieval_base_url('knowledge/schema.md')],
            'servizi' => ['title'=>'Servizi', 'url'=>$this->retrieval_base_url('knowledge/servizi.md')],
            'citation-friendly' => ['title'=>'Contenuti citation-friendly', 'url'=>$this->retrieval_base_url('knowledge/citation-friendly.md')],
            'answer-extraction' => ['title'=>'Answer extraction', 'url'=>$this->retrieval_base_url('knowledge/answer-extraction.md')],
        ];
    }

    public function retrieval_template_redirect(){
        $resource = get_query_var('in3pida_ai_resource');
        if(!$resource){
            $path = trim((string)parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
            if($path === 'llms.txt') $resource = 'llms';
            elseif($path === 'ai-sitemap.xml') $resource = 'ai_sitemap';
            elseif($path === 'knowledge') $resource = 'knowledge_index';
            elseif(preg_match('#^knowledge/([a-z0-9\-]+)\.md$#', $path, $m)){ $resource = 'knowledge_md'; set_query_var('in3pida_ai_slug', $m[1]); }
        }
        if(!$resource) return;
        if(!$this->retrieval_is_enabled()){
            status_header(404);
            exit;
        }
        if($resource === 'llms') $this->retrieval_output_text($this->retrieval_llms_txt(), 'text/plain; charset=utf-8');
        if($resource === 'ai_sitemap') $this->retrieval_output_text($this->retrieval_ai_sitemap_xml(), 'application/xml; charset=utf-8');
        if($resource === 'knowledge_index') $this->retrieval_output_text($this->retrieval_knowledge_index_html(), 'text/html; charset=utf-8');
        if($resource === 'knowledge_md'){
            $slug = sanitize_key(get_query_var('in3pida_ai_slug'));
            $md = $this->retrieval_markdown($slug);
            if($md === ''){ status_header(404); exit; }
            $this->retrieval_output_text($md, 'text/markdown; charset=utf-8');
        }
    }

    private function retrieval_output_text($content, $type){
        nocache_headers();
        header('Content-Type: '.$type);
        if(strpos($type, 'application/xml') === false){
            header('X-Robots-Tag: noindex, follow');
        }
        echo $content;
        exit;
    }

    private function retrieval_llms_txt(){
        $layer = $this->llm_get_layer_cached();
        $schema = $this->schema_opts();
        $lines = [];

        $lines[] = '# '.($layer['name'] ?: get_bloginfo('name'));
        if(!empty($layer['summary_short'])) $lines[] = '> '.$layer['summary_short'];
        $lines[] = '';

        if(!empty($layer['summary_extended']) && $layer['summary_extended'] !== ($layer['summary_short'] ?? '')){
            $lines[] = $layer['summary_extended'];
            $lines[] = '';
        }

        if(!empty($layer['key_facts'])){
            $lines[] = '## Informazioni principali';
            foreach((array)$layer['key_facts'] as $fact){
                if(!empty($fact['value'])) $lines[] = '- **'.wp_strip_all_tags($fact['label']).'**: '.wp_strip_all_tags($fact['value']);
            }
            $lines[] = '';
        }

        $amenities = array_values(array_filter(array_map('sanitize_text_field', (array)($schema['amenities'] ?? []))));
        if($amenities){
            $lines[] = '## Servizi';
            foreach(array_slice($amenities, 0, 20) as $amenity) $lines[] = '- '.$amenity;
            $lines[] = '';
        }

        $rooms = array_values(array_filter((array)($schema['rooms'] ?? [])));
        if($rooms){
            $lines[] = '## Camere e appartamenti';
            foreach(array_slice($rooms, 0, 10) as $room){
                $room_name = is_array($room) ? sanitize_text_field($room['name'] ?? '') : sanitize_text_field((string)$room);
                if($room_name) $lines[] = '- '.$room_name;
            }
            $lines[] = '';
        }

        $faqs = array_slice((array)($layer['faqs'] ?? []), 0, 6);
        if($faqs){
            $lines[] = '## Domande frequenti';
            foreach($faqs as $faq){
                $q = wp_strip_all_tags($faq['question'] ?? '');
                $a = wp_strip_all_tags($faq['answer'] ?? '');
                if($q && $a){ $lines[] = '### '.$q; $lines[] = $a; $lines[] = ''; }
            }
        }

        $lines[] = '## File AI-readable';
        $lines[] = '- [Knowledge index]('.$this->retrieval_base_url('knowledge/').'): indice dei contenuti strutturati';
        $lines[] = '- [AI sitemap]('.$this->retrieval_base_url('ai-sitemap.xml').'): sitemap ottimizzata per crawler AI';
        $lines[] = '- [Entity Graph]('.esc_url(rest_url('in3pida/v1/graph')).'): grafo semantico delle relazioni tra entita';
        $lines[] = '- [Chunk index]('.esc_url(rest_url('in3pida/v1/chunks')).'): blocchi semantici ottimizzati per retrieval';
        foreach($this->retrieval_md_pages() as $page){
            $lines[] = '- ['.$page['title'].']('.$page['url'].')';
        }
        $lines[] = '';
        $lines[] = '## Fonte';
        $lines[] = 'Generato automaticamente da Eletta — Posiziona il tuo sito nelle ricerche AI. Fonte: Schema.org, FAQ e dati di coerenza contenuti.';
        if(!empty($layer['updated_at'])) $lines[] = 'Aggiornato: '.$layer['updated_at'];
        return implode("\n", $lines)."\n";
    }

    private function retrieval_ai_sitemap_xml(){
        $layer = $this->llm_get_layer_cached();
        $lastmod_time = !empty($layer['updated_at']) ? strtotime($layer['updated_at']) : time();
        $lastmod = gmdate('c', $lastmod_time);

        $entries = [];
        $entries[] = ['url' => home_url('/'), 'changefreq' => 'weekly', 'priority' => '1.0', 'type' => 'homepage'];

        $faq_page_id = intval(get_option(self::PAGE_OPTION, 0));
        if($faq_page_id && get_post_status($faq_page_id) === 'publish'){
            $entries[] = ['url' => get_permalink($faq_page_id), 'changefreq' => 'weekly', 'priority' => '0.9', 'type' => 'faq-page'];
        }

        $entries[] = ['url' => $this->retrieval_base_url('llms.txt'),       'changefreq' => 'weekly', 'priority' => '0.9', 'type' => 'llms-txt'];
        $entries[] = ['url' => $this->retrieval_base_url('knowledge/'),      'changefreq' => 'weekly', 'priority' => '0.8', 'type' => 'knowledge-index'];

        $md_priorities = ['overview' => '0.8', 'faq' => '0.8', 'schema' => '0.7', 'servizi' => '0.7', 'citation-friendly' => '0.7', 'answer-extraction' => '0.6'];
        foreach($this->retrieval_md_pages() as $key => $page){
            $entries[] = ['url' => $page['url'], 'changefreq' => 'weekly', 'priority' => ($md_priorities[$key] ?? '0.6'), 'type' => 'knowledge-'.$key];
        }

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
        $xml .= '<!-- AI Sitemap generata da Eletta -->'."\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
        foreach($entries as $e){
            $xml .= '  <url>'."\n";
            $xml .= '    <loc>'.esc_url($e['url']).'</loc>'."\n";
            $xml .= '    <lastmod>'.esc_html($lastmod).'</lastmod>'."\n";
            $xml .= '    <changefreq>'.esc_html($e['changefreq']).'</changefreq>'."\n";
            $xml .= '    <priority>'.esc_html($e['priority']).'</priority>'."\n";
            $xml .= '    <!-- content-type: '.esc_html($e['type']).' -->'."\n";
            $xml .= '  </url>'."\n";
        }
        $xml .= '</urlset>'."\n";
        return $xml;
    }

    private function retrieval_knowledge_index_html(){
        $layer = $this->llm_get_layer_cached();
        $html = '<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="robots" content="noindex,follow"><title>'.esc_html($layer['name'] ?: get_bloginfo('name')).' - Knowledge index</title></head><body>';
        $html .= '<main data-ai-knowledge-index><h1>'.esc_html($layer['name'] ?: get_bloginfo('name')).' - Knowledge index</h1>';
        if(!empty($layer['summary_extended'])) $html .= '<p>'.esc_html($layer['summary_extended']).'</p>';
        $html .= '<h2>File Markdown</h2><ul>';
        foreach($this->retrieval_md_pages() as $page){ $html .= '<li><a href="'.esc_url($page['url']).'">'.esc_html($page['title']).'</a></li>'; }
        $html .= '</ul><p><a href="'.esc_url($this->retrieval_base_url('llms.txt')).'">llms.txt</a> | <a href="'.esc_url($this->retrieval_base_url('ai-sitemap.xml')).'">AI sitemap</a></p></main></body></html>';
        return $html;
    }

    private function retrieval_markdown($slug){
        $layer = $this->llm_get_layer_cached();
        $slug_titles = [
            'overview'          => 'Overview struttura',
            'faq'               => 'FAQ',
            'schema'            => 'Schema.org facts',
            'servizi'           => 'Servizi e blocchi semantici',
            'citation-friendly' => 'Contenuti citation-friendly',
            'answer-extraction' => 'Answer extraction',
        ];
        if(!array_key_exists($slug, $slug_titles)) return '';
        $site_name = $layer['name'] ?: get_bloginfo('name');
        $out = [];
        $out[] = '---';
        $out[] = 'title: '.str_replace(["\n","\r"], ' ', ($slug_titles[$slug].' - '.$site_name));
        $out[] = 'source: in3pida LLM Ready Layer';
        if(!empty($layer['updated_at'])) $out[] = 'updated: '.$layer['updated_at'];
        $out[] = 'robots: noindex';
        $out[] = '---';
        $out[] = '';
        $out[] = '# '.$site_name;
        $out[] = '';
        if(!empty($layer['updated_at'])) $out[] = 'Aggiornato al: '.$layer['updated_at'];
        $out[] = '';
        if($slug === 'overview'){
            $out[] = '## Riassunto';
            $out[] = $layer['summary_extended'] ?? '';
            $out[] = '';
            $out[] = '## Key facts';
            foreach((array)($layer['key_facts'] ?? []) as $fact) $out[] = '- **'.$fact['label'].'**: '.$fact['value'];
        } elseif($slug === 'faq'){
            $out[] = '## FAQ';
            foreach((array)($layer['faqs'] ?? []) as $faq){ $out[] = '### '.$faq['question']; $out[] = $faq['answer']; $out[] = ''; }
        } elseif($slug === 'schema'){
            $out[] = '## Schema.org facts';
            foreach((array)($layer['key_facts'] ?? []) as $fact) $out[] = '- **'.$fact['label'].'**: '.$fact['value'];
        } elseif($slug === 'servizi'){
            $out[] = '## Servizi e blocchi semantici';
            foreach((array)($layer['semantic_sections'] ?? []) as $section){ $out[] = '### '.$section['title']; foreach((array)$section['items'] as $item) $out[] = '- '.(is_scalar($item)?$item:''); $out[] = ''; }
        } elseif($slug === 'citation-friendly'){
            $citation = $layer['citation_friendly'] ?? [];
            $out[] = '## Contenuti citation-friendly';
            if(!empty($citation['source_note'])) $out[] = $citation['source_note'];
            if(!empty($citation['updated_at'])) $out[] = 'Aggiornato al: '.$citation['updated_at'];
            $out[] = '';
            if(!empty($citation['statistics'])){ $out[] = '### Statistiche'; foreach((array)$citation['statistics'] as $stat) $out[] = '- **'.$stat['label'].'**: '.$stat['value']; $out[] = ''; }
            foreach((array)($citation['tables'] ?? []) as $table){
                $headers = (array)($table['headers'] ?? []);
                $out[] = '### '.$table['title'];
                if($headers){ $out[] = '| '.implode(' | ', $headers).' |'; $out[] = '| '.implode(' | ', array_fill(0, count($headers), '---')).' |'; foreach((array)($table['rows'] ?? []) as $row){ $cells=[]; foreach($headers as $h) $cells[] = str_replace('|','/', (string)($row[$h] ?? '')); $out[] = '| '.implode(' | ', $cells).' |'; } $out[] = ''; }
            }
            if(!empty($citation['definitions'])){ $out[] = '### Definizioni'; foreach((array)$citation['definitions'] as $def) $out[] = '- **'.$def['term'].'**: '.$def['definition']; $out[] = ''; }
            if(!empty($citation['glossary'])){ $out[] = '### Glossario'; foreach((array)$citation['glossary'] as $gl) $out[] = '- **'.$gl['term'].'**: '.$gl['definition']; $out[] = ''; }
        } elseif($slug === 'answer-extraction'){
            $ae = $layer['answer_extraction'] ?? [];
            $out[] = '## Risposte dirette';
            $out[] = '';
            foreach((array)($ae['optimized_answers'] ?? []) as $ans){
                $out[] = '### '.($ans['question'] ?? '');
                $out[] = $ans['answer'] ?? '';
                $out[] = '';
            }
            if(!empty($ae['checks'])){
                $out[] = '## Check answer extraction';
                foreach((array)$ae['checks'] as $check){
                    $mark = ($check['status'] ?? '') === 'ok' ? 'ok' : 'attenzione';
                    $out[] = '- ['.$mark.'] '.($check['label'] ?? '');
                }
                $out[] = '';
            }
            if(!empty($ae['suggestions'])){
                $out[] = '## Suggerimenti';
                foreach((array)$ae['suggestions'] as $s) $out[] = '- '.$s;
                $out[] = '';
            }
        }
        $out[] = '';
        $out[] = 'Fonte: LLM Ready Layer generato automaticamente da Eletta — Posiziona il tuo sito nelle ricerche AI.';
        return implode("\n", array_map(function($v){ return wp_strip_all_tags((string)$v); }, $out))."\n";
    }

    // ── RATE LIMITER ─────────────────────────────────────────────────────────────

    private function isi_rate_limit(string $endpoint, int $limit = 60, int $window = 60): bool {
        $ip  = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $key = 'in3pida_rl_' . $endpoint . '_' . substr(md5($ip), 0, 12);
        $n   = (int) get_transient($key);
        if ($n >= $limit) return false;
        set_transient($key, $n + 1, $window);
        return true;
    }

    // ── CHUNK ENGINE ────────────────────────────────────────────────────────────

    public function register_chunk_rest_routes(){
        register_rest_route('in3pida/v1', '/chunks', [
            'methods'             => 'GET, OPTIONS',
            'callback'            => [$this, 'chunk_rest_handler'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function chunk_rest_handler($request){
        if ($request->get_method() === 'OPTIONS') {
            $response = new WP_REST_Response(null, 200);
            $response->header('Access-Control-Allow-Origin', '*');
            $response->header('Access-Control-Allow-Methods', 'GET, OPTIONS');
            $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
            return $response;
        }
        if(!$this->retrieval_is_enabled()){
            return new WP_Error('disabled', 'Chunk engine non attivo.', ['status' => 403]);
        }
        if(!$this->isi_rate_limit('chunks')){
            return new \WP_Error('rate_limited', 'Too many requests', ['status' => 429]);
        }
        $chunks = $this->chunks_get_cached();
        $response = new WP_REST_Response(['generated' => gmdate('c'), 'source' => home_url(), 'chunks' => $chunks]);
        $response->header('Access-Control-Allow-Origin', '*');
        return $response;
    }

    public function chunks_invalidate(){
        delete_transient(self::CHUNKS_TRANSIENT);
    }

    public function chunks_get_cached(){
        $cached = get_transient(self::CHUNKS_TRANSIENT);
        if($cached !== false) return $cached;
        $chunks = $this->chunks_build();
        set_transient(self::CHUNKS_TRANSIENT, $chunks, self::LLM_CACHE_TTL);
        return $chunks;
    }

    private function chunks_build(){
        $schema = $this->schema_opts();
        $faq_items = $this->llm_get_faq_items();
        $name = trim((string)($schema['name'] ?? get_bloginfo('name')));
        $chunks = [];

        // identity
        $parts = [];
        if($name) $parts[] = 'Nome struttura: '.$name;
        if(!empty($schema['type'])) $parts[] = 'Tipologia: '.$schema['type'];
        if(!empty($schema['city'])) $parts[] = 'Citta: '.$schema['city'];
        if(!empty($schema['description'])) $parts[] = 'Descrizione: '.wp_trim_words(sanitize_text_field($schema['description']), 50, '...');
        if($parts) $chunks[] = $this->chunks_make('identity', 'Identita struttura', implode('. ', $parts).'.', ['name','type','location'], 'schema');

        // contact
        $parts = [];
        if(!empty($schema['address'])) $parts[] = 'Indirizzo: '.sanitize_text_field($schema['address']);
        if(!empty($schema['telephone'])) $parts[] = 'Telefono: '.sanitize_text_field($schema['telephone']);
        if(!empty($schema['email'])) $parts[] = 'Email: '.sanitize_email($schema['email']);
        if(!empty($schema['url'])) $parts[] = 'Sito: '.esc_url_raw($schema['url']);
        if(!empty($schema['checkin_time'])) $parts[] = 'Check-in: '.sanitize_text_field($schema['checkin_time']);
        if(!empty($schema['checkout_time'])) $parts[] = 'Check-out: '.sanitize_text_field($schema['checkout_time']);
        if(!empty($schema['pets_allowed'])) $parts[] = 'Animali ammessi: '.sanitize_text_field($schema['pets_allowed']);
        if(!empty($schema['price_range'])) $parts[] = 'Fascia prezzo: '.sanitize_text_field($schema['price_range']);
        if($parts) $chunks[] = $this->chunks_make('contact', 'Contatti e info pratiche', implode('. ', $parts).'.', ['contact','address','checkin','checkout'], 'schema');

        // amenities
        $amenities = array_values(array_filter(array_map('sanitize_text_field', (array)($schema['amenities'] ?? []))));
        if($amenities) $chunks[] = $this->chunks_make('amenities', 'Servizi e dotazioni', 'Servizi disponibili: '.implode(', ', $amenities).'.', ['services','amenities','facilities'], 'schema');

        // rooms
        foreach((array)($schema['rooms'] ?? []) as $room){
            if(!is_array($room)) continue;
            $room_name = sanitize_text_field($room['name'] ?? '');
            if(!$room_name) continue;
            $parts = ['Camera: '.$room_name];
            if(!empty($room['description'])) $parts[] = sanitize_text_field($room['description']);
            if(!empty($room['amenities']) && is_array($room['amenities'])) $parts[] = 'Dotazioni: '.implode(', ', array_map('sanitize_text_field', $room['amenities']));
            $chunks[] = $this->chunks_make('room', $room_name, implode('. ', $parts).'.', ['room','accommodation',sanitize_title($room_name)], 'schema');
        }

        // offers
        foreach((array)($schema['offers'] ?? []) as $offer){
            if(!is_array($offer)) continue;
            $offer_name = sanitize_text_field($offer['name'] ?? '');
            if(!$offer_name) continue;
            $parts = ['Offerta: '.$offer_name];
            if(!empty($offer['description'])) $parts[] = sanitize_text_field($offer['description']);
            if(!empty($offer['price'])) $parts[] = 'Prezzo: '.sanitize_text_field($offer['price']);
            $chunks[] = $this->chunks_make('offer', $offer_name, implode('. ', $parts).'.', ['offer','price','deal'], 'schema');
        }

        // faq
        foreach($faq_items as $faq){
            $q = wp_strip_all_tags($faq['question'] ?? '');
            $a = wp_strip_all_tags($faq['answer'] ?? '');
            if(!$q || !$a) continue;
            $chunks[] = $this->chunks_make('faq', $q, 'Domanda: '.$q.' Risposta: '.$a, ['faq','question','answer'], 'faq', true);
        }

        return $chunks;
    }

    private function chunks_make($type, $title, $content, $tags, $source, $is_qa = false){
        $content_clean = wp_strip_all_tags($content);
        $words = str_word_count($content_clean);
        return [
            'id'              => sanitize_title($type.'-'.$title),
            'type'            => $type,
            'title'           => $title,
            'content'         => $content_clean,
            'tokens_estimate' => (int)ceil($words * 1.3),
            'citation_score'  => $this->chunks_citation_score($content_clean, $type, $is_qa),
            'retrieval_tags'  => $tags,
            'source'          => $source,
        ];
    }

    private function chunks_citation_score($content, $type, $is_qa = false){
        $score = 40;
        $words = str_word_count(wp_strip_all_tags($content));
        if($is_qa) $score += 25;
        if($words < 80) $score += 15; elseif($words < 150) $score += 8;
        if(preg_match('/\d{2}:\d{2}|\d+\s*euro|\b[\w.]+@[\w.]+\b|https?:\/\//i', $content)) $score += 15;
        if($type === 'contact') $score += 10;
        if($type === 'faq') $score += 5;
        return min(100, $score);
    }

    public function chunks_page(){
        if(!current_user_can('manage_options')) return;
        $chunks = $this->chunks_get_cached();
        $rest_url = esc_url(rest_url('in3pida/v1/chunks'));
        $enabled = $this->retrieval_is_enabled();
        echo '<div class="wrap in3pida-admin in3pida-admin-pro">';
        $this->admin_header('Chunk Engine: contenuti segmentati per retrieval AI');
        echo '<div class="in3pida-grid">';

        echo '<section class="in3pida-card"><h2>⚙️ Stato</h2><p class="in3pida-card-desc">Il Chunk Engine segmenta automaticamente i dati Schema.org e FAQ in blocchi ottimizzati per il retrieval AI. Non richiede configurazione manuale.</p>';
        echo '<div class="in3pida-kpi-grid">';
        echo '<div><strong>Chunk totali</strong><span>'.count($chunks).'</span></div>';
        $scores = array_column($chunks, 'citation_score');
        $avg_score = $scores ? round(array_sum($scores) / count($scores)) : 0;
        echo '<div><strong>Citation score medio</strong><span>'.$avg_score.'/100</span></div>';
        $total_tokens = array_sum(array_column($chunks, 'tokens_estimate'));
        echo '<div><strong>Token totali stimati</strong><span>'.$total_tokens.'</span></div>';
        echo '</div>';
        if($enabled){
            echo '<div class="in3pida-note"><strong>REST endpoint:</strong> <a href="'.esc_url($rest_url).'" target="_blank"><code>'.esc_html($rest_url).'</code></a></div>';
        } else {
            echo '<div class="in3pida-note">Il REST endpoint pubblico si attiva abilitando il <strong>LLM ready layer</strong>. I chunk sono comunque generati e usati internamente.</div>';
        }
        echo '</section>';

        if($chunks){
            $types = ['identity' => '🏨', 'contact' => '📞', 'amenities' => '🛎️', 'room' => '🛏️', 'offer' => '🏷️', 'faq' => '❓'];
            echo '<section class="in3pida-card"><h2>📦 Chunk generati</h2><p class="in3pida-card-desc">Ogni chunk rappresenta un blocco semantico indipendente. Il citation score indica quanto quel blocco e probabile venga citato da un AI durante una risposta.</p>';
            echo '<div class="in3pida-report-list">';
            foreach($chunks as $chunk){
                $score = intval($chunk['citation_score']);
                $score_color = $score >= 70 ? '#0D5F75' : ($score >= 50 ? '#0D5F75' : '#0D5F75');
                $icon = $types[$chunk['type']] ?? '📄';
                echo '<div class="in3pida-repeat-box">';
                echo '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">';
                echo '<strong>'.$icon.' '.esc_html($chunk['title']).'</strong>';
                echo '<span style="color:'.esc_attr($score_color).';font-weight:700">Score: '.$score.'/100</span>';
                echo '</div>';
                echo '<div style="font-size:12px;color:#666;margin-bottom:4px">Tipo: <code>'.esc_html($chunk['type']).'</code> &nbsp;|&nbsp; Token stimati: '.esc_html($chunk['tokens_estimate']).' &nbsp;|&nbsp; Sorgente: '.esc_html($chunk['source']).'</div>';
                $preview = mb_strimwidth($chunk['content'], 0, 180, '...');
                echo '<div style="font-size:13px;color:#444;line-height:1.5">'.esc_html($preview).'</div>';
                if(!empty($chunk['retrieval_tags'])){
                    echo '<div style="margin-top:6px">';
                    foreach($chunk['retrieval_tags'] as $tag) echo '<code style="margin-right:4px;font-size:11px">'.esc_html($tag).'</code>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div></section>';
        } else {
            echo '<section class="in3pida-card"><h2>📦 Nessun chunk</h2><div class="in3pida-note in3pida-alert">Compila <strong>Schema.org</strong> e aggiungi <strong>FAQ</strong> per generare i chunk.</div></section>';
        }
        echo '</div></div>';
    }

    // ── END CHUNK ENGINE ─────────────────────────────────────────────────────────

    // ── ENTITY GRAPH ─────────────────────────────────────────────────────────────

    private function entity_graph_lines($text){
        return array_values(array_filter(array_map('trim', explode("\n", str_replace("\r", "\n", (string)$text)))));
    }

    public function entity_graph_invalidate(){
        delete_transient(self::ENTITY_GRAPH_TRANSIENT);
    }

    public function entity_graph_get_cached(){
        $cached = get_transient(self::ENTITY_GRAPH_TRANSIENT);
        if($cached !== false) return $cached;
        $graph = $this->entity_graph_build();
        set_transient(self::ENTITY_GRAPH_TRANSIENT, $graph, self::LLM_CACHE_TTL);
        return $graph;
    }

    private function entity_graph_build(){
        $schema = $this->schema_opts();
        $faq_items = $this->llm_get_faq_items();
        $name = trim((string)($schema['name'] ?? get_bloginfo('name')));

        // Read query targets, POI and topics from existing Schema.org fields
        $query_targets = $this->llm_csv_items($schema['keywords'] ?? '', 30);
        $poi_list      = array_values(array_unique(array_merge(
            $this->csv_items($schema['nearby_attractions'] ?? ''),
            $this->csv_items($schema['area_served'] ?? '')
        )));
        $topics        = array_values(array_unique(array_merge(
            array_map('sanitize_text_field', (array)($schema['targets'] ?? [])),
            array_map('sanitize_text_field', (array)($schema['knows_about'] ?? []))
        )));
        $poi_list   = array_values(array_filter($poi_list));
        $topics     = array_values(array_filter($topics));

        $nodes = [];

        // Hotel node
        $hotel_node = ['id' => 'hotel', 'type' => 'LodgingBusiness', 'label' => $name, 'properties' => []];
        foreach(['type' => 'tipologia', 'city' => 'citta', 'address' => 'indirizzo', 'telephone' => 'telefono', 'email' => 'email', 'url' => 'sito', 'checkin_time' => 'checkin', 'checkout_time' => 'checkout', 'price_range' => 'fascia_prezzo', 'pets_allowed' => 'animali'] as $sk => $label){
            $v = trim((string)($schema[$sk] ?? ''));
            if($v) $hotel_node['properties'][$label] = sanitize_text_field($v);
        }
        $nodes[] = $hotel_node;

        // Location node
        $city = trim((string)($schema['city'] ?? ''));
        if($city){
            $nodes[] = ['id' => 'location-'.sanitize_title($city), 'type' => 'City', 'label' => $city, 'properties' => ['regione' => sanitize_text_field($schema['region'] ?? '')]];
        }

        // Amenities node
        $amenities = array_values(array_filter(array_map('sanitize_text_field', (array)($schema['amenities'] ?? []))));
        if($amenities){
            $nodes[] = ['id' => 'amenities', 'type' => 'AmenityList', 'label' => 'Servizi e dotazioni', 'properties' => ['items' => $amenities]];
        }

        // Room nodes
        foreach((array)($schema['rooms'] ?? []) as $i => $room){
            if(!is_array($room) || empty($room['name'])) continue;
            $rname = sanitize_text_field($room['name']);
            $props = [];
            foreach(['description', 'bed', 'price', 'view'] as $rk){
                if(!empty($room[$rk])) $props[$rk] = sanitize_text_field($room[$rk]);
            }
            $nodes[] = ['id' => 'room-'.sanitize_title($rname), 'type' => 'Accommodation', 'label' => $rname, 'properties' => $props];
        }

        // FAQ nodes
        foreach($faq_items as $i => $faq){
            $q = wp_strip_all_tags($faq['question'] ?? '');
            if(!$q) continue;
            $nodes[] = ['id' => 'faq-'.$i, 'type' => 'FAQItem', 'label' => $q, 'properties' => ['answer' => wp_strip_all_tags($faq['answer'] ?? '')]];
        }

        // Query target nodes (da Schema.org keywords)
        foreach($query_targets as $i => $qt){
            $nodes[] = ['id' => 'query-'.$i, 'type' => 'QueryTarget', 'label' => $qt, 'properties' => []];
        }

        // POI nodes (da Schema.org nearby_attractions + area_served)
        foreach($poi_list as $i => $poi){
            $nodes[] = ['id' => 'poi-'.sanitize_title($poi), 'type' => 'NearbyPOI', 'label' => $poi, 'properties' => []];
        }

        // Topic cluster nodes (da Schema.org targets + knows_about)
        foreach($topics as $i => $topic){
            $nodes[] = ['id' => 'topic-'.sanitize_title($topic), 'type' => 'TopicCluster', 'label' => $topic, 'properties' => []];
        }

        // Relations
        $relations = [];
        if($city) $relations[] = ['from' => 'hotel', 'to' => 'location-'.sanitize_title($city), 'type' => 'locatedIn'];
        if($amenities) $relations[] = ['from' => 'hotel', 'to' => 'amenities', 'type' => 'hasAmenity'];
        foreach((array)($schema['rooms'] ?? []) as $room){
            if(!is_array($room) || empty($room['name'])) continue;
            $relations[] = ['from' => 'hotel', 'to' => 'room-'.sanitize_title($room['name']), 'type' => 'hasAccommodation'];
        }
        foreach($faq_items as $i => $faq){
            if(empty($faq['question'])) continue;
            $relations[] = ['from' => 'hotel', 'to' => 'faq-'.$i, 'type' => 'hasFAQ'];
        }
        foreach($query_targets as $i => $qt){
            $relations[] = ['from' => 'hotel', 'to' => 'query-'.$i, 'type' => 'targetQuery'];
        }
        foreach($poi_list as $i => $poi){
            $relations[] = ['from' => 'hotel', 'to' => 'poi-'.sanitize_title($poi), 'type' => 'nearTo'];
        }
        foreach($topics as $i => $topic){
            $relations[] = ['from' => 'hotel', 'to' => 'topic-'.sanitize_title($topic), 'type' => 'belongsToTopic'];
        }

        return [
            'generated'      => gmdate('c'),
            'source'         => home_url(),
            'entity_name'    => $name,
            'nodes'          => $nodes,
            'relations'      => $relations,
            'stats'          => [
                'total_nodes'     => count($nodes),
                'total_relations' => count($relations),
                'query_targets'   => count($query_targets),
                'poi_nearby'      => count($poi_list),
                'topic_clusters'  => count($topics),
            ],
        ];
    }

    public function register_entity_graph_rest_routes(){
        register_rest_route('in3pida/v1', '/graph', [
            'methods'             => 'GET',
            'callback'            => [$this, 'entity_graph_rest_handler'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function entity_graph_rest_handler($request){
        if(!$this->retrieval_is_enabled()){
            return new WP_Error('disabled', 'Entity graph non attivo.', ['status' => 403]);
        }
        if(!$this->isi_rate_limit('graph')){
            return new \WP_Error('rate_limited', 'Too many requests', ['status' => 429]);
        }
        return rest_ensure_response($this->entity_graph_get_cached());
    }

    public function entity_graph_page(){
        if(!current_user_can('manage_options')) return;
        $graph = $this->entity_graph_get_cached();
        $rest_url = esc_url(rest_url('in3pida/v1/graph'));
        $enabled = $this->retrieval_is_enabled();
        echo '<div class="wrap in3pida-admin in3pida-admin-pro">';
        $this->admin_header('Entity Graph: mappa delle relazioni semantiche della struttura');
        echo '<div class="in3pida-grid">';

        // Stats card
        $stats = $graph['stats'] ?? [];
        echo '<section class="in3pida-card"><h2>📊 Stato grafo</h2><p class="in3pida-card-desc">Il grafo mappa le relazioni tra tutte le entita della struttura. Le entita base vengono da Schema.org e FAQ automaticamente. Query target, POI vicini e topic cluster si inseriscono manualmente.</p>';
        echo '<div class="in3pida-kpi-grid">';
        echo '<div><strong>Nodi totali</strong><span>'.esc_html($stats['total_nodes'] ?? 0).'</span></div>';
        echo '<div><strong>Relazioni</strong><span>'.esc_html($stats['total_relations'] ?? 0).'</span></div>';
        echo '<div><strong>Query target</strong><span>'.esc_html($stats['query_targets'] ?? 0).'</span></div>';
        echo '<div><strong>POI vicini</strong><span>'.esc_html($stats['poi_nearby'] ?? 0).'</span></div>';
        echo '<div><strong>Topic cluster</strong><span>'.esc_html($stats['topic_clusters'] ?? 0).'</span></div>';
        echo '</div>';
        if($enabled) echo '<div class="in3pida-note"><strong>REST endpoint:</strong> <a href="'.esc_url($rest_url).'" target="_blank"><code>'.esc_html($rest_url).'</code></a></div>';
        else echo '<div class="in3pida-note">Il REST endpoint pubblico si attiva abilitando il <strong>LLM ready layer</strong>. Il grafo è comunque generato e usato internamente.</div>';
        echo '</section>';

        // Fonti automatiche da Schema.org
        $schema = $this->schema_opts();
        $schema_url = esc_url(admin_url('admin.php?page=in3pida-schemaorg'));
        $qt_list  = $this->llm_csv_items($schema['keywords'] ?? '', 30);
        $poi_show = array_values(array_unique(array_merge($this->csv_items($schema['nearby_attractions'] ?? ''), $this->csv_items($schema['area_served'] ?? ''))));
        $poi_show = array_values(array_filter($poi_show));
        $tc_show  = array_values(array_unique(array_merge(array_map('sanitize_text_field', (array)($schema['targets'] ?? [])), array_map('sanitize_text_field', (array)($schema['knows_about'] ?? [])))));
        $tc_show  = array_values(array_filter($tc_show));

        echo '<section class="in3pida-card"><h2>🔄 Dati automatici da Schema.org</h2><p class="in3pida-card-desc">Query target, POI vicini e topic cluster vengono letti direttamente da Schema.org. Per modificarli vai su <a href="'.esc_url($schema_url).'">Schema.org → Audience e posizionamento AI</a>.</p>';
        echo '<div class="in3pida-fields">';

        echo '<div class="in3pida-note"><strong>Query target</strong> (da <em>Keywords semantiche</em> in Schema.org)<br>';
        if($qt_list) foreach($qt_list as $qt) echo '<code style="margin:2px 4px 2px 0;display:inline-block">'.esc_html($qt).'</code>';
        else echo '<em style="color:#888">Nessuna keyword inserita in Schema.org → sezione Audience e posizionamento AI.</em>';
        echo '</div>';

        echo '<div class="in3pida-note"><strong>POI vicini</strong> (da <em>Attrazioni vicine</em> e <em>Zone turistiche</em> in Schema.org)<br>';
        if($poi_show) foreach($poi_show as $poi) echo '<code style="margin:2px 4px 2px 0;display:inline-block">'.esc_html($poi).'</code>';
        else echo '<em style="color:#888">Nessuna attrazione/zona inserita in Schema.org → sezione Audience e posizionamento AI.</em>';
        echo '</div>';

        echo '<div class="in3pida-note"><strong>Topic cluster</strong> (da <em>Target clienti</em> e <em>KnowsAbout</em> in Schema.org)<br>';
        if($tc_show) foreach($tc_show as $tc) echo '<code style="margin:2px 4px 2px 0;display:inline-block">'.esc_html($tc).'</code>';
        else echo '<em style="color:#888">Nessun target o tema inserito in Schema.org → sezione Audience e posizionamento AI.</em>';
        echo '</div>';

        echo '<div class="in3pida-note" style="background:#fff;border-color:#e4e4ec"><strong>Come aggiornare:</strong> modifica i dati in <a href="'.esc_url($schema_url).'">Schema.org → Audience e posizionamento AI</a> e salva. Il grafo si aggiorna automaticamente.</div>';
        echo '</div></section>';

        // Graph visualization
        if(!empty($graph['nodes'])){
            $type_icons = ['LodgingBusiness' => '🏨', 'City' => '📍', 'AmenityList' => '🛎️', 'Accommodation' => '🛏️', 'FAQItem' => '❓', 'QueryTarget' => '🎯', 'NearbyPOI' => '🗺️', 'TopicCluster' => '🏷️'];
            echo '<section class="in3pida-card"><h2>🕸️ Nodi del grafo</h2><p class="in3pida-card-desc">Ogni nodo rappresenta un\'entita. Le relazioni tra i nodi definiscono il contesto semantico della struttura per i sistemi AI.</p>';
            echo '<div class="in3pida-report-list">';
            $current_type = '';
            foreach($graph['nodes'] as $node){
                $t = $node['type'] ?? '';
                if($t !== $current_type){
                    if($current_type) echo '</div>';
                    $icon = $type_icons[$t] ?? '📄';
                    echo '<div class="in3pida-repeat-box"><h4 style="margin:0 0 8px">'.$icon.' '.esc_html($t).'</h4><div style="display:flex;flex-wrap:wrap;gap:6px">';
                    $current_type = $t;
                }
                echo '<span style="background:#f0f0f0;padding:3px 8px;border-radius:4px;font-size:12px">'.esc_html($node['label']).'</span>';
            }
            if($current_type) echo '</div></div>';
            echo '</div></section>';
        }

        echo '</div></div>';
    }

    // ── END ENTITY GRAPH ──────────────────────────────────────────────────────────

    // ── CITATION ENGINE ───────────────────────────────────────────────────────────

    public function citation_invalidate(){
        delete_transient(self::CITATION_TRANSIENT);
    }

    public function citation_get_cached(){
        $cached = get_transient(self::CITATION_TRANSIENT);
        if($cached !== false) return $cached;
        $blocks = $this->citation_build();
        set_transient(self::CITATION_TRANSIENT, $blocks, 12 * HOUR_IN_SECONDS);
        return $blocks;
    }

    private function citation_score($answer, $category){
        $score = 40;
        $len = mb_strlen($answer);
        if($len >= 20 && $len <= 200) $score += 15;
        if(preg_match('/\d/', $answer)) $score += 15;
        if(preg_match('/\d{1,2}[:h]\d{2}/', $answer)) $score += 10;
        if(preg_match('/[€$£]\s*\d|prezzo|costo|tariffa/i', $answer)) $score += 10;
        if($category === 'faq') $score += 8;
        if(substr_count($answer, '.') <= 1) $score += 7;
        return min(100, $score);
    }

    private function citation_block($id, $category, $cat_label, $question, $answer, $source){
        return [
            'id'             => $id,
            'category'       => $category,
            'category_label' => $cat_label,
            'question'       => $question,
            'answer'         => $answer,
            'source'         => $source,
            'citability_score' => $this->citation_score($answer, $category),
        ];
    }

    private function citation_build(){
        $schema = $this->schema_opts();
        $blocks = [];

        $name   = trim($schema['name'] ?? '');
        $type   = trim($schema['type'] ?? '');
        $city   = trim($schema['city'] ?? '');
        $street = trim($schema['street_address'] ?? '');
        $zip    = trim($schema['postal_code'] ?? '');

        // --- Identity ---
        if($name && $type){
            $label = $type ? $type : 'struttura ricettiva';
            $location = $city ? " a $city" : '';
            $blocks[] = $this->citation_block('identity-name', 'identity', 'Identit\xc3\xa0', 'Come si chiama la struttura e di che tipo \xc3\xa8?', "$name \xc3\xa8 un $label$location.", 'schema');
        }
        $desc = trim($schema['description'] ?? '');
        if($name && $desc){
            $short = mb_strimwidth($desc, 0, 200, '...');
            $blocks[] = $this->citation_block('identity-description', 'identity', 'Identit\xc3\xa0', "Cos\xc3\xa8 $name?", $short, 'schema');
        }

        // --- Location ---
        if($street && $city){
            $full_address = $street.($zip ? ', '.$zip : '').', '.$city;
            $blocks[] = $this->citation_block('location-address', 'location', 'Posizione', "Dove si trova $name?", ($name ? "$name si trova in " : 'Indirizzo: ').$full_address.'.', 'schema');
        } elseif($city && $name){
            $blocks[] = $this->citation_block('location-city', 'location', 'Posizione', "In quale citt\xc3\xa0 si trova $name?", "$name si trova a $city.", 'schema');
        }
        $nearby = $this->csv_items($schema['nearby_attractions'] ?? '');
        if($nearby && $name){
            $blocks[] = $this->citation_block('location-nearby', 'location', 'Posizione', 'Cosa si trova nelle vicinanze?', ($name ? "$name \xc3\xa8 vicino a: " : 'Nelle vicinanze: ').implode(', ', array_slice($nearby, 0, 5)).'.', 'schema');
        }

        // --- Policy ---
        if(!empty($schema['checkin_time'])){
            $blocks[] = $this->citation_block('policy-checkin', 'policy', 'Policy', "Qual \xc3\xa8 l'orario di check-in?", ($name ? "Il check-in a $name \xc3\xa8 dalle " : 'Check-in dalle ').esc_html($schema['checkin_time']).'.', 'schema');
        }
        if(!empty($schema['checkout_time'])){
            $blocks[] = $this->citation_block('policy-checkout', 'policy', 'Policy', "Qual \xc3\xa8 l'orario di check-out?", ($name ? "Il check-out a $name \xc3\xa8 entro le " : 'Check-out entro le ').esc_html($schema['checkout_time']).'.', 'schema');
        }
        if(!empty($schema['pet_friendly'])){
            $pf = $schema['pet_friendly'];
            $pf_val = is_array($pf) ? (!empty($pf['allowed']) ? 'ammessi' : 'non ammessi') : (intval($pf) ? 'ammessi' : 'non ammessi');
            $blocks[] = $this->citation_block('policy-pets', 'policy', 'Policy', 'Sono ammessi gli animali domestici?', ($name ? "A $name gli animali domestici sono " : 'Animali domestici: ').$pf_val.'.', 'schema');
        }

        // --- Services ---
        $amenities = array_filter((array)($schema['amenities'] ?? []), function($a){ return is_string($a) && trim($a) !== ''; });
        if($amenities && $name){
            $blocks[] = $this->citation_block('services-list', 'services', 'Servizi', "Quali servizi offre $name?", "$name offre: ".implode(', ', array_slice(array_values($amenities), 0, 10)).'.', 'schema');
        }

        // --- Rooms ---
        $rooms = array_filter((array)($schema['rooms'] ?? []), function($r){ return is_array($r) && !empty($r['name']); });
        foreach(array_values($rooms) as $i => $room){
            $rname = sanitize_text_field($room['name']);
            $parts = [];
            if(!empty($room['max_occupancy'])) $parts[] = 'fino a '.intval($room['max_occupancy']).' ospiti';
            if(!empty($room['bed_type']))      $parts[] = 'letto '.sanitize_text_field($room['bed_type']);
            if(!empty($room['price_from']))    $parts[] = 'prezzo da '.sanitize_text_field($room['price_from']).' \xe2\x82\xac';
            if(!$parts) continue;
            $blocks[] = $this->citation_block('room-'.($i+1), 'rooms', 'Camere', "Com\xc3\xa8 la camera $rname?", "$rname: ".implode(', ', $parts).'.', 'schema');
        }

        // --- Pricing ---
        if(!empty($schema['price_range'])){
            $blocks[] = $this->citation_block('pricing-range', 'pricing', 'Prezzi', ($name ? "Qual \xc3\xa8 la fascia di prezzo di $name?" : "Qual \xc3\xa8 la fascia di prezzo?"), ($name ? "$name ha una fascia di prezzo: " : 'Fascia di prezzo: ').sanitize_text_field($schema['price_range']).'.', 'schema');
        }
        $offers = array_filter((array)($schema['offers'] ?? []), function($o){ return is_array($o) && (!empty($o['name']) || !empty($o['price_from'])); });
        foreach(array_values($offers) as $i => $offer){
            $oname = sanitize_text_field($offer['name'] ?? 'Offerta '.($i+1));
            $oprice = !empty($offer['price_from']) ? ' da '.sanitize_text_field($offer['price_from']).' \xe2\x82\xac' : '';
            $blocks[] = $this->citation_block('offer-'.($i+1), 'pricing', 'Prezzi', "Offerta: $oname", "$oname$oprice.".(!empty($offer['description']) ? ' '.mb_strimwidth(sanitize_text_field($offer['description']), 0, 100, '...') : ''), 'schema');
        }

        // --- Ratings ---
        if(!empty($schema['rating_value'])){
            $source_label = !empty($schema['rating_source']) ? ' ('.$schema['rating_source'].')' : '';
            $reviews = !empty($schema['review_count']) ? ' su '.intval($schema['review_count']).' recensioni' : '';
            $blocks[] = $this->citation_block('ratings-main', 'ratings', 'Rating', ($name ? "Qual \xc3\xa8 il rating di $name?" : "Qual \xc3\xa8 il rating della struttura?"), ($name ? "$name ha un rating di " : 'Rating: ').sanitize_text_field($schema['rating_value']).$reviews.$source_label.'.', 'schema');
        }

        // --- FAQ ---
        $faq_posts = get_posts(['post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 20, 'orderby' => 'menu_order', 'order' => 'ASC']);
        foreach($faq_posts as $i => $post){
            $q = trim($post->post_title);
            $a = wp_strip_all_tags($post->post_content);
            $a = preg_replace('/\s+/', ' ', trim($a));
            if(!$q || !$a) continue;
            $a_short = mb_strimwidth($a, 0, 250, '...');
            $blocks[] = $this->citation_block('faq-'.($i+1), 'faq', 'FAQ', $q, $a_short, 'faq');
        }

        usort($blocks, function($a, $b){ return $b['citability_score'] - $a['citability_score']; });
        return $blocks;
    }

    public function register_citation_rest_routes(){
        register_rest_route('in3pida/v1', '/citation', [
            'methods'             => 'GET',
            'callback'            => [$this, 'citation_rest_handler'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function citation_rest_handler($request){
        if(!$this->retrieval_is_enabled()) return new WP_Error('disabled', 'LLM layer not active', ['status' => 403]);
        if(!$this->isi_rate_limit('citation')) return new \WP_Error('rate_limited', 'Too many requests', ['status' => 429]);
        $blocks = $this->citation_get_cached();
        return rest_ensure_response(['generated' => gmdate('c'), 'source' => home_url(), 'total' => count($blocks), 'blocks' => $blocks]);
    }

    public function citation_page(){
        if(!current_user_can('manage_options')) return;
        $blocks   = $this->citation_get_cached();
        $enabled  = $this->retrieval_is_enabled();
        $rest_url = esc_url(rest_url('in3pida/v1/citation'));
        echo '<div class="wrap in3pida-admin in3pida-admin-pro">';
        $this->admin_header('Citation Engine: blocchi di contenuto ottimizzati per essere citati dagli AI');
        echo '<div class="in3pida-grid">';

        $avg = $blocks ? round(array_sum(array_column($blocks, 'citability_score')) / count($blocks)) : 0;
        $high = count(array_filter($blocks, function($b){ return $b['citability_score'] >= 70; }));
        echo '<section class="in3pida-card"><h2>📊 Stato Citation Engine</h2><p class="in3pida-card-desc">Il Citation Engine genera automaticamente blocchi strutturati question→answer dai dati Schema.org e FAQ. Ogni blocco ha un citability score che indica la probabilita che un AI lo citi in una risposta.</p>';
        echo '<div class="in3pida-kpi-grid">';
        echo '<div><strong>Blocchi totali</strong><span>'.count($blocks).'</span></div>';
        echo '<div><strong>Score medio</strong><span>'.$avg.'/100</span></div>';
        echo '<div><strong>Blocchi score 70+</strong><span>'.$high.'</span></div>';
        echo '</div>';
        if($enabled) echo '<div class="in3pida-note"><strong>REST endpoint:</strong> <a href="'.esc_url($rest_url).'" target="_blank"><code>'.esc_html($rest_url).'</code></a></div>';
        else echo '<div class="in3pida-note">Il REST endpoint si attiva abilitando il <strong>LLM ready layer</strong>. I blocchi sono comunque generati e usati internamente.</div>';
        echo '</section>';

        $cat_icons = ['identity'=>'🏨','location'=>'📍','policy'=>'📋','services'=>'🛎️','rooms'=>'🛏️','pricing'=>'💶','ratings'=>'⭐','faq'=>'❓'];
        $categories = [];
        foreach($blocks as $b) $categories[$b['category']] = $b['category_label'];

        foreach($categories as $cat => $cat_label){
            $cat_blocks = array_values(array_filter($blocks, function($b) use($cat){ return $b['category'] === $cat; }));
            if(!$cat_blocks) continue;
            $icon = $cat_icons[$cat] ?? '📄';
            echo '<section class="in3pida-card"><h2>'.$icon.' '.esc_html($cat_label).'</h2>';
            echo '<div class="in3pida-report-list">';
            foreach($cat_blocks as $block){
                $score = intval($block['citability_score']);
                $score_color = $score >= 70 ? '#0D5F75' : ($score >= 50 ? '#0D5F75' : '#0D5F75');
                echo '<div class="in3pida-repeat-box">';
                echo '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">';
                echo '<strong style="font-size:13px">'.esc_html($block['question']).'</strong>';
                echo '<span style="color:'.esc_attr($score_color).';font-weight:700;white-space:nowrap;margin-left:12px">Score: '.$score.'/100</span>';
                echo '</div>';
                echo '<div style="font-size:13px;color:#444;line-height:1.5;margin-bottom:4px">'.esc_html($block['answer']).'</div>';
                echo '<div style="font-size:11px;color:#888">Fonte: '.esc_html($block['source']).' &nbsp;|&nbsp; ID: <code>'.esc_html($block['id']).'</code></div>';
                echo '</div>';
            }
            echo '</div></section>';
        }

        if(!$blocks) echo '<section class="in3pida-card"><h2>📭 Nessun blocco</h2><div class="in3pida-note">Compila <strong>Schema.org</strong> e aggiungi <strong>FAQ</strong> per generare i blocchi citation.</div></section>';

        echo '</div></div>';
    }

    // ── END CITATION ENGINE ───────────────────────────────────────────────────────

    public function llm_ready_page(){
        if(!current_user_can('manage_options')) return;
        $layer = $this->llm_get_layer_cached();
        $llm_o = $this->llm_opts();
        echo '<div class="wrap in3pida-admin in3pida-admin-pro in3pida-llm-page">';
        $this->admin_header('LLM ready layer: contenuti chiari, leggibili e facili da interpretare per AI e motori di ricerca');
        echo '<div class="in3pida-grid">';
        echo '<section class="in3pida-card"><h2>⚙️ Attivazione</h2><p class="in3pida-card-desc">Decidi se pubblicare automaticamente il LLM ready layer nel frontend del sito.</p><form method="post" action="options.php">';
        settings_fields('in3pida_llm_ready_settings_group');
        echo '<div class="in3pida-fields"><label class="in3pida-check"><input type="checkbox" name="'.esc_attr(self::LLM_OPTION).'[enabled]" value="1" '.checked($llm_o['enabled'],1,false).'> Abilita LLM ready layer</label><div class="in3pida-note"><strong>Stato:</strong> '.($llm_o['enabled'] ? 'Abilitato' : 'Disabilitato').'. Quando è disabilitato, il plugin non pubblica il layer nel frontend.</div></div><div class="in3pida-savebar in3pida-savebar-inline">';
        submit_button('Salva impostazioni', 'primary in3pida-save', 'submit', false);
        echo '</div></form>';
        if($llm_o['enabled'] && $this->has_physical_robots_txt() && !$this->physical_robots_has_ai_sitemap()){
            echo '<div class="in3pida-note in3pida-robots-notice"><strong>LLM Ready Layer attivo.</strong> Rilevato <code>robots.txt</code> personalizzato. Per includere la AI Sitemap aggiungi: <code>'.esc_html('Sitemap: '.$this->retrieval_base_url('ai-sitemap.xml')).'</code> <button type="button" class="button-link in3pida-robots-help">Come fare?</button><div class="in3pida-robots-modal" style="display:none"><div class="in3pida-robots-modal-box"><button type="button" class="in3pida-robots-close">×</button><h2>Come aggiungere la AI Sitemap al robots.txt</h2><h3>Se usi Yoast SEO</h3><p>Vai in <strong>Yoast SEO → Strumenti → Editor file</strong>, apri <strong>robots.txt</strong>, aggiungi la riga indicata e salva.</p><h3>Se usi Rank Math</h3><p>Vai in <strong>Rank Math → Impostazioni Generali → Modifica robots.txt</strong>, aggiungi la riga indicata e salva.</p><h3>Se non usi un plugin SEO</h3><p>Apri il file <strong>robots.txt</strong> dal File Manager dell\'hosting o via FTP, nella cartella principale del sito, aggiungi la riga indicata e salva.</p><p><strong>Consiglio:</strong> se non hai esperienza tecnica, fai fare questa modifica a un tecnico.</p><code>'.esc_html('Sitemap: '.$this->retrieval_base_url('ai-sitemap.xml')).'</code></div></div></div>';
        }
        echo '</section>';
        $airs = $layer['ai_readiness_score'] ?? [];
        echo '<section class="in3pida-card"><h2>📈 AI Readiness Score</h2><p class="in3pida-card-desc">Punteggio diagnostico automatico: misura quanto il sito è leggibile, strutturato e pronto per retrieval e answer extraction AI. Non modifica contenuti, SEO o frontend.</p>';
        echo '<div class="in3pida-kpi-grid"><div class="in3pida-tip" data-tip="Punteggio complessivo: indica quanto il tuo sito è pronto per essere letto e citato da assistenti AI come ChatGPT, Perplexity o Google AI. Più è alto, meglio le AI trovano e citano le informazioni del tuo hotel."><strong>AI Readiness Score</strong><span>'.esc_html(intval($airs['score'] ?? 0)).'/100</span></div></div>';
        if(!empty($airs['breakdown'])){ $airs_tips=['Structured Data'=>'Dati strutturati Schema.org: nome, indirizzo, telefono, servizi. Aiutano le AI a capire chi sei e cosa offri senza dover leggere tutto il sito.','Content Quality'=>'Qualità dei contenuti: FAQ, descrizioni, servizi. Più sono completi e chiari, più le AI possono rispondere alle domande degli utenti sul tuo hotel.','Retrieval AI-ready'=>'File tecnici per le AI (llms.txt, AI sitemap, knowledge): guidano i robot AI a trovare le informazioni giuste direttamente sul tuo sito.','Answer Extraction'=>'Capacità di fornire risposte dirette: orari check-in, parcheggio, animali, servizi. Le AI usano queste risposte per rispondere agli utenti in modo preciso.','Consistency'=>'Coerenza tra il tuo sito e i portali esterni (Booking, Google, Tripadvisor). Dati coerenti = più affidabilità per le AI e meno rischio di informazioni contraddittorie.']; echo '<h3>Breakdown</h3><div class="in3pida-kpi-grid">'; foreach((array)$airs['breakdown'] as $label=>$value){ $tip=$airs_tips[$label]??''; echo '<div'.($tip?' class="in3pida-tip" data-tip="'.esc_attr($tip).'"':'').'><strong>'.esc_html($label).'</strong><span>'.esc_html(intval($value)).'/100</span></div>'; } echo '</div>'; }
        if(!empty($airs['warnings'])){ echo '<h3>Segnali e suggerimenti</h3><div class="in3pida-report-list">'; foreach((array)$airs['warnings'] as $warn){ echo '<div class="in3pida-note">'.esc_html($warn).'</div>'; } echo '</div>'; }
        echo '</section>';
        echo '<section class="in3pida-card"><h2>📊 Legenda score indicativo</h2><p class="in3pida-card-desc">Valori indicativi per leggere il punteggio in modo realistico. Lo score non garantisce traffico o citazioni, ma misura la preparazione tecnica e contenutistica del sito per sistemi AI.</p><div class="in3pida-table-wrap"><table class="widefat striped in3pida-print-table"><thead><tr><th>Stato sito</th><th>Score indicativo</th></tr></thead><tbody>';
        foreach((array)($airs['legend'] ?? []) as $row){ echo '<tr><td>'.esc_html($row['Stato sito'] ?? '').'</td><td>'.esc_html($row['Score indicativo'] ?? '').'</td></tr>'; }
        echo '</tbody></table></div></section>';
        echo '<section class="in3pida-card"><h2>🔗 Output frontend</h2><p class="in3pida-card-desc">Il LLM ready layer viene inserito automaticamente nel frontend quando il toggle è attivo. Non devi copiare shortcode, non devi creare pagine manuali e non devi incollare codice.</p><div class="in3pida-note"><strong>Funzionamento:</strong> il plugin legge FAQ, Schema.org e dati di coerenza, genera il layer e lo pubblica automaticamente nel sito.</div></section>';
        echo '<section class="in3pida-card"><h2>🛰️ Retrieval AI-ready</h2><p class="in3pida-card-desc">Output automatici generati dal LLM Ready Layer per facilitare lettura, crawling e retrieval da parte di sistemi AI.</p><div class="in3pida-note"><strong>Automatico:</strong> quando il LLM ready layer è attivo, il plugin espone llms.txt, AI sitemap, knowledge index e file Markdown senza compilazioni manuali.</div><div class="in3pida-report-list"><div class="in3pida-note"><strong>llms.txt:</strong> <a href="'.esc_url($this->retrieval_base_url('llms.txt')).'" target="_blank">'.esc_html($this->retrieval_base_url('llms.txt')).'</a></div><div class="in3pida-note"><strong>AI sitemap:</strong> <a href="'.esc_url($this->retrieval_base_url('ai-sitemap.xml')).'" target="_blank">'.esc_html($this->retrieval_base_url('ai-sitemap.xml')).'</a></div><div class="in3pida-note"><strong>Knowledge index:</strong> <a href="'.esc_url($this->retrieval_base_url('knowledge/')).'" target="_blank">'.esc_html($this->retrieval_base_url('knowledge/')).'</a></div><div class="in3pida-note"><strong>Markdown:</strong> /knowledge/overview.md, /knowledge/faq.md, /knowledge/schema.md, /knowledge/servizi.md, /knowledge/citation-friendly.md, /knowledge/answer-extraction.md</div></div></section>';
        $authority = $layer['entity_authority'] ?? [];
        echo '<section class="in3pida-card"><h2>🏛️ Entity Authority score</h2><p class="in3pida-card-desc">Punteggio automatico che valuta quanto l\'entità è riconoscibile e collegata a profili ufficiali. Usa i dati sameAs guidati, i dati Schema.org e, se disponibile, il report di coerenza contenuti.</p><div class="in3pida-kpi-grid"><div><strong>Indice autorevolezza entità</strong><span>'.esc_html($authority['score'] ?? 0).'/100</span></div><div><strong>Profili collegati</strong><span>'.esc_html(count((array)($authority['profiles'] ?? []))).'</span></div><div><strong>Profili consigliati mancanti</strong><span>'.esc_html(count((array)($authority['missing'] ?? []))).'</span></div></div>';
        if(!empty($authority['signals'])){ echo '<div class="in3pida-report-list">'; foreach($authority['signals'] as $sig){ echo '<div class="in3pida-note"><strong>'.esc_html($sig['label']).':</strong> '.esc_html($sig['value']).'</div>'; } echo '</div>'; }
        if(!empty($authority['missing'])) echo '<div class="in3pida-note in3pida-alert"><strong>Consigliati da aggiungere:</strong> '.esc_html(implode(', ', array_slice($authority['missing'],0,8))).'</div>';
        echo '</section>';
        echo '<section class="in3pida-card"><h2>🧠 LLM ready layer</h2><p class="in3pida-card-desc">Questa tab genera automaticamente un livello testuale pulito usando i dati già presenti nel plugin: Schema.org, FAQ e report di coerenza contenuti. Non devi ricompilare i dati hotel.</p><div class="in3pida-note"><strong>Come usarlo:</strong> abilita il layer e controlla l\'anteprima qui sotto. Il frontend viene gestito automaticamente dal plugin.</div></section>';
        echo '<section class="in3pida-card"><h2>📌 Riassunto automatico</h2><div class="in3pida-fields"><div class="in3pida-field"><label>Summary breve</label><textarea readonly>'.esc_textarea($layer['summary_short']).'</textarea></div><div class="in3pida-field"><label>Summary esteso</label><textarea readonly>'.esc_textarea($layer['summary_extended']).'</textarea></div></div></section>';
        echo '<section class="in3pida-card"><h2>✅ Key facts</h2><p class="in3pida-card-desc">Informazioni secche e facilmente leggibili da LLM, motori di ricerca e sistemi di retrieval.</p>';
        if(empty($layer['key_facts'])) echo '<div class="in3pida-note in3pida-alert">Compila prima i dati principali in in3pida schemaorg.</div>'; else { echo '<div class="in3pida-kpi-grid">'; foreach($layer['key_facts'] as $fact){ echo '<div><strong>'.esc_html($fact['label']).'</strong><span>'.esc_html($fact['value']).'</span></div>'; } echo '</div>'; }
        echo '</section>';
        $citation = $layer['citation_friendly'] ?? [];
        echo '<section class="in3pida-card"><h2>📚 Contenuti citation-friendly</h2><p class="in3pida-card-desc">Statistiche, tabelle, definizioni, glossari e comparazioni generati automaticamente dai dati Schema.org, FAQ e Coerenza contenuti.</p>';
        echo '<div class="in3pida-note"><strong>Fonte dati:</strong> '.esc_html($citation['source_note'] ?? 'Dati inseriti nel plugin.').' <br><strong>Aggiornato al:</strong> '.esc_html($citation['updated_at'] ?? '').'</div>';
        if(!empty($citation['statistics'])){ echo '<h3>Statistiche</h3><div class="in3pida-kpi-grid">'; foreach($citation['statistics'] as $stat){ echo '<div><strong>'.esc_html($stat['label']).'</strong><span>'.esc_html($stat['value']).'</span></div>'; } echo '</div>'; }
        if(!empty($citation['tables'])){ foreach($citation['tables'] as $table){ echo '<div class="in3pida-repeat-box"><h3 id="'.esc_attr($table['id']).'">'.esc_html($table['title']).'</h3><div class="in3pida-table-wrap"><table class="widefat striped in3pida-print-table"><thead><tr>'; foreach((array)$table['headers'] as $head){ echo '<th>'.esc_html($head).'</th>'; } echo '</tr></thead><tbody>'; foreach((array)$table['rows'] as $row){ echo '<tr>'; foreach((array)$table['headers'] as $head){ echo '<td>'.esc_html($row[$head] ?? '').'</td>'; } echo '</tr>'; } echo '</tbody></table></div></div>'; } }
        if(!empty($citation['definitions'])){ echo '<h3>Definizioni</h3><div class="in3pida-report-list">'; foreach($citation['definitions'] as $def){ echo '<div class="in3pida-note"><strong>'.esc_html($def['term']).':</strong> '.esc_html($def['definition']).'</div>'; } echo '</div>'; }
        if(!empty($citation['glossary'])){ echo '<h3>Glossario</h3><div class="in3pida-report-list">'; foreach($citation['glossary'] as $gl){ echo '<div class="in3pida-note"><strong>'.esc_html($gl['term']).':</strong> '.esc_html($gl['definition']).'</div>'; } echo '</div>'; }
        if(!empty($citation['comparisons'])){ echo '<h3>Comparazioni</h3><div class="in3pida-report-list">'; foreach($citation['comparisons'] as $cmp){ echo '<div class="in3pida-note"><strong>'.esc_html($cmp['label']).':</strong> '.esc_html($cmp['left']).' / '.esc_html($cmp['right']).'</div>'; } echo '</div>'; }
        if(empty($citation['statistics']) && empty($citation['tables']) && empty($citation['definitions']) && empty($citation['glossary']) && empty($citation['comparisons'])) echo '<div class="in3pida-note in3pida-alert">Compila Schema.org e FAQ per generare contenuti citation-friendly.</div>';
        echo '</section>';
        $ae = $layer['answer_extraction'] ?? [];
        echo '<section class="in3pida-card"><h2>🎯 Answer extraction</h2><p class="in3pida-card-desc">Analisi automatica dei contenuti per verificare se le AI possono estrarre risposte dirette, concise e citabili.</p>';
        echo '<div class="in3pida-kpi-grid"><div><strong>AI Answer Score</strong><span>'.esc_html(intval($ae['score'] ?? 0)).'/100</span></div><div><strong>Aggiornato al</strong><span>'.esc_html($ae['updated_at'] ?? '').'</span></div></div>';
        if(!empty($ae['checks'])){ echo '<h3>Check automatici</h3><div class="in3pida-report-list">'; foreach((array)$ae['checks'] as $check){ echo '<div class="in3pida-note"><strong>'.esc_html($check['label']).':</strong> '.esc_html($check['status']).'</div>'; } echo '</div>'; }
        if(!empty($ae['optimized_answers'])){ echo '<h3>Risposte dirette generate</h3><div class="in3pida-report-list">'; foreach((array)$ae['optimized_answers'] as $ans){ echo '<div class="in3pida-note"><strong>'.esc_html($ans['question']).'</strong><br>'.esc_html($ans['answer']).'</div>'; } echo '</div>'; }
        if(!empty($ae['suggestions'])){ echo '<h3>Suggerimenti</h3><div class="in3pida-report-list">'; foreach((array)$ae['suggestions'] as $sugg){ echo '<div class="in3pida-note">'.esc_html($sugg).'</div>'; } echo '</div>'; }
        echo '</section>';
        $qs = $layer['quality_safety'] ?? [];
        echo '<section class="in3pida-card"><h2>🛡️ Controlli qualità AI/SEO sicuri</h2><p class="in3pida-card-desc">Controlli automatici backend: non riscrivono contenuti, non aggiungono carico al frontend e non modificano le pagine principali del sito.</p>';
        echo '<div class="in3pida-kpi-grid"><div><strong>Quality safety score</strong><span>'.esc_html(intval($qs['score'] ?? 0)).'/100</span></div><div><strong>Ultimo aggiornamento reale</strong><span>'.esc_html($qs['updated_at'] ?? '').'</span></div><div><strong>Duplicate safety</strong><span>'.esc_html(($qs['duplicate_safety']['status'] ?? '') === 'ok' ? 'attiva' : 'da verificare').'</span></div></div>';
        if(!empty($qs['duplicate_safety']['message'])) echo '<div class="in3pida-note"><strong>Noindex/canonical intelligente:</strong> '.esc_html($qs['duplicate_safety']['message']).'</div>';
        if(!empty($qs['schema_checks'])){ echo '<h3>Schema validator interno</h3><div class="in3pida-report-list">'; foreach((array)$qs['schema_checks'] as $check){ echo '<div class="in3pida-note"><strong>'.esc_html($check['label']).':</strong> '.esc_html($check['status']).' - '.esc_html($check['message']).'</div>'; } echo '</div>'; }
        echo '<h3>Entity consistency check</h3>';
        if(empty($qs['consistency_warnings'])) echo '<div class="in3pida-note"><strong>OK:</strong> nessuna incoerenza evidente tra Schema.org e FAQ.</div>'; else { echo '<div class="in3pida-report-list">'; foreach((array)$qs['consistency_warnings'] as $warn){ echo '<div class="in3pida-note in3pida-alert">'.esc_html($warn).'</div>'; } echo '</div>'; }
        echo '</section>';
        $vis = $layer['ai_visibility_monitor'] ?? [];
        echo '<section class="in3pida-card"><h2>👁️ Segnali AI visibility interni</h2><p class="in3pida-card-desc">Stima tecnica automatica e leggera: usa solo i dati già presenti nel plugin. Non misura citazioni reali su motori AI e non usa API esterne.</p>';
        echo '<div class="in3pida-note"><strong>Nota:</strong> '.esc_html($vis['note'] ?? 'Monitor interno senza interrogazioni esterne.').'</div>';
        echo '<div class="in3pida-kpi-grid"><div><strong>Potenziale interno</strong><span>'.esc_html(intval($vis['score'] ?? 0)).'/100</span></div><div><strong>Livello stimato</strong><span>'.esc_html($vis['level'] ?? 'n/d').'</span></div><div><strong>Brand</strong><span>'.esc_html($vis['brand'] ?? '').'</span></div><div><strong>Aggiornato al</strong><span>'.esc_html($vis['updated_at'] ?? '').'</span></div></div>';
        if(!empty($vis['checks'])){ echo '<h3>Segnali monitorati</h3><div class="in3pida-report-list">'; foreach((array)$vis['checks'] as $check){ echo '<div class="in3pida-note"><strong>'.esc_html($check['label']).':</strong> '.esc_html($check['status']).' - '.esc_html($check['value']).'</div>'; } echo '</div>'; }
        if(!empty($vis['keywords'])) echo '<div class="in3pida-note"><strong>Keyword automatiche:</strong> '.esc_html(implode(', ', (array)$vis['keywords'])).'</div>';
        if(!empty($vis['faq_ready'])){ echo '<h3>FAQ extraction-ready</h3><div class="in3pida-report-list">'; foreach((array)$vis['faq_ready'] as $q){ echo '<div class="in3pida-note">'.esc_html($q).'</div>'; } echo '</div>'; } if(!empty($vis['intents'])){ echo '<h3>Intenti di ricerca suggeriti</h3><div class="in3pida-report-list">'; foreach((array)$vis['intents'] as $intent){ echo '<div class="in3pida-note">'.esc_html($intent).'</div>'; } echo '</div>'; }
        if(!empty($vis['suggestions'])){ echo '<h3>Suggerimenti</h3><div class="in3pida-report-list">'; foreach((array)$vis['suggestions'] as $sugg){ echo '<div class="in3pida-note">'.esc_html($sugg).'</div>'; } echo '</div>'; }
        echo '</section>';

        echo '<section class="in3pida-card"><h2>🧩 Blocchi semantici</h2><p class="in3pida-card-desc">Sezioni ordinate con ID descrittivi, utili per rendere i contenuti più chiari, chunkabili e citabili.</p>';
        if(empty($layer['semantic_sections'])) echo '<div class="in3pida-note">Quando compili servizi, target, temi, keyword o FAQ, qui compariranno i blocchi semantici automatici.</div>'; else { echo '<div class="in3pida-report-list">'; foreach($layer['semantic_sections'] as $section){ echo '<div class="in3pida-repeat-box"><h3 id="'.esc_attr($section['id']).'">'.esc_html($section['title']).'</h3><ul>'; foreach((array)$section['items'] as $item){ echo '<li>'.wp_kses_post(is_scalar($item)?$item:'').'</li>'; } echo '</ul></div>'; } echo '</div>'; }
        echo '</section>';
        echo '<section class="in3pida-card"><h2>📊 Dati da coerenza contenuti</h2><p class="in3pida-card-desc">Se hai già eseguito una scansione, il layer usa anche il riepilogo del report.</p>';
        if(empty($layer['consistency'])) echo '<div class="in3pida-note">Nessun report disponibile. Esegui una scansione in Coerenza contenuti se vuoi aggiungere questo segnale.</div>'; else { echo '<div class="in3pida-kpi-grid"><div><strong>Indice coerenza</strong><span>'.esc_html($layer['consistency']['score']).'/100</span></div><div><strong>Canali controllati</strong><span>'.esc_html($layer['consistency']['channels_checked']).'</span></div><div><strong>Critiche</strong><span>'.esc_html($layer['consistency']['critical']).'</span></div><div><strong>Medie</strong><span>'.esc_html($layer['consistency']['medium']).'</span></div><div><strong>Basse</strong><span>'.esc_html($layer['consistency']['low']).'</span></div></div>'; }
        echo '</section>';
        echo '</div></div>';
    }

    // ── AI LAYER PAGE (merged: Chunk Engine + Entity Graph + Citation Engine + LLM Layer) ─────────

    public function ai_layer_page() {
        if (!current_user_can('manage_options')) return;

        $layer    = $this->llm_get_layer_cached();
        $chunks   = $this->chunks_get_cached();
        $blocks   = $this->citation_get_cached();
        $graph    = $this->entity_graph_get_cached();
        $llm_o    = $this->llm_opts();
        $enabled  = $this->retrieval_is_enabled();

        $airs      = $layer['ai_readiness_score'] ?? [];
        $ae        = $layer['answer_extraction'] ?? [];
        $qs        = $layer['quality_safety'] ?? [];
        $vis       = $layer['ai_visibility_monitor'] ?? [];
        $authority = $layer['entity_authority'] ?? [];

        $chunk_scores  = $chunks ? array_column($chunks, 'citation_score') : [];
        $chunk_avg     = $chunk_scores ? round(array_sum($chunk_scores) / count($chunk_scores)) : 0;
        $citation_avg  = $blocks ? round(array_sum(array_column($blocks, 'citability_score')) / count($blocks)) : 0;
        $graph_stats   = $graph['stats'] ?? [];
        $rest_base     = rest_url('in3pida/v1/');
        $schema_url    = esc_url(admin_url('admin.php?page=in3pida-schemaorg'));

        echo '<div class="wrap in3pida-admin in3pida-admin-pro">';
        $this->admin_header('AI Layer — GEO, Chunk Engine, Entity Graph, Citation Engine');
        echo '<div class="in3pida-grid">';

        // ── SCORE DASHBOARD (fisso, sempre visibile) ─────────────────────────
        echo '<section class="in3pida-card">';
        echo '<h2>📊 Punteggi AI</h2>';
        echo '<div class="in3pida-kpi-grid">';
        echo '<div class="in3pida-tip" data-tip="Punteggio complessivo: quanto il sito è pronto per essere letto e citato da assistenti AI."><strong>AI Readiness Score</strong><span>' . intval($airs['score'] ?? 0) . '/100</span></div>';
        echo '<div><strong>Answer Extraction</strong><span>' . intval($ae['score'] ?? 0) . '/100</span></div>';
        echo '<div><strong>Quality Safety</strong><span>' . intval($qs['score'] ?? 0) . '/100</span></div>';
        echo '<div><strong>AI Visibility</strong><span>' . intval($vis['score'] ?? 0) . '/100</span></div>';
        echo '<div><strong>Entity Authority</strong><span>' . esc_html($authority['score'] ?? 0) . '/100</span></div>';
        echo '<div><strong>Chunk Citation avg</strong><span>' . $chunk_avg . '/100</span></div>';
        echo '<div><strong>Citation Engine avg</strong><span>' . $citation_avg . '/100</span></div>';
        echo '</div>';
        echo '</section>';

        // ── TAB NAV + PANELS ─────────────────────────────────────────────────
        echo '<section class="in3pida-card" style="padding:0;overflow:hidden">';

        echo '<div class="in3pida-ai-tabs">';
        echo '<button class="in3pida-ai-tab active" onclick="isiAiTab(this,\'ai-attivazione\')">⚙️ Attivazione</button>';
        echo '<button class="in3pida-ai-tab" onclick="isiAiTab(this,\'ai-chunk\')">📦 Chunk Engine</button>';
        echo '<button class="in3pida-ai-tab" onclick="isiAiTab(this,\'ai-graph\')">🕸️ Entity Graph</button>';
        echo '<button class="in3pida-ai-tab" onclick="isiAiTab(this,\'ai-citation\')">📚 Citation Engine</button>';
        echo '<button class="in3pida-ai-tab" onclick="isiAiTab(this,\'ai-llm\')">🧠 LLM Layer</button>';
        echo '<button class="in3pida-ai-tab" onclick="isiAiTab(this,\'ai-missing\')">🎯 Missing Answers</button>';
        echo '</div>';

        // ── PANEL: ATTIVAZIONE ────────────────────────────────────────────────
        echo '<div id="ai-attivazione" class="in3pida-ai-panel">';
        echo '<p class="in3pida-card-desc">Abilita il LLM ready layer per esporre llms.txt, AI sitemap e knowledge index nel frontend del sito.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('in3pida_llm_ready_settings_group');
        echo '<div class="in3pida-fields">';
        echo '<label class="in3pida-check"><input type="checkbox" name="' . esc_attr(self::LLM_OPTION) . '[enabled]" value="1" ' . checked($llm_o['enabled'], 1, false) . '> Abilita LLM ready layer</label>';
        echo '<div class="in3pida-note"><strong>Stato:</strong> ' . ($llm_o['enabled'] ? 'Abilitato' : 'Disabilitato') . '.</div>';
        echo '</div>';
        echo '<div class="in3pida-savebar-inline">';
        submit_button('Salva', 'primary in3pida-save', 'submit', false);
        echo '</div></form>';

        // Campo chiave API Anthropic (form separato)
        $api_key_val = get_option(self::GEMINI_API_OPTION, '');
        echo '<div style="border-top:1px solid #e4e4ec;margin-top:22px;padding-top:20px">';
        echo '<h3 style="margin:0 0 8px;font-size:13px;color:#171b33;font-weight:900;text-transform:uppercase;letter-spacing:.06em">✨ Mappa Query — Chiave API Google Gemini</h3>';
        echo '<p style="font-size:13px;color:#4b4d68;margin:0 0 6px">Usata dalla funzione <strong>Genera risposta</strong> in Mappa Query per creare automaticamente le risposte FAQ dai dati Schema.org. <strong>Gratuita</strong> — nessuna carta di credito.</p>';
        echo '<p style="font-size:13px;color:#4b4d68;margin:0 0 14px">Ottieni la chiave su <strong>aistudio.google.com</strong> → "Get API key" → copia e incolla qui sotto.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields('in3pida_api_settings_group');
        echo '<div class="in3pida-field"><label>Chiave API Gemini</label>';
        echo '<input type="password" name="' . esc_attr(self::GEMINI_API_OPTION) . '" value="' . esc_attr($api_key_val) . '" style="max-width:420px" placeholder="AIza...">';
        echo '</div>';
        if ($api_key_val) echo '<div class="in3pida-note" style="margin-top:10px;background:#fff;border-color:#e4e4ec"><strong>Chiave configurata.</strong> La funzione "Genera risposta" è attiva in Mappa Query.</div>';
        echo '<div class="in3pida-savebar-inline">';
        submit_button('Salva chiave', 'primary in3pida-save', 'submit', false);
        echo '</div></form>';
        echo '</div>';

        if ($llm_o['enabled'] && $this->has_physical_robots_txt() && !$this->physical_robots_has_ai_sitemap()) {
            echo '<div class="in3pida-note in3pida-robots-notice" style="margin-top:12px"><strong>Attenzione:</strong> robots.txt personalizzato rilevato. Aggiungi: <code>' . esc_html('Sitemap: ' . $this->retrieval_base_url('ai-sitemap.xml')) . '</code></div>';
        }
        if ($llm_o['enabled']) {
            echo '<h3 style="border-top:1px solid #e4e4ec;margin-top:20px;padding-top:16px">Output frontend attivi</h3>';
            echo '<div class="in3pida-report-list">';
            echo '<div class="in3pida-note"><strong>llms.txt:</strong> <a href="' . esc_url($this->retrieval_base_url('llms.txt')) . '" target="_blank">' . esc_html($this->retrieval_base_url('llms.txt')) . '</a></div>';
            echo '<div class="in3pida-note"><strong>AI sitemap:</strong> <a href="' . esc_url($this->retrieval_base_url('ai-sitemap.xml')) . '" target="_blank">' . esc_html($this->retrieval_base_url('ai-sitemap.xml')) . '</a></div>';
            echo '<div class="in3pida-note"><strong>Knowledge index:</strong> <a href="' . esc_url($this->retrieval_base_url('knowledge/')) . '" target="_blank">' . esc_html($this->retrieval_base_url('knowledge/')) . '</a></div>';
            echo '</div>';
        }
        echo '</div>';

        // ── PANEL: CHUNK ENGINE ───────────────────────────────────────────────
        echo '<div id="ai-chunk" class="in3pida-ai-panel" style="display:none">';
        echo '<p class="in3pida-card-desc">Segmenta automaticamente i dati Schema.org e FAQ in blocchi ottimizzati per il retrieval AI. Non richiede configurazione.</p>';
        if ($enabled) echo '<div class="in3pida-note" style="margin-bottom:12px"><strong>REST endpoint:</strong> <a href="' . esc_url($rest_base . 'chunks') . '" target="_blank"><code>' . esc_html($rest_base . 'chunks') . '</code></a></div>';
        else echo '<div class="in3pida-note" style="margin-bottom:12px">Il REST endpoint si attiva abilitando il LLM ready layer.</div>';
        if ($chunks) {
            $types = ['identity' => '🏨', 'contact' => '📞', 'amenities' => '🛎️', 'room' => '🛏️', 'offer' => '🏷️', 'faq' => '❓'];
            echo '<div class="in3pida-report-list">';
            foreach ($chunks as $chunk) {
                $score = intval($chunk['citation_score']);
                $score_color = $score >= 70 ? '#0D5F75' : ($score >= 50 ? '#0D5F75' : '#0D5F75');
                $icon = $types[$chunk['type']] ?? '📄';
                echo '<div class="in3pida-repeat-box">';
                echo '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">';
                echo '<strong>' . $icon . ' ' . esc_html($chunk['title']) . '</strong>';
                echo '<span style="color:' . esc_attr($score_color) . ';font-weight:700">Score: ' . $score . '/100</span>';
                echo '</div>';
                echo '<div style="font-size:12px;color:#666;margin-bottom:4px">Tipo: <code>' . esc_html($chunk['type']) . '</code> &nbsp;|&nbsp; Token: ' . esc_html($chunk['tokens_estimate']) . '</div>';
                $preview = mb_strimwidth($chunk['content'], 0, 180, '...');
                echo '<div style="font-size:13px;color:#444;line-height:1.5">' . esc_html($preview) . '</div>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<div class="in3pida-note in3pida-alert">Compila <strong>Schema.org</strong> e aggiungi <strong>FAQ</strong> per generare i chunk.</div>';
        }
        echo '</div>';

        // ── PANEL: ENTITY GRAPH ───────────────────────────────────────────────
        echo '<div id="ai-graph" class="in3pida-ai-panel" style="display:none">';
        echo '<p class="in3pida-card-desc">Mappa le relazioni tra le entità della struttura. Dati automatici da Schema.org, FAQ e campi audience.</p>';
        if ($enabled) echo '<div class="in3pida-note" style="margin-bottom:12px"><strong>REST endpoint:</strong> <a href="' . esc_url($rest_base . 'graph') . '" target="_blank"><code>' . esc_html($rest_base . 'graph') . '</code></a></div>';
        else echo '<div class="in3pida-note" style="margin-bottom:12px">Il REST endpoint si attiva abilitando il LLM ready layer.</div>';
        echo '<div class="in3pida-note" style="margin-bottom:12px">Per modificare query target, POI e topic cluster vai su <a href="' . $schema_url . '">Schema.org → Audience e posizionamento AI</a>.</div>';
        if (!empty($graph['nodes'])) {
            $type_icons = ['LodgingBusiness' => '🏨', 'City' => '📍', 'AmenityList' => '🛎️', 'Accommodation' => '🛏️', 'FAQItem' => '❓', 'QueryTarget' => '🎯', 'NearbyPOI' => '🗺️', 'TopicCluster' => '🏷️'];
            echo '<div class="in3pida-report-list">';
            $current_type = '';
            foreach ($graph['nodes'] as $node) {
                $t = $node['type'] ?? '';
                if ($t !== $current_type) {
                    if ($current_type) echo '</div></div>';
                    $icon = $type_icons[$t] ?? '📄';
                    echo '<div class="in3pida-repeat-box"><h4 style="margin:0 0 8px">' . $icon . ' ' . esc_html($t) . '</h4><div style="display:flex;flex-wrap:wrap;gap:6px">';
                    $current_type = $t;
                }
                echo '<span style="background:#f0f0f0;padding:3px 8px;font-size:12px">' . esc_html($node['label']) . '</span>';
            }
            if ($current_type) echo '</div></div>';
            echo '</div>';
        } else {
            echo '<div class="in3pida-note in3pida-alert">Compila Schema.org e FAQ per generare il grafo.</div>';
        }
        echo '</div>';

        // ── PANEL: CITATION ENGINE ────────────────────────────────────────────
        echo '<div id="ai-citation" class="in3pida-ai-panel" style="display:none">';
        echo '<p class="in3pida-card-desc">Genera blocchi strutturati question→answer ottimizzati per essere citati dagli AI.</p>';
        if ($enabled) echo '<div class="in3pida-note" style="margin-bottom:12px"><strong>REST endpoint:</strong> <a href="' . esc_url($rest_base . 'citation') . '" target="_blank"><code>' . esc_html($rest_base . 'citation') . '</code></a></div>';
        if ($blocks) {
            $cat_icons = ['identity' => '🏨', 'location' => '📍', 'policy' => '📋', 'services' => '🛎️', 'rooms' => '🛏️', 'pricing' => '💶', 'ratings' => '⭐', 'faq' => '❓'];
            $categories = [];
            foreach ($blocks as $b) $categories[$b['category']] = $b['category_label'];
            foreach ($categories as $cat => $cat_label) {
                $cat_blocks = array_values(array_filter($blocks, function($b) use($cat) { return $b['category'] === $cat; }));
                if (!$cat_blocks) continue;
                $icon = $cat_icons[$cat] ?? '📄';
                echo '<h3 style="border-top:1px solid #e4e4ec;margin-top:16px;padding-top:12px">' . $icon . ' ' . esc_html($cat_label) . '</h3><div class="in3pida-report-list">';
                foreach ($cat_blocks as $block) {
                    $score = intval($block['citability_score']);
                    $score_color = $score >= 70 ? '#0D5F75' : ($score >= 50 ? '#0D5F75' : '#0D5F75');
                    echo '<div class="in3pida-repeat-box">';
                    echo '<div style="margin-bottom:6px">';
                    echo '<strong style="font-size:13px">' . esc_html($block['question']) . '</strong>';
                    echo '</div>';
                    echo '<div style="font-size:13px;color:#444;line-height:1.5;margin-bottom:4px">' . esc_html($block['answer']) . '</div>';
                    echo '<div style="font-size:11px;color:#888">Fonte: ' . esc_html($block['source']) . '</div>';
                    echo '</div>';
                }
                echo '</div>';
            }
        } else {
            echo '<div class="in3pida-note in3pida-alert">Compila <strong>Schema.org</strong> e aggiungi <strong>FAQ</strong> per generare i blocchi citation.</div>';
        }
        echo '</div>';

        // ── PANEL: LLM LAYER ─────────────────────────────────────────────────
        echo '<div id="ai-llm" class="in3pida-ai-panel" style="display:none">';

        if (!empty($airs['warnings'])) {
            echo '<h3>Suggerimenti</h3><div class="in3pida-report-list">';
            foreach ((array)$airs['warnings'] as $warn) echo '<div class="in3pida-note">' . esc_html($warn) . '</div>';
            echo '</div>';
        }
        echo '<h3>Key facts</h3>';
        if (empty($layer['key_facts'])) echo '<div class="in3pida-note in3pida-alert">Compila prima i dati in <strong>Schema.org</strong>.</div>';
        else { echo '<div class="in3pida-kpi-grid">'; foreach ($layer['key_facts'] as $fact) echo '<div><strong>' . esc_html($fact['label']) . '</strong><span>' . esc_html($fact['value']) . '</span></div>'; echo '</div>'; }

        if (!empty($ae['optimized_answers'])) {
            echo '<h3>Risposte dirette</h3><div class="in3pida-report-list">';
            foreach ((array)$ae['optimized_answers'] as $ans) echo '<div class="in3pida-note"><strong>' . esc_html($ans['question']) . '</strong><br>' . esc_html($ans['answer']) . '</div>';
            echo '</div>';
        }

        echo '<h3>Quality Safety</h3>';
        if (!empty($qs['schema_checks'])) {
            echo '<div class="in3pida-report-list">';
            foreach ((array)$qs['schema_checks'] as $check) echo '<div class="in3pida-note"><strong>' . esc_html($check['label']) . ':</strong> ' . esc_html($check['status']) . ' — ' . esc_html($check['message']) . '</div>';
            echo '</div>';
        }

        echo '<h3>AI Visibility</h3>';
        echo '<div class="in3pida-note"><strong>Livello:</strong> ' . esc_html($vis['level'] ?? 'n/d') . ' &nbsp;|&nbsp; <strong>Brand:</strong> ' . esc_html($vis['brand'] ?? '') . '</div>';
        if (!empty($vis['suggestions'])) { echo '<div class="in3pida-report-list">'; foreach ((array)$vis['suggestions'] as $sugg) echo '<div class="in3pida-note">' . esc_html($sugg) . '</div>'; echo '</div>'; }

        echo '<h3>Entity Authority</h3>';
        if (!empty($authority['missing'])) echo '<div class="in3pida-note in3pida-alert"><strong>Da aggiungere:</strong> ' . esc_html(implode(', ', array_slice($authority['missing'], 0, 8))) . '</div>';

        if (!empty($layer['consistency'])) echo '<h3>Coerenza contenuti</h3><div class="in3pida-note">Canali controllati: <strong>' . esc_html($layer['consistency']['channels_checked']) . '</strong> &nbsp;|&nbsp; Critiche: <strong>' . esc_html($layer['consistency']['critical']) . '</strong></div>';

        echo '</div>';

        // ── PANEL: MISSING ANSWER DETECTOR ───────────────────────────────────
        $mad    = $this->compute_missing_answers();
        $fresh  = $this->compute_freshness();
        $pct    = $mad['coverage_pct'];
        $pct_color = $pct >= 80 ? '#0D5F75' : '#0D5F75';
        $pct_bg    = $pct >= 80 ? '#e8f2f5' : '#e8f2f5';

        echo '<div id="ai-missing" class="in3pida-ai-panel" style="display:none">';
        echo '<p class="in3pida-card-desc">Genera automaticamente le domande che gli utenti fanno alle AI sulla tua struttura e controlla se il tuo sito contiene una risposta chiara per ognuna.</p>';

        // Score coverage
        echo '<div style="display:flex;align-items:center;gap:20px;padding:12px 0 20px">';
        echo '<div style="font-size:48px;font-weight:800;color:'.$pct_color.'">'.$pct.'<span style="font-size:22px;color:#888">/100</span></div>';
        echo '<div style="flex:1"><div style="height:8px;background:#f0f0f4;border-radius:4px"><div style="height:8px;width:'.$pct.'%;background:'.$pct_color.';border-radius:4px"></div></div>';
        echo '<div style="font-size:12px;color:#666b84;margin-top:6px">'.$mad['covered'].' query coperte su '.$mad['total'].' monitorate — '.$mad['missing'].' risposte mancanti</div></div>';
        echo '</div>';

        // Freshness
        if (!empty($fresh['alerts'])) {
            echo '<div class="in3pida-note in3pida-alert" style="margin-bottom:16px"><strong>Contenuti da aggiornare:</strong><ul style="margin:6px 0 0 16px;padding:0">';
            foreach ($fresh['alerts'] as $a) echo '<li style="margin-bottom:3px">'.esc_html($a).'</li>';
            echo '</ul></div>';
        } else {
            echo '<div class="in3pida-note" style="background:#fff;border-color:#e4e4ec;margin-bottom:16px"><strong>Contenuti aggiornati.</strong> FAQ e Schema.org risultano recenti.</div>';
        }

        // Freshness details
        echo '<div class="in3pida-kpi-grid" style="margin-bottom:20px">';
        echo '<div><strong>FAQ pubblicate</strong><span>'.esc_html($fresh['faq_count']).'</span></div>';
        $df = $fresh['days_since_faq']; echo '<div><strong>Ultimo agg. FAQ</strong><span>'.($df !== null ? $df.' giorni fa' : 'N/D').'</span></div>';
        $ds = $fresh['days_since_schema']; echo '<div><strong>Ultimo agg. Schema</strong><span>'.($ds !== null ? $ds.' giorni fa' : 'Non rilevato').'</span></div>';
        echo '</div>';

        // Missing queries
        if (!empty($mad['missing_queries'])) {
            echo '<h3 style="color:#0D5F75">✕ Risposte mancanti ('.count($mad['missing_queries']).')</h3>';
            echo '<div class="in3pida-report-list">';
            foreach ($mad['missing_queries'] as $q) {
                echo '<div class="in3pida-repeat-box">';
                echo '<div style="font-weight:700;font-size:13px">'.esc_html($q['query']).'</div>';
                echo '<div style="font-size:12px;color:#666;margin-top:4px">'.esc_html($q['suggestion']).'</div>';
                echo '</div>';
            }
            echo '</div>';
        }

        // Covered queries
        if (!empty($mad['covered_queries'])) {
            echo '<h3 style="color:#0D5F75;margin-top:20px">✓ Query coperte ('.count($mad['covered_queries']).')</h3>';
            echo '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px">';
            foreach ($mad['covered_queries'] as $q) echo '<span style="background:#fafafa;border:1px solid #e4e4ec;padding:4px 10px;font-size:12px;border-radius:4px;color:#171b33">'.esc_html($q['query']).'</span>';
            echo '</div>';
        }

        // Query set
        $qs = $this->generate_query_set();
        echo '<details style="margin-top:20px"><summary style="cursor:pointer;font-weight:700;color:#171b33;font-size:13px">📋 Tutte le query monitorate ('.count($qs).')</summary>';
        echo '<div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:8px">';
        foreach ($qs as $q) echo '<span style="background:#fafafa;border:1px solid #e4e4ec;padding:4px 10px;font-size:12px;border-radius:4px">'.esc_html($q['query']).'</span>';
        echo '</div></details>';

        echo '</div>';

        echo '</section>';

        // ── Mappa Query (riepilogo) ──────────────────────────────────
        $coverage   = $this->compute_query_coverage();
        $qpct       = $coverage['pct'];
        $qpct_color = $qpct >= 70 ? '#0D5F75' : '#0D5F75';
        echo '<section class="in3pida-card">';
        echo '<h2>🗺️ Mappa Query</h2>';
        echo '<p class="in3pida-card-desc">Copertura delle query conversazionali per tipologia di ospite rispetto alle FAQ pubblicate. <a href="' . esc_url(admin_url('edit.php?post_type=' . self::CPT . '&page=in3pida-query-map')) . '" style="color:#0D5F75;font-weight:700">Apri Mappa Query completa →</a></p>';
        echo '<div style="display:flex;align-items:center;gap:20px">';
        echo '<div style="font-size:42px;font-weight:800;color:' . $qpct_color . '">' . $qpct . '<span style="font-size:18px;color:#666b84">/100</span></div>';
        echo '<div style="flex:1"><div style="height:8px;background:#f0f0f4;border-radius:4px"><div style="height:8px;width:' . $qpct . '%;background:' . $qpct_color . ';border-radius:4px"></div></div>';
        echo '<div style="font-size:12px;color:#666b84;margin-top:6px">' . $coverage['covered'] . ' query coperte su ' . $coverage['total'] . ' — ' . $coverage['uncovered'] . ' scoperte</div></div>';
        echo '</div>';
        echo '</section>';

        // ── Visibilità AI (monitor iSI) ──────────────────────────────
        $this->monitor_page_content();

        echo '</div></div>';

        echo '<script>
function isiAiTab(btn,id){document.querySelectorAll(".in3pida-ai-tab").forEach(function(b){b.classList.remove("active")});btn.classList.add("active");document.querySelectorAll(".in3pida-ai-panel").forEach(function(p){p.style.display="none"});document.getElementById(id).style.display="block"}
</script>';
    }
        // ── END AI LAYER PAGE ─────────────────────────────────────────────────────────

    private function llm_render_frontend_layer(){
        $layer = $this->llm_get_layer_cached();
        ob_start();
        echo '<section class="in3pida-llm-layer" data-ai-summary data-llm-ready-layer>';
        echo '<h2>Riassunto rapido</h2>';
        if(!empty($layer['summary_short'])) echo '<p>'.wp_kses_post($layer['summary_short']).'</p>';
        if(!empty($layer['summary_extended'])) echo '<p>'.wp_kses_post($layer['summary_extended']).'</p>';
        if(!empty($layer['key_facts'])){
            echo '<h3>Informazioni principali</h3><ul>';
            foreach($layer['key_facts'] as $fact) echo '<li><strong>'.esc_html($fact['label']).':</strong> '.esc_html($fact['value']).'</li>';
            echo '</ul>';
        }
        $citation = $layer['citation_friendly'] ?? [];
        if(!empty($citation)){
            echo '<section id="contenuti-citation-friendly" data-citation-friendly><h3>Contenuti citation-friendly</h3>';
            if(!empty($citation['source_note']) || !empty($citation['updated_at'])) echo '<p><strong>Fonte:</strong> '.esc_html($citation['source_note'] ?? '').' <strong>Aggiornato al:</strong> '.esc_html($citation['updated_at'] ?? '').'</p>';
            if(!empty($citation['statistics'])){ echo '<h4>Statistiche</h4><ul>'; foreach((array)$citation['statistics'] as $stat) echo '<li><strong>'.esc_html($stat['label']).':</strong> '.esc_html($stat['value']).'</li>'; echo '</ul>'; }
            if(!empty($citation['tables'])){ foreach((array)$citation['tables'] as $table){ echo '<h4 id="'.esc_attr($table['id']).'">'.esc_html($table['title']).'</h4><table><thead><tr>'; foreach((array)$table['headers'] as $head) echo '<th>'.esc_html($head).'</th>'; echo '</tr></thead><tbody>'; foreach((array)$table['rows'] as $row){ echo '<tr>'; foreach((array)$table['headers'] as $head) echo '<td>'.esc_html($row[$head] ?? '').'</td>'; echo '</tr>'; } echo '</tbody></table>'; } }
            if(!empty($citation['definitions'])){ echo '<h4>Definizioni</h4><dl>'; foreach((array)$citation['definitions'] as $def) echo '<dt>'.esc_html($def['term']).'</dt><dd>'.wp_kses_post($def['definition']).'</dd>'; echo '</dl>'; }
            if(!empty($citation['glossary'])){ echo '<h4>Glossario</h4><dl>'; foreach((array)$citation['glossary'] as $gl) echo '<dt>'.esc_html($gl['term']).'</dt><dd>'.wp_kses_post($gl['definition']).'</dd>'; echo '</dl>'; }
            if(!empty($citation['comparisons'])){ echo '<h4>Comparazioni</h4><ul>'; foreach((array)$citation['comparisons'] as $cmp) echo '<li><strong>'.esc_html($cmp['label']).':</strong> '.esc_html($cmp['left']).' / '.esc_html($cmp['right']).'</li>'; echo '</ul>'; }
            echo '</section>';
        }
        $ae = $layer['answer_extraction'] ?? [];
        if(!empty($ae['optimized_answers'])){
            echo '<section id="answer-extraction" data-answer-extraction><h3>Risposte dirette</h3>';
            foreach((array)$ae['optimized_answers'] as $ans){ echo '<h4>'.esc_html($ans['question']).'</h4><p>'.wp_kses_post($ans['answer']).'</p>'; }
            echo '</section>';
        }
        if(!empty($layer['entity_authority'])){
            echo '<section id="entity-authority"><h3>Entity authority</h3><ul>';
            echo '<li><strong>Score:</strong> '.esc_html($layer['entity_authority']['score']).'/100</li>';
            foreach((array)($layer['entity_authority']['profiles'] ?? []) as $profile) echo '<li>'.esc_html($profile).'</li>';
            echo '</ul></section>';
        }
        foreach((array)$layer['semantic_sections'] as $section){
            echo '<section id="'.esc_attr($section['id']).'"><h3>'.esc_html($section['title']).'</h3><ul>';
            foreach((array)$section['items'] as $item) echo '<li>'.wp_kses_post(is_scalar($item)?$item:'').'</li>';
            echo '</ul></section>';
        }
        echo '</section>';
        return ob_get_clean();
    }

    public function llm_auto_output(){
        if (is_admin() || wp_doing_ajax()) return;
        $llm_o = $this->llm_opts();
        if (empty($llm_o['enabled'])) return;
        echo $this->llm_render_frontend_layer();
    }

    public function llm_shortcode($atts=[]){
        $llm_o = $this->llm_opts();
        if (empty($llm_o['enabled'])) return '';
        return $this->llm_render_frontend_layer();
    }

    public function content_consistency_page(){
        if(!current_user_can('manage_options')) return;
        $schema = $this->schema_opts();
        $summary = $this->cc_official_summary($schema);
        $channels = $this->cc_get_channels();
        $report = $this->cc_get_report();
        $last = get_option(self::CC_LAST_SCAN_OPTION, '');
        echo '<div class="wrap in3pida-admin in3pida-admin-pro in3pida-consistency-page">';
        $this->admin_header(); $this->top_actions('consistency');
        echo '<div class="in3pida-grid">';
        if(!empty($_GET['updated'])) echo '<div class="in3pida-note" id="in3pida-cc-save-feedback"><strong>Canali salvati.</strong> Ora puoi avviare la scansione o aggiornare il report.</div>';
        if(!empty($_GET['scan_async_required'])) echo '<div class="in3pida-note"><strong>Scansione pronta.</strong> Clicca “Avvia scansione tutti i canali”: lo stato comparirà sotto al pulsante.</div>';
        echo '<section class="in3pida-card"><h2>🧭 Stato dati ufficiali</h2><p class="in3pida-card-desc">Questa sezione usa come fonte ufficiale i dati già salvati in Schema.org. Non devi ricompilare i dati hotel.</p>';
        if(!$summary['configured']) echo '<div class="in3pida-note in3pida-alert"><strong>Configura prima la tab Schema.org:</strong> questi dati sono usati come fonte ufficiale per il confronto.</div>';
        echo '<div class="in3pida-kpi-grid"><div><strong>Schema.org configurato</strong><span>'.($summary['configured']?'Sì':'No').'</span></div><div><strong>Nome struttura</strong><span>'.esc_html($summary['name'] ?: 'Non compilato').'</span></div><div><strong>URL ufficiale</strong><span>'.esc_html($summary['url'] ?: 'Non compilato').'</span></div><div><strong>Servizi configurati</strong><span>'.esc_html($summary['amenities']).'</span></div><div><strong>FAQ pubblicate</strong><span>'.esc_html($summary['faqs']).'</span></div></div></section>';

        echo '<section class="in3pida-card"><h2>🌐 Canali da controllare</h2><p class="in3pida-card-desc">Aggiungi manualmente le URL dei canali esterni da confrontare con i dati ufficiali Schema.org.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('in3pida_cc_save_channels');
        echo '<input type="hidden" name="action" value="in3pida_cc_save_channels">';
        echo '<div class="in3pida-repeater in3pida-cc-repeater" data-name="channels" data-kind="cc_channel">';
        $types = $this->cc_channel_types();
        if(!$channels) $channels = [['type'=>'Booking','name'=>'','url'=>'','status'=>'','last_scan'=>'']];
        foreach($channels as $i=>$ch){ $this->cc_channel_row($i,$ch,$types); }
        echo '<button type="button" class="in3pida-btn in3pida-add">Aggiungi canale</button></div>';
        echo '<div class="in3pida-savebar in3pida-savebar-inline"><button type="submit" class="button button-primary in3pida-save">Salva canali</button><span>Salva prima i canali, poi avvia la scansione. Dopo il salvataggio comparirà una conferma.</span></div></form></section>';

        $ajax_nonce = wp_create_nonce('in3pida_cc_ajax_scan');
        echo '<section class="in3pida-card"><h2>⚡ Azioni</h2><p class="in3pida-card-desc">La scansione parte solo quando clicchi il pulsante. Il plugin usa chiamate AJAX una alla volta, con timeout, per evitare blocchi della bacheca se un canale esterno risponde lentamente.</p><div class="in3pida-top-actions in3pida-top-actions-inner">';
        echo '<button type="button" class="button button-primary in3pida-save" id="in3pida-cc-ajax-scan" data-nonce="'.esc_attr($ajax_nonce).'" data-total="'.esc_attr(count($channels)).'">Avvia scansione tutti i canali</button>';
        echo '<a href="'.esc_url(admin_url('edit.php?post_type='.self::CPT.'&page=in3pida-coerenza-contenuti')).'" class="in3pida-btn in3pida-btn-light" style="margin-left:10px">Aggiorna report</a>';
        echo '<button type="button" class="in3pida-btn in3pida-btn-light" id="in3pida-cc-print-pdf" style="margin-left:10px">Stampa / Esporta PDF</button>';
        echo '</div><div id="in3pida-cc-progress" class="in3pida-note in3pida-scan-status" style="display:none;margin-top:14px"><strong>Stato scansione:</strong> <span class="in3pida-cc-progress-text">0%</span><div class="in3pida-progress-track"><div class="in3pida-cc-progress-bar"></div></div><p class="in3pida-card-desc in3pida-cc-progress-message" style="margin-top:8px"></p><div class="in3pida-cc-current"></div><div class="in3pida-cc-channel-statuses">'; foreach($channels as $ci=>$ch){ $label = trim(($ch['name'] ?? '') ?: ($ch['type'] ?? 'Canale')); echo '<div class="in3pida-cc-status-row" data-index="'.esc_attr($ci).'"><strong>'.esc_html($label ?: 'Canale').'</strong><span>In attesa</span></div>'; } echo '</div><div class="in3pida-cc-live-log" aria-live="polite"></div></div>';
        echo '<p class="in3pida-help in3pida-help-local"><strong>Nota:</strong> i canali di tipo Booking, Tripadvisor, Google Business Profile, Expedia e Airbnb vengono marcati automaticamente come "Verifica manuale" nel report e non generano scansione HTTP. Il punteggio globale viene calcolato solo sui canali scansionati.</p></section>';

        echo '<section class="in3pida-card" id="in3pida-cc-report-print"><div class="in3pida-print-cover"><div class="in3pida-print-brand">Eletta</div><h1>Report Coerenza Contenuti</h1><p><strong>Sito:</strong> '.esc_html(get_bloginfo('name')).' — '.esc_html(home_url('/')).'</p><p><strong>Data generazione:</strong> '.esc_html(current_time('d/m/Y H:i')).'</p></div><h2>📊 Report coerenza contenuti</h2>';
        $this->cc_render_report($report,$last);
        echo '<div class="in3pida-print-footer">Report generato da Eletta — Posiziona il tuo sito nelle ricerche AI. Usare il report come supporto operativo: alcuni portali esterni possono bloccare o limitare la scansione automatica.</div>';
        echo '</section>';
        $this->cc_render_debug_log();
        echo '<script>(function(){var b=document.getElementById("in3pida-cc-print-pdf");if(!b)return;b.addEventListener("click",function(e){e.preventDefault();document.body.classList.add("in3pida-print-cc-report");setTimeout(function(){window.print();},120);});window.addEventListener("afterprint",function(){document.body.classList.remove("in3pida-print-cc-report");});})();</script>';
        echo '</div></div>';
    }

    private function cc_channel_row($i,$ch,$types){
        echo '<div class="in3pida-repeat-box in3pida-cc-row">';
        echo '<div class="in3pida-repeat-grid">';
        $manual_types_json = wp_json_encode($this->cc_manual_only_types());
        $is_manual_now = in_array($ch['type']??'', $this->cc_manual_only_types(), true);
        echo '<select name=”channels['.esc_attr($i).'][type]” class=”in3pida-ch-type-select” data-manual=\''.esc_attr($manual_types_json).'\'>'; foreach($types as $t) echo '<option value=”'.esc_attr($t).'” '.selected($ch['type']??'', $t, false).'>'.esc_html($t).'</option>'; echo '</select>';
        echo '<input type=”text” name=”channels['.esc_attr($i).'][name]” placeholder=”Nome scheda / etichetta interna” value=”'.esc_attr($ch['name']??'').'”>';
        echo '<input type=”url” name=”channels['.esc_attr($i).'][url]” placeholder=”URL canale” value=”'.esc_attr($ch['url']??'').'”>';
        echo '</div>';
        echo '<div class=”in3pida-cc-manual-hint” style=”'.($is_manual_now?'':'display:none').'”><span class=”in3pida-sev-badge in3pida-cc-manual-badge”>Verifica manuale</span> Questo portale blocca le scansioni automatiche. La scansione non viene eseguita: apri la scheda manualmente e verifica i dati.</div>';
        echo '<p class=”in3pida-card-desc in3pida-field-help”><strong>Nome scheda / etichetta interna:</strong> è un nome libero per riconoscere meglio il canale nel report.</p><div class=”in3pida-cc-meta”>Stato ultimo controllo: <strong>'.esc_html($ch['status']??'Non scansionato').'</strong> &nbsp; Data ultima scansione: <strong>'.esc_html($ch['last_scan']??'-').'</strong></div>';
        echo '<div class=”in3pida-cc-remove-wrap”><button type=”button” class=”in3pida-remove”>Rimuovi canale</button></div>';
        echo '</div>';
    }

    public function cc_save_channels(){
        if(!current_user_can('manage_options')) wp_die('Permessi insufficienti.');
        check_admin_referer('in3pida_cc_save_channels');
        $channels = $this->cc_sanitize_channels($_POST['channels'] ?? []);
        update_option(self::CC_CHANNELS_OPTION, $channels);
        wp_safe_redirect(admin_url('edit.php?post_type='.self::CPT.'&page=in3pida-coerenza-contenuti&updated=1')); exit;
    }
    private function cc_sanitize_channels($rows){
        $out=[]; $types=$this->cc_channel_types();
        foreach((array)$rows as $row){ if(!is_array($row)) continue; $url=esc_url_raw($row['url']??''); $name=sanitize_text_field($row['name']??''); if(!$url && !$name) continue;
            $type=sanitize_text_field($row['type']??'Altro'); if(!in_array($type,$types,true)) $type='Altro';
            $out[]=['type'=>$type,'name'=>$name,'url'=>$url,'status'=>sanitize_text_field($row['status']??'Salvato'),'last_scan'=>sanitize_text_field($row['last_scan']??'')];
        }
        return $out;
    }

    public function cc_scan_action(){
        if(!current_user_can('manage_options')) wp_die('Permessi insufficienti.');
        check_admin_referer('in3pida_cc_scan');
        // Safety fallback: non esegue piu scansioni sincrone in una singola richiesta POST.
        // La scansione completa avviene solo via AJAX, un canale per richiesta, per evitare timeout/504.
        update_option(self::CC_REPORT_OPTION, []);
        update_option(self::CC_LAST_SCAN_OPTION, '');
        delete_transient(self::LLM_CACHE_TRANSIENT);
        wp_safe_redirect(admin_url('edit.php?post_type='.self::CPT.'&page=in3pida-coerenza-contenuti&scan_async_required=1'));
        exit;
    }

    public function cc_ajax_scan_channel(){
        if(!current_user_can('manage_options')) wp_send_json_error(['message'=>'Permessi insufficienti.'], 403);
        check_ajax_referer('in3pida_cc_ajax_scan','nonce');
        $index = isset($_POST['index']) ? absint($_POST['index']) : 0;
        $reset = !empty($_POST['reset']);
        $channels = $this->cc_get_channels();
        $total = count($channels);
        if(!$total) wp_send_json_error(['message'=>'Nessun canale da scansionare.'], 400);
        if(!isset($channels[$index])) wp_send_json_error(['message'=>'Canale non trovato.'], 404);

        $schema = $this->schema_opts();
        $scan = $this->cc_scan_channel($channels[$index], $schema);
        $channels[$index]['status'] = $scan['status'];
        $channels[$index]['last_scan'] = current_time('mysql');

        $previous = (!$reset) ? $this->cc_get_report() : [];
        $results = [];
        if(!empty($previous['results']) && is_array($previous['results'])) $results = $previous['results'];
        $results[$index] = $scan;
        ksort($results);
        $report = $this->cc_build_report(array_values($results));

        update_option(self::CC_CHANNELS_OPTION, $channels);
        update_option(self::CC_REPORT_OPTION, $report);
        update_option(self::CC_LAST_SCAN_OPTION, current_time('mysql'));
        delete_transient(self::LLM_CACHE_TRANSIENT);

        $label = ($channels[$index]['name'] ?? '') ?: ($channels[$index]['type'] ?? 'Canale');
        wp_send_json_success([
            'index' => $index,
            'total' => $total,
            'done' => $index + 1,
            'progress' => $total ? round((($index + 1) / $total) * 100) : 100,
            'status' => $scan['status'],
            'score' => $scan['score'],
            'message' => sprintf('%s: %s (%s/100)', $label, $scan['status'], $scan['score']),
        ]);
    }

    private function cc_scan_channel($channel,$schema){
        $url=$channel['url']??''; $base=['channel'=>$channel,'score'=>0,'issues'=>[],'suggestions'=>[],'status'=>'Errore'];
        if(in_array($channel['type']??'', $this->cc_manual_only_types(), true)){ $base['status']='Verifica manuale'; $base['manual']=true; $base['score']=0; return $base; }
        if(!$url || !wp_http_validate_url($url)){ $base['issues'][]=$this->cc_issue('critical','URL non valido',$schema['url']??'', $url, 'Inserisci una URL valida per questo canale.'); $this->cc_log_error($channel, 'URL non valido', ['url'=>$url]); return $base; }
        $response=wp_remote_get($url,['timeout'=>12,'redirection'=>3,'user-agent'=>'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 in3pida/1.3.1']);
        if(is_wp_error($response)){ $msg=$response->get_error_message(); $base['issues'][]=$this->cc_issue('medium','Canale non accessibile','Pagina accessibile',$msg,'Verifica la URL o controlla manualmente questo canale.'); $this->cc_log_error($channel, 'Canale non accessibile: '.$msg, ['url'=>$url]); return $base; }
        $code=wp_remote_retrieve_response_code($response); $body=(string)wp_remote_retrieve_body($response);
        if($code<200 || $code>=300 || !$body){ $base['issues'][]=$this->cc_issue('medium','Errore HTTP durante la scansione','HTTP 200','HTTP '.$code,'Verifica se il canale blocca la scansione o richiede accesso manuale.'); $this->cc_log_error($channel, 'Errore HTTP durante la scansione: HTTP '.$code, ['url'=>$url,'code'=>$code]); return $base; }
        $extracted=$this->cc_extract_content($body,$url);
        $issues=$this->cc_compare($schema,$extracted,$channel);
        $base['status']='Scansionato'; $base['extracted']=$extracted; $base['issues']=$issues; $base['score']=$this->cc_score($issues); $base['suggestions']=array_values(array_unique(array_filter(array_map(function($i){return $i['suggestion']??'';},$issues))));
        return $base;
    }

    private function cc_log_error($channel, $message, $context = []){
        $log = get_option(self::DEBUG_LOG_OPTION, []);
        if(!is_array($log)) $log = [];
        $log[] = [
            'time' => current_time('mysql'),
            'channel' => sanitize_text_field(($channel['name'] ?? '') ?: ($channel['type'] ?? 'Canale')),
            'url' => esc_url_raw($channel['url'] ?? ($context['url'] ?? '')),
            'message' => sanitize_text_field($message),
            'context' => array_map('sanitize_text_field', array_map('strval', (array)$context)),
        ];
        $log = array_slice($log, -100);
        update_option(self::DEBUG_LOG_OPTION, $log, false);
    }

    private function cc_get_debug_log(){
        $log = get_option(self::DEBUG_LOG_OPTION, []);
        return is_array($log) ? array_reverse($log) : [];
    }

    public function cc_clear_debug_log_action(){
        if(!current_user_can('manage_options')) wp_die('Accesso negato');
        check_admin_referer('in3pida_cc_clear_log');
        update_option(self::DEBUG_LOG_OPTION, [], false);
        wp_safe_redirect(admin_url('edit.php?post_type='.self::CPT.'&page=in3pida-coerenza-contenuti&log_cleared=1'));
        exit;
    }

    private function cc_render_debug_log(){
        $log = array_slice($this->cc_get_debug_log(), 0, 10);
        echo '<section class="in3pida-card"><h2>🛠️ Log errori scansione</h2><p class="in3pida-card-desc">Ultimi errori tecnici rilevati durante la scansione dei canali esterni. Il log è limitato agli ultimi 100 eventi per non appesantire il database.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin:0 0 12px 0;">';
        wp_nonce_field('in3pida_cc_clear_log');
        echo '<input type="hidden" name="action" value="in3pida_cc_clear_log"><button type="submit" class="in3pida-btn">Svuota log</button></form>';
        if(!$log){ echo '<div class="in3pida-note">Nessun errore tecnico registrato.</div></section>'; return; }
        echo '<div class="in3pida-report-list">';
        foreach($log as $row){
            echo '<div class="in3pida-note"><strong>'.esc_html($row['time'] ?? '').' - '.esc_html($row['channel'] ?? 'Canale').'</strong><br>'.esc_html($row['message'] ?? '').'<br><small>'.esc_html($row['url'] ?? '').'</small></div>';
        }
        echo '</div></section>';
    }

    private function cc_extract_content($html,$url){
        $limited=substr($html,0,350000);
        $title=''; if(preg_match('/<title[^>]*>(.*?)<\/title>/is',$limited,$m)) $title=wp_strip_all_tags(html_entity_decode($m[1]));
        $meta=$this->cc_meta($limited,'description'); $ogt=$this->cc_meta($limited,'og:title','property'); $ogd=$this->cc_meta($limited,'og:description','property');
        preg_match_all('/<script[^>]+type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is',$limited,$jm); $jsonld=[]; foreach($jm[1]??[] as $j){ $jsonld[]=trim(wp_strip_all_tags($j)); }
        $text=preg_replace('/<script\b[^>]*>.*?<\/script>/is',' ',$limited); $text=preg_replace('/<style\b[^>]*>.*?<\/style>/is',' ',$text); $text=wp_strip_all_tags($text); $text=preg_replace('/\s+/u',' ',html_entity_decode($text)); $text=substr($text,0,25000);
        preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i',$text,$emails);
        preg_match_all('/(?:\+\d{1,3}[\s\-.]?)?(?:\(?\d{2,4}\)?[\s\-.]?){2,5}\d{2,4}/',$text,$phones_raw);
        $phones_filtered = array_values(array_filter(array_unique($phones_raw[0]??[]), function($p){ $d=preg_replace('/\D+/','',$p); return strlen($d)>=7 && strlen($d)<=15; }));
        preg_match_all('/https?:\/\/[^\s"\'<>]+/i',$limited,$links);
        return ['url'=>$url,'title'=>$title,'meta_description'=>$meta,'og_title'=>$ogt,'og_description'=>$ogd,'text'=>$text,'jsonld'=>$jsonld,'emails'=>array_values(array_unique($emails[0]??[])),'phones'=>$phones_filtered,'links'=>array_slice(array_values(array_unique($links[0]??[])),0,100),'services'=>$this->cc_detect_services($text)];
    }
    private function cc_meta($html,$name,$attr='name'){
        $pattern='/<meta[^>]+'.$attr.'=["\']'.preg_quote($name,'/').'["\'][^>]+content=["\']([^"\']*)["\'][^>]*>/i';
        if(preg_match($pattern,$html,$m)) return html_entity_decode($m[1]);
        $pattern='/<meta[^>]+content=["\']([^"\']*)["\'][^>]+'.$attr.'=["\']'.preg_quote($name,'/').'["\'][^>]*>/i';
        if(preg_match($pattern,$html,$m)) return html_entity_decode($m[1]);
        return '';
    }
    private function cc_norm($v){ $v=is_array($v)?implode(' ',$v):(string)$v; $v=remove_accents(wp_strip_all_tags($v)); $v=strtolower($v); $v=preg_replace('/[^a-z0-9@\.\+]+/',' ',$v); return trim(preg_replace('/\s+/',' ',$v)); }
    private function cc_norm_phone($v){ return preg_replace('/\D+/','',(string)$v); }
    private function cc_norm_url($v){ $v=strtolower(trim((string)$v)); $v=preg_replace('#^https?://#','',$v); return rtrim($v,'/'); }
    private function cc_contains($hay,$needle){ $needle=$this->cc_norm($needle); if(!$needle) return true; return strpos($this->cc_norm($hay),$needle)!==false; }
    private function cc_detect_services($text){
        $map=['Wi-Fi gratuito'=>['wifi','wi fi','internet gratuito','free wifi'],'Parcheggio'=>['parking','parcheggio','garage'],'Piscina'=>['pool','swimming pool','piscina'],'Colazione'=>['breakfast','colazione','prima colazione'],'Ristorante'=>['restaurant','ristorante'],'Bar'=>['bar'],'Aria condizionata'=>['aria condizionata','air conditioning','climatizzazione'],'Animali ammessi'=>['pet friendly','animali ammessi','pets allowed'],'Accessibilità per ospiti con disabilità'=>['accessibile','disabili','wheelchair']];
        $n=$this->cc_norm($text); $found=[]; foreach($map as $canonical=>$terms){ foreach($terms as $t){ if(strpos($n,$this->cc_norm($t))!==false){$found[]=$canonical; break;} } } return array_values(array_unique($found));
    }
    private function cc_issue($severity,$message,$official,$found,$suggestion){ return ['severity'=>$severity,'message'=>$message,'official'=>(string)$official,'found'=>(string)$found,'suggestion'=>$suggestion]; }
    private function cc_compare($s,$e,$channel){
        $issues=[]; $full=implode(' ',[$e['title']??'',$e['meta_description']??'',$e['og_title']??'',$e['og_description']??'',$e['text']??'']);
        $is_official_site=in_array($channel['type']??'', $this->cc_official_site_types(), true);
        $portal_types=['Hotels.com','Venere.com','Agoda','Facebook','Instagram','LinkedIn','Bing Places','Consorzio / Associazione','Portale regionale turismo','Blog / Stampa','Sito partner','Altro'];
        $is_portal=!$is_official_site && in_array($channel['type']??'',$portal_types,true);
        if(!empty($s['name']) && !$this->cc_contains($full,$s['name'])) $issues[]=$this->cc_issue('critical','Nome struttura non coerente o non rilevato',$s['name'],$e['title']??'','Aggiorna il nome struttura su questo canale usando il nome ufficiale.');
        if(!empty($s['alternate_name']) && !$this->cc_contains($full,$s['alternate_name']) && !$this->cc_contains($full,$s['name'])) $issues[]=$this->cc_issue('low','Nome alternativo non rilevato',$s['alternate_name'],'Non trovato','Valuta se aggiungere anche il nome alternativo dove utile.');
        if(!$is_portal && !empty($s['url']) && !in_array($this->cc_norm_url($s['url']), array_map([$this,'cc_norm_url'], (array)($e['links']??[])), true) && !$this->cc_contains($full,$s['url'])) $issues[]=$this->cc_issue('critical','URL ufficiale non rilevato',$s['url'],'Non trovato','Aggiungi il link al sito ufficiale o verifica che sia corretto.');
        foreach(['street'=>'indirizzo','city'=>'città','postal_code'=>'CAP','region'=>'regione','country'=>'paese'] as $k=>$label){ if(!empty($s[$k]) && !$this->cc_contains($full,$s[$k])) $issues[]=$this->cc_issue($k==='street'?'critical':'medium',ucfirst($label).' non coerente o non rilevato',$s[$k],'Non trovato','Uniforma '.$label.' su questo canale.'); }
        if(!empty($s['telephone'])){ $official=$this->cc_norm_phone($s['telephone']); $phones=array_map([$this,'cc_norm_phone'],(array)($e['phones']??[])); $ok=false; foreach($phones as $p){ if($official && (strpos($p,$official)!==false || strpos($official,$p)!==false)){ $ok=true; break; } } if(!$ok) $issues[]=$this->cc_issue('critical','Telefono diverso o non rilevato',$s['telephone'],implode(', ',array_slice($e['phones']??[],0,3)) ?: 'Non trovato','Uniforma il numero di telefono.'); }
        if(!$is_portal && !empty($s['email']) && !in_array(strtolower($s['email']),array_map('strtolower',(array)($e['emails']??[])),true)) $issues[]=$this->cc_issue('medium','Email non rilevata',$s['email'],implode(', ',array_slice($e['emails']??[],0,3)) ?: 'Non trovata','Aggiungi o correggi l\'email ufficiale su questo canale.');
        $miss_svc=[];
        foreach((array)($s['amenities']??[]) as $a){ if($a && !in_array($a,(array)($e['services']??[]),true) && !$this->cc_contains($full,$a)) $miss_svc[]=$a; }
        if($miss_svc){ $n=count($miss_svc); $lbl=$n===1?$miss_svc[0]:$n.' servizi: '.implode(', ',array_slice($miss_svc,0,5)).($n>5?' (+'.($n-5).')':''); $issues[]=$this->cc_issue('medium','Servizi non menzionati sul canale',$lbl,'Non menzionati','Aggiungi '.($n===1?'il servizio mancante':'i servizi mancanti').' nella scheda del canale.'); }
        foreach(['checkin_time'=>'check-in','checkout_time'=>'check-out','pets_allowed'=>'policy animali','price_range'=>'fascia prezzo'] as $k=>$label){ if(!empty($s[$k]) && !$this->cc_contains($full,$s[$k])) $issues[]=$this->cc_issue('medium',ucfirst($label).' non rilevato',$s[$k],'Non trovato','Verifica e allinea '.$label.' con i dati ufficiali.'); }
        $keywords=array_merge($this->csv_items($s['keywords']??''),(array)($s['targets']??[]),(array)($s['knows_about']??[]));
        $miss_kw=[];
        foreach(array_slice($keywords,0,12) as $kw){ if($kw && !$this->cc_contains($full,$kw)) $miss_kw[]=$kw; }
        if($miss_kw){ $n=count($miss_kw); $lbl=$n===1?$miss_kw[0]:$n.' concetti: '.implode(', ',array_slice($miss_kw,0,4)).($n>4?' (+'.($n-4).')':''); $issues[]=$this->cc_issue('low','Concetti/keyword non presenti',$lbl,'Non trovati','Allinea la descrizione del canale al posizionamento ufficiale.'); }
        if($this->cc_contains($full,'adults only') && in_array('Famiglie',(array)($s['targets']??[]),true)) $issues[]=$this->cc_issue('medium','Possibile contraddizione di posizionamento','Target famiglie','Canale cita adults only','Verifica se il canale comunica un target incompatibile.');
        $faq_posts=get_posts(['post_type'=>self::CPT,'post_status'=>'publish','numberposts'=>5]);
        $miss_faq=[];
        foreach($faq_posts as $fp){ $q=get_the_title($fp); if($q && !$this->cc_contains($full,$q)) $miss_faq[]=$q; }
        if($miss_faq){ $n=count($miss_faq); $lbl=$n===1?$miss_faq[0]:$n.' FAQ: '.implode(' / ',array_slice($miss_faq,0,2)).($n>2?' (+'.($n-2).')':''); $issues[]=$this->cc_issue('low','FAQ non rilevate sul canale',$lbl,'Non trovate','Inserisci FAQ importanti su check-in, parcheggio, animali o servizi.'); }
        $miss_same=[];
        foreach((array)($s['sameas']??[]) as $row){ $u=is_array($row)?($row['url']??''):$row; if($u && !$this->cc_contains(implode(' ',(array)($e['links']??[])),$u)) $miss_same[]=$u; }
        if($miss_same){ $n=count($miss_same); $lbl=$n===1?$miss_same[0]:$n.' profili mancanti'; $issues[]=$this->cc_issue('low','Profili social/sameAs non rilevati',$lbl,'Non trovati','Verifica la coerenza dei profili esterni collegati.'); }
        return $issues;
    }
    private function cc_score($issues){ $score=100; foreach($issues as $i){ $sev=$i['severity']??'low'; $score-=($sev==='critical'?12:($sev==='medium'?6:2)); } return max(0,min(100,$score)); }
    private function cc_build_report($results){
        $scanned=array_values(array_filter($results,function($r){return empty($r['manual']);}));
        $tot=count($scanned); $avg=$tot?round(array_sum(array_map(function($r){return intval($r['score']??0);},$scanned))/$tot):0;
        $counts=['critical'=>0,'medium'=>0,'low'=>0]; foreach($scanned as $r){ foreach((array)($r['issues']??[]) as $i){ $sev=$i['severity']??'low'; if(isset($counts[$sev])) $counts[$sev]++; }}
        return ['score'=>$avg,'channels_checked'=>$tot,'counts'=>$counts,'results'=>$results,'created_at'=>current_time('mysql')];
    }
    private function cc_clean_url_display($url){
        $p = parse_url((string)$url);
        if(!$p || empty($p['host'])) return (string)$url;
        return ($p['scheme']??'https').'://'.($p['host']??'').rtrim($p['path']??'','/');
    }

    private function cc_sev_badge($sev){
        $map = ['critical'=>['Critico','in3pida-sev-critical'],'medium'=>['Medio','in3pida-sev-medium'],'low'=>['Basso','in3pida-sev-low']];
        [$label,$cls] = $map[$sev] ?? ['Basso','in3pida-sev-low'];
        return '<span class=”in3pida-sev-badge '.esc_attr($cls).'”>'.esc_html($label).'</span>';
    }

    private function cc_render_report($report,$last){
        if(empty($report)){ echo '<p class=”in3pida-card-desc”>Nessun report disponibile. Salva i canali e clicca su “Avvia scansione tutti i canali”.</p>'; return; }
        $counts = $report['counts'] ?? ['critical'=>0,'medium'=>0,'low'=>0];
        $score  = $report['score'] ?? 0;
        $score_color = $score >= 80 ? '#0D5F75' : '#0D5F75';
        echo '<div class=”in3pida-cc-global-bar”>';
        echo '<div class=”in3pida-cc-global-score” style=”border-left:4px solid '.esc_attr($score_color).'”><strong>Indice coerenza</strong><span style=”color:'.esc_attr($score_color).';font-size:26px;font-weight:900”>'.esc_html($score).'/100</span></div>';
        echo '<div class=”in3pida-cc-global-counts”>';
        if($counts['critical']) echo '<span class=”in3pida-sev-badge in3pida-sev-critical”>'.esc_html($counts['critical']).' Critico'.($counts['critical']>1?'i':'').'</span>';
        if($counts['medium'])   echo '<span class=”in3pida-sev-badge in3pida-sev-medium”>'.esc_html($counts['medium']).' Medio</span>';
        if($counts['low'])      echo '<span class=”in3pida-sev-badge in3pida-sev-low”>'.esc_html($counts['low']).' Basso'.($counts['low']>1?'i':'').'</span>';
        echo '<span class=”in3pida-cc-global-meta”>Scansione: '.esc_html($last ?: ($report['created_at']??'-')).' &mdash; '.esc_html($report['channels_checked']??0).' canal'.($report['channels_checked']==1?'e':'i').'</span>';
        echo '</div></div>';
        echo '<div class=”in3pida-report-list”>';
        $sev_order = ['critical'=>0,'medium'=>1,'low'=>2];
        foreach((array)($report['results']??[]) as $r){
            $ch = $r['channel'] ?? [];
            $issues = (array)($r['issues'] ?? []);
            $url_raw = $ch['url'] ?? '';
            $url_display = $this->cc_clean_url_display($url_raw);
            $name  = ($ch['name']??'') ?: ($ch['type']??'Canale');
            $is_manual = !empty($r['manual']);
            echo '<div class=”in3pida-repeat-box in3pida-print-channel'.($is_manual?' in3pida-cc-manual-ch':'').'”>';
            echo '<div class=”in3pida-cc-ch-header”>';
            echo '<div class=”in3pida-cc-ch-title”><strong>'.esc_html($name).'</strong>';
            if($url_raw) echo ' &mdash; <a href=”'.esc_url($url_raw).'” target=”_blank” rel=”noopener” class=”in3pida-cc-url-link”>'.esc_html($url_display).'</a>';
            echo '</div>';
            if($is_manual){
                echo '<span class=”in3pida-sev-badge in3pida-cc-manual-badge”>Verifica manuale</span>';
            } else {
                $score_ch = intval($r['score'] ?? 0);
                $sc = $score_ch >= 80 ? '#0D5F75' : '#0D5F75';
                echo '<span class=”in3pida-score” style=”background:'.esc_attr($sc).'”>'.esc_html($score_ch).'/100</span>';
            }
            echo '</div>';
            if($is_manual){
                echo '<p class=”in3pida-cc-manual-note”>Questo portale blocca le scansioni automatiche. Verifica manualmente che i dati (nome, indirizzo, telefono, orari) siano coerenti con quelli ufficiali.</p>';
                if($url_raw) echo '<a href=”'.esc_url($url_raw).'” target=”_blank” rel=”noopener” class=”button”>Apri scheda &rarr;</a>';
            } elseif(!empty($issues)){
                $c_crit=$c_med=$c_low=0;
                foreach($issues as $i){ $s=$i['severity']??'low'; if($s==='critical')$c_crit++; elseif($s==='medium')$c_med++; else $c_low++; }
                usort($issues,function($a,$b) use($sev_order){ return ($sev_order[$a['severity']??'low']??2)-($sev_order[$b['severity']??'low']??2); });
                echo '<div class=”in3pida-cc-summary-bar”>';
                if($c_crit) echo '<span class=”in3pida-sev-badge in3pida-sev-critical”>'.esc_html($c_crit).' Critico'.($c_crit>1?'i':'').'</span>';
                if($c_med)  echo '<span class=”in3pida-sev-badge in3pida-sev-medium”>'.esc_html($c_med).' Medio</span>';
                if($c_low)  echo '<span class=”in3pida-sev-badge in3pida-sev-low”>'.esc_html($c_low).' Basso'.($c_low>1?'i':'').'</span>';
                echo '</div>';
                echo '<table class=”widefat in3pida-print-table in3pida-cc-table”><thead><tr><th style=”width:90px”>Livello</th><th>Problema</th><th>Dato ufficiale</th><th>Rilevato</th><th>Azione consigliata</th></tr></thead><tbody>';
                foreach($issues as $i){
                    echo '<tr><td>'.$this->cc_sev_badge($i['severity']??'low').'</td>';
                    echo '<td>'.esc_html($i['message']??'').'</td>';
                    echo '<td class=”in3pida-cc-td-official”>'.esc_html($i['official']??'').'</td>';
                    echo '<td class=”in3pida-cc-td-found”>'.esc_html($i['found']??'').'</td>';
                    echo '<td>'.esc_html($i['suggestion']??'').'</td></tr>';
                }
                echo '</tbody></table>';
            } else {
                echo '<p class=”in3pida-cc-ok”><strong>Nessuna incongruenza rilevata.</strong></p>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

    public function faq_list_header() { $screen = function_exists('get_current_screen') ? get_current_screen() : null; if (!$screen || $screen->id !== 'edit-' . self::CPT) return; $faq_count = wp_count_posts(self::CPT); $published = isset($faq_count->publish) ? intval($faq_count->publish) : 0; echo '<div class="in3pida-list-shell">'; $this->admin_header(); $this->top_actions('faq'); echo '<div class="in3pida-card in3pida-list-card"><h2><span class="in3pida-ifaq-mini">iSI</span> Lista FAQ</h2><p class="in3pida-card-desc">FAQ pubblicate: <strong>' . esc_html($published) . '</strong>. Per l\'ordine manuale trascina le righe con il mouse: il nuovo ordine viene salvato con una sola chiamata AJAX al rilascio.</p></div></div>'; }

    public function ajax_sort_faqs() {
        if (!current_user_can('edit_posts')) wp_send_json_error(['message' => 'Permessi insufficienti.'], 403);
        check_ajax_referer('in3pida_faq_sort', 'nonce');
        $ids = isset($_POST['ids']) ? (array) wp_unslash($_POST['ids']) : [];
        $ids = array_values(array_filter(array_map('absint', $ids)));
        if (empty($ids)) wp_send_json_error(['message' => 'Ordine non valido.'], 400);
        foreach ($ids as $pos => $id) {
            if (get_post_type($id) !== self::CPT || !current_user_can('edit_post', $id)) continue;
            wp_update_post(['ID' => $id, 'menu_order' => ($pos + 1) * 10]);
        }
        delete_transient(self::LLM_CACHE_TRANSIENT);
        wp_send_json_success(['message' => 'Ordine FAQ aggiornato.']);
    }

    private function page_has_faq_shortcode(){ global $post; if(!is_a($post,'WP_Post')) return false; if(has_shortcode($post->post_content,'in3pida_faq')||has_shortcode($post->post_content,'site_faq')||has_shortcode($post->post_content,'in3pida_llm_layer')) return true; $faq_page_id=absint(get_option(self::PAGE_OPTION)); if($faq_page_id&&is_page($faq_page_id)) return true; if(is_page('faq')) return true; $uri=$_SERVER['REQUEST_URI']??'/'; return stripos($uri,'/faq')!==false; }
    public function enqueue_assets() { $llm_e=!empty($this->llm_opts()['enabled']); $has_sc=$this->page_has_faq_shortcode(); if(!$llm_e && !$has_sc) return; wp_register_style('in3pida-faq', false, [], '1.6.5'); wp_enqueue_style('in3pida-faq'); wp_add_inline_style('in3pida-faq', $has_sc ? $this->css() : '.in3pida-llm-layer{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}'); if($has_sc){ wp_register_script('in3pida-faq', false, [], '1.6.5', true); wp_enqueue_script('in3pida-faq'); wp_add_inline_script('in3pida-faq', "document.addEventListener('click',function(e){var b=e.target.closest('.in3pida-faq-q');if(!b)return;var item=b.closest('.in3pida-faq-item');var open=item.classList.contains('is-open');item.parentNode.querySelectorAll('.in3pida-faq-item').forEach(function(i){i.classList.remove('is-open');i.querySelector('.in3pida-faq-q').setAttribute('aria-expanded','false');});if(!open){item.classList.add('is-open');b.setAttribute('aria-expanded','true');}});"); } }
    public function css() { $o=$this->opts(); $font=trim($o['font_family'])?'font-family:'.esc_attr($o['font_family']).';':''; $wrap_width=($o['max_width_mode']==='site')?'max-width:none;width:100%;margin:0;padding:0;':"max-width:{$o['max_width']}px;margin:40px auto;padding:36px 20px;"; $wrap_color=$o['text_color_inherit']?'':"color:{$o['text_color']};"; $wrap_bg=$o['background_color_inherit']?'':"background:{$o['background_color']};"; $primary_color=$o['primary_color_inherit']?'':"color:{$o['primary_color']};"; $primary_color_important=$o['primary_color_inherit']?'':"color:{$o['primary_color']}!important;"; $accent_color=$o['accent_color_inherit']?'':"color:{$o['accent_color']};"; $accent_icon=$o['accent_color_inherit']?'background:transparent;border:1px solid currentColor;color:inherit;':"background:{$o['accent_color']};color:#fff;"; $card_bg=$o['card_background_inherit']?'':"background:{$o['card_background']};"; return ".in3pida-llm-layer{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}#in3pida-faq-container.in3pida-faq-wrap, .in3pida-faq-wrap{{$wrap_width}{$wrap_color}{$wrap_bg}{$font}}.in3pida-faq-head{text-align:center;margin-bottom:30px}.in3pida-faq-kicker{display:inline-block;margin-bottom:12px;{$accent_color}font-weight:700;letter-spacing:.08em;text-transform:uppercase;font-size:13px}.in3pida-faq-title{margin:0;{$primary_color}font-size:clamp(32px,5vw,58px);line-height:1.04;font-weight:800}.in3pida-faq-intro{max-width:720px;margin:14px auto 0;font-size:18px;line-height:1.65}.in3pida-faq-list{display:grid;gap:14px}.in3pida-faq-item{{$card_bg}border:1px solid rgba(0,0,0,.08);border-radius:{$o['border_radius']}px;overflow:hidden;box-shadow:0 10px 30px rgba(31,42,68,.08);transition:box-shadow .2s ease,transform .2s ease,background-color .2s ease}.in3pida-faq-item:hover{box-shadow:0 14px 36px rgba(31,42,68,.13);transform:translateY(-1px)}.in3pida-faq-q,.entry-content .in3pida-faq-q,button.in3pida-faq-q{appearance:none!important;-webkit-appearance:none!important;box-sizing:border-box!important;width:100%!important;max-width:none!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:18px!important;margin:0!important;padding:22px 24px!important;background:transparent!important;border:0!important;outline:0!important;box-shadow:none!important;cursor:pointer;{$primary_color_important}font:inherit!important;font-size:19px!important;font-weight:750!important;text-align:left!important;text-decoration:none!important}.in3pida-faq-q:hover,.in3pida-faq-q:focus,.in3pida-faq-q:active{background:transparent!important;border:0!important;outline:0!important;box-shadow:none!important;{$primary_color_important}}.in3pida-faq-q span:first-child{display:block;width:100%}.in3pida-faq-icon{width:30px;height:30px;min-width:30px;border-radius:999px;{$accent_icon}display:grid;place-items:center;font-size:22px;line-height:1;transition:.2s}.in3pida-faq-a{display:none;padding:0 24px 24px;font-size:17px;line-height:1.7}.in3pida-faq-item.is-open .in3pida-faq-a{display:block}.in3pida-faq-item.is-open .in3pida-faq-icon{transform:rotate(45deg)}"; }
    public function shortcode($atts=[]) { $o=$this->opts(); $mq=empty($o['show_solo_ai'])?[['relation'=>'OR',['key'=>'_in3pida_llm_only','compare'=>'NOT EXISTS'],['key'=>'_in3pida_llm_only','value'=>'1','compare'=>'!=']]]:null; $q_args=['post_type'=>self::CPT,'posts_per_page'=>-1,'post_status'=>'publish','orderby'=>$o['order_by'],'order'=>$o['order']]; if($mq) $q_args['meta_query']=$mq; $q=new WP_Query($q_args); ob_start(); echo '<section id="in3pida-faq-container" class="in3pida-faq-wrap"><div class="in3pida-faq-head">'.((($o['show_kicker'] ?? 1))?'<span class="in3pida-faq-kicker">FAQ</span>':'').'<h1 class="in3pida-faq-title">'.esc_html($o['page_title']).'</h1>'; if($o['page_intro']) echo '<div class="in3pida-faq-intro">'.wp_kses_post(wpautop($o['page_intro'])).'</div>'; echo '</div><div class="in3pida-faq-list">'; $schema=[];$i=0; while($q->have_posts()){ $q->the_post(); $open=($i===0&&$o['open_first'])?' is-open':''; $expanded=$open?'true':'false'; echo '<article class="in3pida-faq-item'.$open.'"><button class="in3pida-faq-q" type="button" aria-expanded="'.$expanded.'"><span>'.esc_html(get_the_title()).'</span><span class="in3pida-faq-icon">+</span></button><div class="in3pida-faq-a">'.apply_filters('the_content', get_the_content()).'</div></article>'; $schema[]=['@type'=>'Question','name'=>wp_strip_all_tags(get_the_title()),'acceptedAnswer'=>['@type'=>'Answer','text'=>wp_strip_all_tags(get_the_content())]]; $i++; } wp_reset_postdata(); echo '</div></section>'; if($o['show_schema']&&$schema) echo '<script type="application/ld+json">'.wp_json_encode(['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>$schema]).'</script>'; return ob_get_clean(); }

    public function columns($cols){$cols['menu_order']='Ordine';$cols['llm_only']='Visibilità';return $cols;} public function column_content($col,$post_id){if($col==='menu_order') echo intval(get_post_field('menu_order',$post_id)); if($col==='llm_only'){if(get_post_meta($post_id,'_in3pida_llm_only',true)==='1') echo '<span style="background:#fbf4f7;border:1px solid #e4e4ec;color:#0D5F75;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px">🤖 Solo AI</span>'; else echo '<span style="font-size:11px;color:#666b84">Pubblica</span>';}} public function sortable_columns($cols){$cols['menu_order']='menu_order';return $cols;} public function admin_order_query($q){if(is_admin()&&$q->is_main_query()&&$q->get('post_type')===self::CPT&&!$q->get('orderby')){$q->set('orderby','menu_order');$q->set('order','ASC');}}
    public function remove_legacy_move_actions($actions,$post){
        if(!$post || $post->post_type !== self::CPT) return $actions;
        foreach((array)$actions as $key=>$html){
            $plain=wp_strip_all_tags((string)$html);
            if(stripos((string)$html,'in3pida_faq_move')!==false || in_array($key,['move_up','move_down','in3pida_move_up','in3pida_move_down'],true) || trim($plain)==='Su' || trim($plain)==='Giù' || trim($plain)==='Giu') unset($actions[$key]);
        }
        return $actions;
    }

    public function admin_assets($hook) {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && $screen->id === 'edit-' . self::CPT) {
            wp_enqueue_script('jquery-ui-sortable');
        }
        if (function_exists('wp_enqueue_media')) wp_enqueue_media();
        wp_enqueue_style('in3pida-google-fonts', 'https://fonts.googleapis.com/css2?family=Commissioner:wght@500&family=Source+Code+Pro:wght@400&family=Sarabun:wght@300;400;600&display=swap', [], null);
        wp_enqueue_script('jquery');
        wp_add_inline_style('wp-admin', '.in3pida-sev-badge{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:800;letter-spacing:.03em;white-space:nowrap}.in3pida-sev-critical{background:#fde8ed;color:#b00020;border:1px solid #f4b8c6}.in3pida-sev-medium{background:#fbf4f7;color:#0D5F75;border:1px solid #ead0dc}.in3pida-sev-low{background:#fafafa;color:#666b84;border:1px solid #e4e4ec}.in3pida-cc-global-bar{display:flex;align-items:center;gap:18px;flex-wrap:wrap;background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:16px 20px;margin-bottom:18px}.in3pida-cc-global-score{display:flex;flex-direction:column;gap:2px;padding-left:14px;min-width:120px}.in3pida-cc-global-score strong{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#646b80}.in3pida-cc-global-counts{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.in3pida-cc-global-meta{font-size:12px;color:#646b80;margin-left:6px}.in3pida-cc-ch-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px}.in3pida-cc-ch-title{font-size:14px;color:#171b33}.in3pida-cc-url-link{color:#0D5F75;font-size:12px;text-decoration:none;word-break:break-all}.in3pida-cc-url-link:hover{text-decoration:underline}.in3pida-cc-summary-bar{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}.in3pida-cc-table{border-collapse:collapse;font-size:13px}.in3pida-cc-table th{background:#fafafa;font-size:11px;text-transform:uppercase;letter-spacing:.05em;padding:8px 10px;color:#171b33}.in3pida-cc-table td{padding:8px 10px;vertical-align:top;border-top:1px solid #f0f0f4}.in3pida-cc-td-official{color:#35364f;font-weight:600}.in3pida-cc-td-found{color:#646b80;font-style:italic}.in3pida-cc-ok{color:#0D5F75;font-weight:700;margin:4px 0}.in3pida-tip{position:relative;cursor:help}.in3pida-tip::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);background:#171b33;color:#fff;font-size:12px;line-height:1.5;padding:8px 12px;border-radius:6px;width:240px;text-align:left;white-space:normal;pointer-events:none;opacity:0;transition:opacity .15s;z-index:9999;font-weight:400}.in3pida-tip:hover::after{opacity:1}.in3pida-cc-manual-badge{background:#fafafa;color:#666b84;border:1px solid #e4e4ec;font-size:11px;font-weight:800;padding:2px 9px;border-radius:999px}.in3pida-cc-manual-hint{background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:8px 12px;color:#171b33;font-size:13px;margin:4px 0 8px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}.in3pida-cc-manual-ch{border-left:4px solid #0D5F75!important;opacity:.85}');
        wp_add_inline_style('wp-admin', '
        .in3pida-admin-pro{max-width:1180px;margin-top:18px;color:#171b33;font-family:Sarabun,sans-serif}.in3pida-admin-pro *{box-sizing:border-box}.in3pida-hero{background:linear-gradient(135deg,#0D5F75 0%,#0a4d60 100%);border-radius:7px;padding:24px 32px;margin:0 0 22px;display:flex;align-items:center;justify-content:space-between;color:#fff;box-shadow:0 10px 30px rgba(13,95,117,.18)}.in3pida-brand{font-family:Commissioner,sans-serif;font-size:34px;line-height:1;font-weight:500;letter-spacing:.01em;color:#fff;text-transform:none}.in3pida-subtitle{font-family:"Source Code Pro",monospace;font-size:14px;font-weight:400;margin-top:6px;color:#fff;opacity:.96}.in3pida-version{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.28);border-radius:999px;padding:8px 15px;font-weight:800;color:#fff}.in3pida-top-actions{display:flex;gap:10px;margin:0 0 18px;flex-wrap:wrap}.in3pida-btn{display:inline-flex;align-items:center;gap:6px;background:#0D5F75;color:#fff!important;text-decoration:none;border-radius:4px;padding:11px 16px;font-weight:800;text-transform:uppercase;font-size:12px;letter-spacing:.02em;box-shadow:0 5px 14px rgba(13,95,117,.22);border:0;cursor:pointer}.in3pida-btn-blue{background:#0D5F75;box-shadow:0 5px 14px rgba(34,157,183,.22)}.in3pida-btn-light{background:#fff;color:#0D5F75!important;border:1px solid #e4e4ec;box-shadow:none}.in3pida-grid{display:grid;gap:22px}.in3pida-card{background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:24px;overflow:hidden;box-shadow:none}.in3pida-card h2{margin:-24px -24px 20px;padding:12px 24px;border-bottom:1px solid #e4e4ec;background:#fafafa;color:#181834;font-size:11px;font-weight:500;font-family:Commissioner,sans-serif;text-transform:uppercase;letter-spacing:.05em;border-radius:6px 6px 0 0}.in3pida-card h3{font-size:13px;text-transform:uppercase;letter-spacing:.06em;margin:22px 0 10px;color:#171b33}.in3pida-card-desc{margin:0 0 22px;color:#4b4d68;font-size:14px}.in3pida-fields{display:grid;gap:18px}.in3pida-two-cols{grid-template-columns:repeat(2,minmax(0,1fr))}.in3pida-field{display:grid;grid-template-columns:210px minmax(0,1fr);gap:18px;align-items:center}.in3pida-field-full{align-items:start}.in3pida-field label{font-weight:800;color:#171b33}.in3pida-field input[type=text],.in3pida-field input[type=url],.in3pida-field input[type=email],.in3pida-field input[type=time],.in3pida-field input[type=number],.in3pida-field input[type=password],.in3pida-field textarea,.in3pida-field select,.in3pida-repeat-row input,.in3pida-repeat-box input,.in3pida-repeat-box textarea{width:100%;max-width:560px;border:1px solid #e4e4ec;border-radius:6px;padding:10px 13px;background:#fff;color:#35364f;box-shadow:none}.in3pida-field input:-webkit-autofill,.in3pida-field input:-webkit-autofill:hover,.in3pida-field input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 100px #fff inset!important;-webkit-text-fill-color:#35364f!important;background:#fff!important}.in3pida-field textarea{max-width:100%;min-height:96px}.in3pida-color{width:58px!important;height:38px;padding:3px!important;border-radius:6px!important}.in3pida-help{grid-column:2;margin:4px 0 0;color:#666b84;font-size:13px}.in3pida-help-local{grid-column:auto}.in3pida-mini-check{display:inline-flex!important;align-items:center;gap:6px;font-weight:700!important;color:#4b4d68!important;white-space:nowrap}.in3pida-mini-check input,.in3pida-check input{accent-color:#0D5F75}.in3pida-inline{display:flex;align-items:center;gap:8px;max-width:560px}.in3pida-inline select{max-width:220px!important}.in3pida-inline input[type=number]{max-width:180px!important}.in3pida-note{background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:13px 15px;color:#35364f;margin-bottom:18px}.in3pida-note a{color:#0D5F75;font-weight:800}.in3pida-alert{border-left:none}.in3pida-alert-text{color:#b00020;font-weight:700}.in3pida-check{display:flex;align-items:center;gap:8px;font-weight:700;color:#35364f}.in3pida-check-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px 18px}.in3pida-mt{margin-top:20px}.in3pida-savebar{position:sticky;bottom:0;margin-top:22px;background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:16px 18px;display:flex;align-items:center;gap:18px;box-shadow:none;z-index:4}.in3pida-save.button-primary{background:#0D5F75!important;border-color:#0D5F75!important;border-radius:4px;font-weight:800;text-transform:uppercase;padding:5px 16px}.post-type-in3pida_faq #menu_order{width:80px}.in3pida-ifaq-mini{display:inline-grid;place-items:center;width:34px;height:22px;margin-right:6px;border-radius:5px;background:#0D5F75;color:#fff;font-size:12px;font-weight:900;letter-spacing:-1px;text-transform:none;vertical-align:middle}#adminmenu a[href="post-new.php?post_type=in3pida_faq"]{display:none!important}body.post-type-in3pida_faq.edit-php .wrap h1.wp-heading-inline{display:none}body.post-type-in3pida_faq.edit-php .wrap .page-title-action{display:none!important}body.post-type-in3pida_faq.edit-php .wrap{max-width:1180px;margin-top:18px;color:#171b33}body.post-type-in3pida_faq .subsubsub{margin:14px 0 10px;padding:10px 14px;background:#fff;border:1px solid #e4e4ec;border-radius:6px;box-shadow:none}body.post-type-in3pida_faq .subsubsub a{color:#171b33;font-weight:800;text-decoration:none}body.post-type-in3pida_faq .subsubsub a.current{color:#0D5F75}body.post-type-in3pida_faq .search-box input[type=search]{border:1px solid #e4e4ec;border-radius:6px;padding:4px 10px;box-shadow:none}body.post-type-in3pida_faq .search-box .button,body.post-type-in3pida_faq .tablenav .button{border-color:#e4e4ec;color:#666b84;font-weight:800;border-radius:4px;background:#fff}body.post-type-in3pida_faq .wp-list-table{border:1px solid #e4e4ec;border-radius:6px;overflow:hidden;box-shadow:none}body.post-type-in3pida_faq .wp-list-table thead th,body.post-type-in3pida_faq .wp-list-table tfoot th{background:#fafafa;color:#171b33;font-weight:900;text-transform:uppercase;font-size:12px;letter-spacing:.05em;border-bottom:1px solid #e4e4ec}body.post-type-in3pida_faq .wp-list-table td,body.post-type-in3pida_faq .wp-list-table th{padding-top:13px;padding-bottom:13px}body.post-type-in3pida_faq .wp-list-table tbody tr:hover{background:#e8ecf7}body.post-type-in3pida_faq .wp-list-table .row-title{color:#171b33;font-size:15px;font-weight:400}body.post-type-in3pida_faq .row-actions a{color:#0D5F75;font-weight:800}body.post-type-in3pida_faq .bulkactions select,body.post-type-in3pida_faq .tablenav-pages .current-page{border:1px solid #e4e4ec;border-radius:6px}.in3pida-list-shell{max-width:1180px;margin:10px 0 18px}.in3pida-list-hero{margin-bottom:16px}.in3pida-list-actions{margin-bottom:18px}.in3pida-list-card{padding:20px 24px;margin-bottom:18px}.in3pida-list-card h2{margin:-20px -24px 16px;padding:10px 24px;border-bottom:1px solid #e4e4ec;background:#fafafa;color:#181834;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;border-radius:6px 6px 0 0}.in3pida-list-card .in3pida-card-desc{margin-bottom:0}.in3pida-repeater{display:grid;gap:12px}.in3pida-repeat-row{display:flex;gap:10px;align-items:center}.in3pida-repeat-two{display:grid;grid-template-columns:1fr 1fr auto}.in3pida-repeat-box{display:grid;gap:10px;background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:14px}.in3pida-repeat-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.in3pida-room-box h4{margin:8px 0 0;color:#171b33}.in3pida-room-amenities{grid-template-columns:repeat(3,minmax(0,1fr));align-items:center}.in3pida-media-select,.in3pida-remove,.in3pida-confirm{border:1px solid #e4e4ec;background:#fff;color:#0D5F75;font-weight:800;border-radius:4px;padding:8px 10px;cursor:pointer}.in3pida-media-select{color:#0D5F75}.in3pida-confirm{color:#666b84}.in3pida-confirm.is-confirmed{background:#e8f2f5}.in3pida-custom-check{background:#fff;border:1px dashed #0D5F75;border-radius:6px;padding:8px 10px}.in3pida-check input[type=checkbox],.in3pida-room-amenities input[type=checkbox],.in3pida-repeat-box .in3pida-check input[type=checkbox]{width:16px!important;min-width:16px!important;max-width:16px!important;height:16px!important;margin:0!important;padding:0!important;display:inline-block!important;box-shadow:none!important}.in3pida-room-amenities .in3pida-check{background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:10px 12px;min-height:38px}.in3pida-json-preview{width:100%;min-height:420px;font-family:monospace;border:1px solid #e4e4ec;border-radius:6px;padding:16px;background:#fafafa;color:#171b33}.in3pida-kpi-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.in3pida-kpi-grid>div{background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:14px}.in3pida-kpi-grid strong{display:block;color:#171b33;margin-bottom:6px}.in3pida-kpi-grid span{color:#0D5F75;font-weight:900}.in3pida-cc-meta{font-size:12px;color:#646b80;margin-top:6px}.in3pida-score{float:right;background:#0D5F75;color:#fff;border-radius:999px;padding:4px 10px;font-size:13px}.in3pida-report-list{display:grid;gap:16px;margin-top:18px}.in3pida-savebar-inline{margin-top:16px}.in3pida-top-actions-inner{margin-bottom:0}@media(max-width:900px){.in3pida-two-cols,.in3pida-check-grid,.in3pida-repeat-grid{grid-template-columns:1fr}.in3pida-field{grid-template-columns:1fr;gap:8px}.in3pida-help{grid-column:auto}.in3pida-hero{padding:22px;align-items:flex-start}.in3pida-brand{font-size:28px}.in3pida-repeat-two{grid-template-columns:1fr}}.in3pida-logo-row{max-width:760px}.in3pida-logo-row .in3pida-logo-url{max-width:560px}.in3pida-media-remove-logo{border:1px solid #e4e4ec;background:#fff;color:#0D5F75;font-weight:800;border-radius:4px;padding:8px 10px;cursor:pointer}.in3pida-advanced{border:1px solid #e4e4ec;border-radius:6px;padding:13px 15px;background:#fff}.in3pida-advanced summary{cursor:pointer;font-weight:900;color:#171b33}.in3pida-progress-track{height:10px;background:#fff;border:1px solid #e4e4ec;border-radius:999px;margin-top:10px;overflow:hidden}.in3pida-cc-progress-bar{height:10px;width:0%;background:#0D5F75;transition:width .2s}.in3pida-cc-channel-statuses{display:grid;gap:8px;margin-top:12px}.in3pida-cc-status-row{display:flex;justify-content:space-between;gap:12px;background:#fff;border:1px solid #e4e4ec;border-radius:6px;padding:8px 10px}.in3pida-cc-status-row.is-running{border-left:4px solid #0D5F75}.in3pida-cc-status-row.is-done{border-left:4px solid #e4e4ec}.in3pida-cc-status-row.is-error{border-left:4px solid #0D5F75}.in3pida-cc-live-log{margin-top:12px;font-size:13px;color:#4b4d68}.in3pida-cc-log-line{border-top:1px solid #e4e4ec;padding:6px 0}.in3pida-robots-modal{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:100000;display:flex;align-items:center;justify-content:center}.in3pida-robots-modal-box{background:#fff;max-width:680px;width:calc(100% - 40px);border-radius:8px;padding:24px;position:relative;box-shadow:0 18px 60px rgba(0,0,0,.25)}.in3pida-robots-close{position:absolute;right:12px;top:10px;border:0;background:transparent;font-size:28px;cursor:pointer}.in3pida-char-hint{margin-top:-8px;color:#666b84;font-size:13px}@media print{@page{size:A4;margin:14mm 12mm}body.in3pida-print-cc-report{background:#fff!important;color:#111!important;font:12px/1.45 Arial,Helvetica,sans-serif!important}body.in3pida-print-cc-report #adminmenumain,body.in3pida-print-cc-report #wpadminbar,body.in3pida-print-cc-report #wpfooter,body.in3pida-print-cc-report .notice,body.in3pida-print-cc-report .update-nag,body.in3pida-print-cc-report .in3pida-hero,body.in3pida-print-cc-report .in3pida-top-actions,body.in3pida-print-cc-report .in3pida-savebar,body.in3pida-print-cc-report .in3pida-card:not(#in3pida-cc-report-print){display:none!important}body.in3pida-print-cc-report #wpcontent,body.in3pida-print-cc-report #wpbody-content,body.in3pida-print-cc-report .wrap,body.in3pida-print-cc-report .in3pida-admin-pro,body.in3pida-print-cc-report .in3pida-grid{margin:0!important;padding:0!important;max-width:none!important;width:auto!important;display:block!important}body.in3pida-print-cc-report #in3pida-cc-report-print{display:block!important;border:0!important;border-radius:0!important;box-shadow:none!important;width:100%!important;max-width:none!important;margin:0!important;padding:0!important;background:#fff!important;color:#111!important}.in3pida-print-cover{display:block!important;border-bottom:3px solid #0D5F75!important;margin:0 0 16px!important;padding:0 0 12px!important}.in3pida-print-brand{font-size:16px!important;font-weight:900!important;color:#0D5F75!important;text-transform:uppercase!important;letter-spacing:.05em!important}.in3pida-print-cover h1{font-size:24px!important;line-height:1.2!important;margin:8px 0 8px!important;color:#111!important}.in3pida-print-cover p{margin:3px 0!important;color:#333!important}body.in3pida-print-cc-report #in3pida-cc-report-print h2{font-size:16px!important;margin:16px 0 10px!important;padding:0 0 8px!important;border-bottom:1px solid #ddd!important;color:#111!important;text-transform:uppercase!important;letter-spacing:.04em!important}body.in3pida-print-cc-report #in3pida-cc-report-print h3{font-size:14px!important;margin:0 0 8px!important;color:#111!important;text-transform:none!important;letter-spacing:0!important}.in3pida-print-summary{display:grid!important;grid-template-columns:repeat(3,1fr)!important;gap:8px!important;margin:0 0 14px!important}.in3pida-print-summary>div{background:#fff!important;border:1px solid #ccc!important;border-radius:0!important;padding:8px!important;break-inside:avoid!important}.in3pida-print-summary strong{display:block!important;color:#111!important;font-size:10px!important;text-transform:uppercase!important;margin-bottom:4px!important}.in3pida-print-summary span{color:#0D5F75!important;font-size:15px!important;font-weight:900!important}.in3pida-report-list{display:block!important;margin-top:10px!important}.in3pida-print-channel{display:block!important;background:#fff!important;border:1px solid #ccc!important;border-left:4px solid #0D5F75!important;border-radius:0!important;padding:10px!important;margin:0 0 12px!important;break-inside:avoid!important;page-break-inside:avoid!important}.in3pida-score{float:right!important;background:#0D5F75!important;color:#fff!important;border-radius:10px!important;padding:2px 8px!important;font-size:11px!important}.in3pida-card-desc{font-size:11px!important;color:#333!important;margin:0 0 8px!important;word-break:break-word!important}.in3pida-print-table,body.in3pida-print-cc-report #in3pida-cc-report-print table{width:100%!important;border-collapse:collapse!important;table-layout:fixed!important;font-size:10.5px!important;background:#fff!important}.in3pida-print-table th,body.in3pida-print-cc-report #in3pida-cc-report-print th{background:#f2f2f2!important;color:#111!important;font-weight:800!important;text-align:left!important}.in3pida-print-table th,.in3pida-print-table td,body.in3pida-print-cc-report #in3pida-cc-report-print th,body.in3pida-print-cc-report #in3pida-cc-report-print td{border:1px solid #bbb!important;padding:5px!important;vertical-align:top!important;word-break:break-word!important}.in3pida-print-footer{display:block!important;border-top:1px solid #ddd!important;margin-top:18px!important;padding-top:8px!important;font-size:10px!important;color:#666!important}.in3pida-note{background:#fff!important;border:1px solid #ccc!important;color:#111!important}.in3pida-print-cc-report a{color:#111!important;text-decoration:none!important}.in3pida-cc-global-bar{display:block!important;border:1px solid #ccc!important;padding:8px 10px!important;margin-bottom:10px!important;background:#fff!important}.in3pida-cc-global-score{display:block!important;margin-bottom:4px!important}.in3pida-cc-global-counts{display:block!important;margin-top:4px!important}.in3pida-cc-ch-header{display:block!important;overflow:hidden!important}.in3pida-cc-summary-bar{display:block!important;margin-bottom:6px!important}.in3pida-sev-badge{display:inline-block!important;margin-right:5px!important;margin-bottom:3px!important;padding:1px 6px!important;font-size:10px!important}}
        ');
        wp_add_inline_style('wp-admin', '
        /* === ISI overrides v1.8.6 === */
        .in3pida-card,.in3pida-admin-pro .in3pida-repeat-box,.in3pida-admin-pro .in3pida-note,.in3pida-admin-pro .in3pida-savebar,.in3pida-admin-pro .in3pida-kpi-grid>div,.in3pida-admin-pro .in3pida-advanced,.in3pida-admin-pro .in3pida-cc-status-row,.in3pida-admin-pro .in3pida-cc-manual-hint,.in3pida-admin-pro .in3pida-json-preview,.in3pida-admin-pro .in3pida-cc-global-bar,.in3pida-admin-pro .in3pida-robots-modal-box,body.post-type-in3pida_faq .wp-list-table,body.post-type-in3pida_faq .subsubsub,.in3pida-admin-pro .in3pida-progress-track,.in3pida-admin-pro .button,.in3pida-admin-pro .button-primary,.in3pida-admin-pro input[type=submit],.in3pida-admin-pro .in3pida-btn,.in3pida-admin-pro .in3pida-remove,.in3pida-admin-pro .in3pida-confirm,.in3pida-admin-pro .in3pida-media-select,.in3pida-admin-pro .in3pida-media-remove-logo,.in3pida-admin-pro .in3pida-media-select-logo,body.post-type-in3pida_faq .button,body.post-type-in3pida_faq .search-box .button{border-radius:6px!important}
        .in3pida-card{border:1px solid #e4e4ec!important}
        body.post-type-in3pida_faq .wp-list-table{border:1px solid #e4e4ec!important;border-radius:6px!important;overflow:hidden!important}
        body.post-type-in3pida_faq #posts-filter,body.post-type-in3pida_faq .wp-list-table *{border-radius:6px!important}
        body.post-type-in3pida_faq .wp-list-table thead th,body.post-type-in3pida_faq .wp-list-table tfoot th{background:#fafafa!important;white-space:nowrap!important;color:#171b33!important}
        body.post-type-in3pida_faq .wp-list-table th a,body.post-type-in3pida_faq .wp-list-table th a:hover,body.post-type-in3pida_faq .manage-column a{color:#171b33!important;display:inline-flex!important;align-items:center!important;gap:3px!important;white-space:nowrap!important;padding-right:8px!important}
        body.post-type-in3pida_faq .wp-list-table th a .sorting-indicators{display:inline-flex!important;flex-direction:column!important;flex-shrink:0!important}
        body.post-type-in3pida_faq .wp-list-table th{padding-right:14px!important}
        .in3pida-admin-pro .in3pida-note{background:#fff!important}
        .in3pida-admin-pro .in3pida-repeat-box{background:#fff!important}
        .in3pida-admin-pro .in3pida-kpi-grid>div{background:#fff!important}
        .in3pida-admin-pro .in3pida-save.button-primary,.in3pida-admin-pro input[type=submit].button-primary{background:#0D5F75!important;border-color:#0D5F75!important;padding:10px 16px!important;height:auto!important;line-height:1!important}
        .in3pida-admin-pro .in3pida-savebar{border-color:#e4e4ec!important}
        .in3pida-admin-pro .in3pida-btn-blue{background:#0D5F75!important;box-shadow:0 5px 14px rgba(13,95,117,.22)!important}
        .in3pida-admin-pro .in3pida-media-select{color:#0D5F75!important}
        .in3pida-admin-pro .in3pida-confirm{color:#0D5F75!important}
        .in3pida-admin-pro .in3pida-confirm.is-confirmed{background:#e8f2f5!important}
        .in3pida-admin-pro .in3pida-cc-status-row.is-running{border-left-color:#0D5F75!important}
        .in3pida-admin-pro .in3pida-cc-url-link{color:#0D5F75!important}
        .in3pida-admin-pro .in3pida-cc-manual-badge{background:#fafafa!important;color:#666b84!important;border-color:#e4e4ec!important}
        .in3pida-admin-pro .in3pida-cc-manual-hint{background:#fff!important;border-color:#e4e4ec!important;color:#171b33!important}
        .in3pida-admin-pro .in3pida-cc-manual-ch{border-left-color:#e4e4ec!important}
        .in3pida-admin-pro button.in3pida-remove,.in3pida-admin-pro button.in3pida-confirm,.in3pida-admin-pro button.in3pida-add,.in3pida-admin-pro button.in3pida-media-select,.in3pida-admin-pro .in3pida-media-remove-logo,.in3pida-admin-pro .in3pida-media-select-logo{width:auto!important;display:inline-flex!important;align-items:center;justify-self:start!important;align-self:start!important;font-family:inherit;font-size:inherit;padding:10px 16px!important;font-weight:800!important}
        .in3pida-admin-pro .in3pida-btn{width:auto!important;display:inline-flex!important;justify-self:start;align-self:start}
        .in3pida-admin-pro .in3pida-remove{width:auto!important;display:inline-flex!important;justify-self:start!important;align-self:start!important;background:#fff!important;color:#0D5F75!important;border:1px solid #e4e4ec!important;padding:10px 16px!important;font-weight:800!important;font-size:12px!important;text-transform:uppercase!important;letter-spacing:.02em!important;cursor:pointer!important}
        .in3pida-admin-pro .in3pida-card h3{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;margin:20px 0 10px;color:#171b33;padding-top:16px;border-top:1px solid #e4e4ec}
        #adminmenu li.menu-icon-in3pida_faq.wp-has-current-submenu .wp-menu-image:before,#adminmenu li.menu-icon-in3pida_faq:hover .wp-menu-image:before{color:#0D5F75!important}
        .in3pida-ai-tabs{display:flex;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;border-bottom:1px solid #e4e4ec;background:#fafafa}
        .in3pida-ai-tabs::-webkit-scrollbar{display:none}
        .in3pida-ai-tab{flex:0 0 auto;padding:10px 16px;border:none;background:none;cursor:pointer;font-size:11px;font-weight:700;letter-spacing:.05em;color:#4a4a6a;border-bottom:2px solid transparent;text-transform:uppercase;white-space:nowrap;transition:color .15s;font-family:inherit;margin-bottom:-1px}
        .in3pida-ai-tab.active{color:#FF8500;border-bottom-color:#FF8500;background:#fff}
        .in3pida-ai-tab:hover{color:#FF8500}
        .in3pida-ai-panel{padding:20px 24px}
        .ui-datepicker{border-radius:0!important;box-shadow:0 4px 18px rgba(0,0,0,.15)!important}
        .ui-datepicker .ui-datepicker-header{background:#0D5F75!important}
        .ui-datepicker td span,.ui-datepicker td a{border-radius:6px!important}
        .ui-datepicker .ui-state-active,.ui-datepicker .ui-state-highlight{background:#0D5F75!important;color:#fff!important;border-radius:0!important}
        .in3pida-admin-pro .in3pida-cc-table th{background:#f5f5f5!important}
        .in3pida-admin-pro input[type=checkbox],.in3pida-check input[type=checkbox],.in3pida-mini-check input[type=checkbox],.in3pida-room-amenities input[type=checkbox],body.post-type-in3pida_faq input[type=checkbox]{accent-color:#0D5F75!important}
        .in3pida-admin-pro input[type=checkbox]:checked,.in3pida-check input[type=checkbox]:checked,.in3pida-mini-check input[type=checkbox]:checked,.in3pida-room-amenities input[type=checkbox]:checked,body.post-type-in3pida_faq input[type=checkbox]:checked{background-color:#0D5F75!important;border-color:#0D5F75!important}
        .in3pida-admin-pro input[type=checkbox]:focus,.in3pida-check input[type=checkbox]:focus,.in3pida-mini-check input[type=checkbox]:focus,.in3pida-room-amenities input[type=checkbox]:focus,body.post-type-in3pida_faq input[type=checkbox]:focus{border-color:#0D5F75!important;box-shadow:0 0 0 1px #0D5F75!important}
        .in3pida-admin-pro input[type=date]{accent-color:#0D5F75}
        .in3pida-admin-pro input[type=date]:focus{border-color:#0D5F75!important;outline:none}
        .in3pida-time-picker{display:inline-flex;align-items:center;gap:0;border:1px solid #e4e4ec;border-radius:6px;background:#fff;overflow:hidden;max-width:160px}
        .in3pida-time-select{border:0!important;box-shadow:none!important;border-radius:0!important;padding:9px 10px;background:#fff;color:#35364f;font-weight:700;font-size:14px;cursor:pointer;appearance:none;-webkit-appearance:none;text-align:center;min-width:54px;outline:none;font-family:inherit;max-width:none!important;width:auto!important}
        .in3pida-time-sep{font-weight:900;color:#171b33;font-size:16px;line-height:1;user-select:none}
        .in3pida-time-select:focus{background:#f0fafc;color:#0D5F75;outline:none!important;box-shadow:none!important}
        .in3pida-time-picker:focus-within{border-color:#0D5F75;box-shadow:0 0 0 1px #0D5F75}
        .in3pida-room-name-url-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .in3pida-two-cols .in3pida-field{align-items:start!important}
        .in3pida-logo-control{align-items:stretch!important}
        .in3pida-logo-control .in3pida-logo-url{flex:1!important;max-width:none!important;height:40px!important;box-sizing:border-box!important}
        .in3pida-logo-control .in3pida-media-select-logo,.in3pida-logo-control .in3pida-media-remove-logo{height:40px!important;box-sizing:border-box!important;flex-shrink:0!important;padding-top:0!important;padding-bottom:0!important;align-items:center!important;display:inline-flex!important}
        .in3pida-admin-pro #in3pida-cc-ajax-scan{padding:11px 16px!important;height:auto!important;line-height:1!important;font-size:12px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.02em!important;border-radius:6px!important}
        .in3pida-room-box .in3pida-room-service-repeater .in3pida-btn,.in3pida-room-box .in3pida-remove-room,.in3pida-repeater[data-kind=room]>.in3pida-btn{min-width:270px!important;width:auto!important;justify-content:center!important}
        .in3pida-cc-remove-wrap{display:flex;justify-content:flex-start}
        .in3pida-cc-remove-wrap .in3pida-remove{width:auto!important;background:#fff!important;color:#0D5F75!important;border:1px solid #e4e4ec!important;padding:10px 16px!important;font-weight:800!important;font-size:12px!important;text-transform:uppercase!important;letter-spacing:.02em!important;cursor:pointer!important;border-radius:6px!important;font-family:inherit!important;display:inline-flex!important;align-items:center!important}
        ');
        wp_add_inline_script('jquery-core', <<<'JS'
document.addEventListener('click',function(e){
  if(e.target.classList.contains('in3pida-remove')){
    var box=e.target.closest('.in3pida-repeat-row,.in3pida-repeat-box');
    if(box) box.remove();
  }
  if(e.target.classList.contains('in3pida-add')){
    var rep=e.target.closest('.in3pida-repeater'); if(!rep)return;
    var name=rep.getAttribute('data-name'), kind=rep.getAttribute('data-kind'), i=Date.now(); var html='';
    if(kind==='url'){
      var media=rep.getAttribute('data-media')==='1';
      html='<div class="in3pida-repeat-row">'+(media?'<input type="hidden" class="in3pida-media-id" name="'+name+'['+i+'][id]" value=""><input type="hidden" class="in3pida-media-url" name="'+name+'['+i+'][url]" value=""><input type="text" class="in3pida-media-preview" placeholder="URL immagine">':'<input type="url" name="'+name+'['+i+'][url]" placeholder="URL">')+(media?'<button type="button" class="in3pida-media-select">Seleziona immagine</button>':'')+'<button type="button" class="in3pida-remove">Rimuovi</button></div>';
    }
    if(kind==='textlist'){
      html='<div class="in3pida-repeat-row"><input type="text" name="'+name+'[]" placeholder="Aggiungi voce"><button type="button" class="in3pida-confirm">Aggiungi</button><button type="button" class="in3pida-remove">Rimuovi</button></div>';
    }
    if(kind==='breadcrumb'){
      html='<div class="in3pida-repeat-row in3pida-repeat-two"><input type="text" name="'+name+'['+i+'][name]" placeholder="Nome livello"><input type="url" name="'+name+'['+i+'][url]" placeholder="URL livello"><button type="button" class="in3pida-remove">Rimuovi</button></div>';
    }
    if(kind==='offer'){
      html='<div class="in3pida-repeat-box"><input name="'+name+'['+i+'][url]" placeholder="URL prenotazione"><input name="'+name+'['+i+'][name]" placeholder="Nome offerta/servizio"><textarea name="'+name+'['+i+'][description]" placeholder="Descrizione offerta"></textarea><input name="'+name+'['+i+'][price]" placeholder="Prezzo da"><input name="'+name+'['+i+'][currency]" value="EUR" placeholder="Valuta"><button type="button" class="in3pida-remove">Rimuovi</button></div>';
    }
    if(kind==='room'){
      html='<div class="in3pida-repeat-box in3pida-room-box"><div class="in3pida-room-name-url-row"><input name="'+name+'['+i+'][name]" placeholder="Nome camera"><input name="'+name+'['+i+'][url]" placeholder="URL pagina camera"></div><textarea name="'+name+'['+i+'][description]" placeholder="Descrizione AI-oriented" style="width:100%;max-width:100%"></textarea><div class="in3pida-repeat-grid"><input name="'+name+'['+i+'][min]" placeholder="Capienza min"><input name="'+name+'['+i+'][max]" placeholder="Capienza max"><input name="'+name+'['+i+'][bed]" placeholder="Tipo letto"><input name="'+name+'['+i+'][price]" placeholder="Prezzo da"><input name="'+name+'['+i+'][currency]" value="EUR" placeholder="Valuta"><input name="'+name+'['+i+'][availability]" placeholder="Disponibilità / note"><input name="'+name+'['+i+'][view]" placeholder="Vista"></div><h4>Servizi camera</h4><div class="in3pida-check-grid in3pida-room-amenities"><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Bagno privato"> Bagno privato</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Aria condizionata"> Aria condizionata</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Wi-Fi"> Wi-Fi</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="TV"> TV</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Minibar"> Minibar</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Balcone"> Balcone</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Cucina"> Cucina</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Frigorifero"> Frigorifero</label><label class="in3pida-check"><input type="checkbox" name="'+name+'['+i+'][amenities][]" value="Accessibile"> Accessibile</label></div><div class="in3pida-repeater in3pida-room-service-repeater in3pida-mt" data-name="'+name+'['+i+'][amenities]" data-kind="textlist"><button type="button" class="in3pida-btn in3pida-add">Aggiungi servizio camera</button></div><button type="button" class="in3pida-remove in3pida-remove-room">Rimuovi camera/appartamento</button></div>';
    }
    if(kind==='cc_channel'){
      var manualTypes=['Booking','Tripadvisor','Google Business Profile','Expedia','Airbnb'];
      var manualJson=JSON.stringify(manualTypes);
      var opts=['Sito ufficiale','Pagina camere','Pagina servizi','Pagina contatti','Facebook','Instagram','LinkedIn','Bing Places','Hotels.com','Venere.com','Agoda','Consorzio / Associazione','Portale regionale turismo','Blog / Stampa','Sito partner','Booking','Tripadvisor','Google Business Profile','Expedia','Airbnb','Altro'].map(function(t){return '<option value=”'+t+'”>'+t+'</option>';}).join('');
      html='<div class=”in3pida-repeat-box in3pida-cc-row”><div class=”in3pida-repeat-grid”><select name=”channels['+i+'][type]” class=”in3pida-ch-type-select” data-manual=\''+manualJson+'\'>'+opts+'</select><input type=”text” name=”channels['+i+'][name]” placeholder=”Nome scheda / etichetta interna”><input type=”url” name=”channels['+i+'][url]” placeholder=”URL canale”></div><div class=”in3pida-cc-manual-hint” style=”display:none”><span class=”in3pida-sev-badge in3pida-cc-manual-badge”>Verifica manuale</span> Questo portale blocca le scansioni automatiche. La scansione non viene eseguita: apri la scheda manualmente e verifica i dati.</div><p class=”in3pida-card-desc in3pida-field-help”><strong>Nome scheda / etichetta interna:</strong> è un nome libero per riconoscere meglio il canale nel report.</p><div class=”in3pida-cc-meta”>Stato ultimo controllo: <strong>Non scansionato</strong> &nbsp; Data ultima scansione: <strong>-</strong></div><div class=”in3pida-cc-remove-wrap”><button type=”button” class=”in3pida-remove”>Rimuovi canale</button></div></div>';
    }
    if(html){
      e.target.insertAdjacentHTML('beforebegin',html);
      var newSel=e.target.previousElementSibling && e.target.previousElementSibling.querySelector('.in3pida-ch-type-select');
      if(newSel) updateManualHint(newSel);
    }
  }
  if(e.target.classList.contains('in3pida-confirm')){
    var row=e.target.closest('.in3pida-repeat-row');
    var input=row ? row.querySelector('input[type=text]') : null;
    if(input && input.value.trim()!==''){
      var rep=row.closest('.in3pida-repeater');
      var grid=rep ? rep.previousElementSibling : null;
      while(grid && !grid.classList.contains('in3pida-check-grid')) grid=grid.previousElementSibling;
      if(grid){
        var label=document.createElement('label');
        label.className='in3pida-check in3pida-custom-check';
        var cb=document.createElement('input');
        cb.type='checkbox'; cb.name=input.name; cb.value=input.value.trim(); cb.checked=true;
        label.appendChild(cb); label.appendChild(document.createTextNode(' '+input.value.trim()));
        grid.appendChild(label);
        row.remove();
      }
    }
  }
  if(e.target.classList.contains('in3pida-media-select')){
    var row=e.target.closest('.in3pida-repeat-row');
    var preview=row ? row.querySelector('input.in3pida-media-preview') : null;
    var hidden=row ? row.querySelector('input.in3pida-media-id') : null;
    var legacy=row ? row.querySelector('input.in3pida-media-url') : null;
    if(window.wp&&wp.media){var frame=wp.media({title:'Seleziona immagine',button:{text:'Usa questa immagine'},multiple:false}); frame.on('select',function(){var att=frame.state().get('selection').first().toJSON(); if(preview) preview.value=att.url||''; if(hidden) hidden.value=att.id||''; if(legacy) legacy.value='';}); frame.open();}
  }
  if(e.target.classList.contains('in3pida-copy-json')){
    var el=document.getElementById(e.target.getAttribute('data-target')); if(el){el.select();document.execCommand('copy');e.target.textContent='Copiato';setTimeout(function(){e.target.textContent='Copia JSON-LD'},1400);}
  }
});



document.addEventListener('click',function(e){
  if(e.target.classList.contains('in3pida-media-select-logo')){
    e.preventDefault();
    var wrap=e.target.closest('.in3pida-logo-control');
    if(!wrap || !window.wp || !wp.media) return;
    var frame=wp.media({title:'Seleziona logo',button:{text:'Usa questo logo'},multiple:false});
    frame.on('select',function(){
      var att=frame.state().get('selection').first().toJSON();
      var id=wrap.querySelector('.in3pida-logo-id');
      var url=wrap.querySelector('.in3pida-logo-url');
      if(id) id.value=att.id||'';
      if(url) url.value=att.url||'';
    });
    frame.open();
  }
  if(e.target.classList.contains('in3pida-media-remove-logo')){
    e.preventDefault();
    var wrap=e.target.closest('.in3pida-logo-control'); if(!wrap) return;
    var id=wrap.querySelector('.in3pida-logo-id'); var url=wrap.querySelector('.in3pida-logo-url');
    if(id) id.value=''; if(url) url.value='';
  }
  if(e.target.classList.contains('in3pida-robots-help')){
    e.preventDefault();
    var notice=e.target.closest('.in3pida-robots-notice'); var modal=notice ? notice.querySelector('.in3pida-robots-modal') : null;
    if(modal) modal.style.display='flex';
  }
  if(e.target.classList.contains('in3pida-robots-close') || e.target.classList.contains('in3pida-robots-modal')){
    var modal=e.target.classList.contains('in3pida-robots-modal') ? e.target : e.target.closest('.in3pida-robots-modal');
    if(modal) modal.style.display='none';
  }
});



document.addEventListener('DOMContentLoaded',function(){
  var saveForm=document.querySelector('.in3pida-consistency-page form[action*="admin-post.php"]');
  if(saveForm){
    saveForm.addEventListener('submit',function(){
      var btn=saveForm.querySelector('button[type="submit"]');
      if(btn){ btn.disabled=true; btn.textContent='Salvataggio canali...'; }
      var note=document.createElement('div');
      note.className='in3pida-note';
      note.innerHTML='<strong>Salvataggio in corso...</strong> Attendi la conferma.';
      saveForm.appendChild(note);
    });
  }
  var refresh=document.querySelector('.in3pida-consistency-page a[href*="in3pida-coerenza-contenuti"]');
  if(refresh && refresh.textContent.indexOf('Aggiorna report')!==-1){
    refresh.addEventListener('click',function(){ refresh.textContent='Aggiornamento...'; });
  }
});

function updateManualHint(sel){
  var manual=[];
  try{ manual=JSON.parse(sel.getAttribute('data-manual')||'[]'); }catch(e){}
  var hint=sel.closest('.in3pida-repeat-box') && sel.closest('.in3pida-repeat-box').querySelector('.in3pida-cc-manual-hint');
  if(hint) hint.style.display=manual.indexOf(sel.value)!==-1?'flex':'none';
}
document.addEventListener('change',function(e){
  if(e.target.classList.contains('in3pida-ch-type-select')) updateManualHint(e.target);
});
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.in3pida-ch-type-select').forEach(function(s){ updateManualHint(s); });
});

document.addEventListener('input',function(e){
  if(e.target.classList.contains('in3pida-media-preview')){
    var row=e.target.closest('.in3pida-repeat-row');
    var hidden=row ? row.querySelector('input.in3pida-media-id') : null;
    var legacy=row ? row.querySelector('input.in3pida-media-url') : null;
    if(hidden) hidden.value='';
    if(legacy) legacy.value=e.target.value||'';
  }
});

document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.in3pida-admin-pro input[type=time]').forEach(function(inp){
    var val=(inp.value||'00:00').split(':');
    var h=val[0]||'00', m=val[1]||'00';
    var wrap=document.createElement('div'); wrap.className='in3pida-time-picker';
    var selH=document.createElement('select'); selH.className='in3pida-time-select';
    for(var i=0;i<24;i++){var o=document.createElement('option');o.value=String(i).padStart(2,'0');o.textContent=o.value;if(o.value===h)o.selected=true;selH.appendChild(o);}
    var sep=document.createElement('span'); sep.className='in3pida-time-sep'; sep.textContent=':';
    var selM=document.createElement('select'); selM.className='in3pida-time-select';
    for(var j=0;j<60;j++){var o=document.createElement('option');o.value=String(j).padStart(2,'0');o.textContent=o.value;if(o.value===m)o.selected=true;selM.appendChild(o);}
    function sync(){inp.value=selH.value+':'+selM.value;}
    selH.addEventListener('change',sync); selM.addEventListener('change',sync);
    inp.style.display='none';
    wrap.appendChild(selH); wrap.appendChild(sep); wrap.appendChild(selM);
    inp.parentNode.insertBefore(wrap,inp.nextSibling);
  });
});

document.addEventListener('DOMContentLoaded',function(){
  var btn=document.getElementById('in3pida-cc-ajax-scan');
  if(!btn) return;
  var box=document.getElementById('in3pida-cc-progress');
  var bar=box ? box.querySelector('.in3pida-cc-progress-bar') : null;
  var text=box ? box.querySelector('.in3pida-cc-progress-text') : null;
  var msg=box ? box.querySelector('.in3pida-cc-progress-message') : null;
  var current=box ? box.querySelector('.in3pida-cc-current') : null;
  var log=box ? box.querySelector('.in3pida-cc-live-log') : null;
  function row(i){ return box ? box.querySelector('.in3pida-cc-status-row[data-index="'+i+'"]') : null; }
  function addLog(m){ if(!log) return; var div=document.createElement('div'); div.className='in3pida-cc-log-line'; div.textContent=m; log.appendChild(div); }
  function setRow(i,state,label){ var r=row(i); if(!r) return; r.classList.remove('is-running','is-done','is-error'); if(state) r.classList.add(state); var span=r.querySelector('span'); if(span) span.textContent=label; }
  function setProgress(p,m){
    if(box) box.style.display='block';
    if(bar) bar.style.width=p+'%';
    if(text) text.textContent=p+'%';
    if(msg && m) msg.textContent=m;
  }
  function scan(i,total,okCount,errCount){
    setRow(i,'is-running','In scansione');
    if(current) current.textContent='Canale in corso: '+(row(i) ? row(i).querySelector('strong').textContent : (i+1));
    var data=new FormData();
    data.append('action','in3pida_cc_scan_channel');
    data.append('nonce',btn.getAttribute('data-nonce')||'');
    data.append('index',i);
    if(i===0) data.append('reset','1');
    fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:data}).then(function(r){return r.json();}).then(function(res){
      if(!res || !res.success){ throw new Error((res && res.data && res.data.message) ? res.data.message : 'Errore durante la scansione'); }
      var d=res.data || {};
      var isErr=(String(d.status||'').toLowerCase().indexOf('errore')!==-1);
      if(isErr){ errCount++; setRow(i,'is-error','Errore'); } else { okCount++; setRow(i,'is-done','Completato'); }
      setProgress(d.progress||0,d.message||'Canale scansionato');
      addLog((isErr?'Errore: ':'OK: ')+(d.message||'Canale scansionato'));
      if(i+1<total){ scan(i+1,total,okCount,errCount); }
      else {
        btn.disabled=false; btn.textContent='Avvia scansione tutti i canali';
        setProgress(100,'Scansione completata. Completati: '+okCount+' - Errori: '+errCount+'. Aggiorno il report...');
        if(current) current.textContent='Scansione completata';
        setTimeout(function(){ window.location.reload(); }, 900);
      }
    }).catch(function(err){
      errCount++;
      setRow(i,'is-error','Errore');
      var label = row(i) ? row(i).querySelector('strong').textContent : ('Canale '+(i+1));
      addLog('Errore AJAX su '+label+': '+err.message);
      setProgress(Math.round(((i+1)/total)*100),'Errore su '+label+'. Continuo con il canale successivo...');
      if(i+1<total){ scan(i+1,total,okCount,errCount); }
      else {
        btn.disabled=false; btn.textContent='Avvia scansione tutti i canali';
        setProgress(100,'Scansione completata. Completati: '+okCount+' - Errori: '+errCount+'. Aggiorno il report...');
        if(current) current.textContent='Scansione completata';
        setTimeout(function(){ window.location.reload(); }, 900);
      }
    });
  }
  btn.addEventListener('click',function(){
    var total=parseInt(btn.getAttribute('data-total')||'0',10);
    if(box) box.style.display='block';
    if(log) log.innerHTML='';
    if(!total){ setProgress(0,'Nessun canale valido da scansionare. Aggiungi almeno un canale e salva.'); addLog('Nessun canale valido da scansionare.'); return; }
    btn.disabled=true; btn.textContent='Scansione in corso...';
    setProgress(0,'Scansione avviata');
    addLog('Scansione avviata');
    scan(0,total,0,0);
  });
});;



window.addEventListener('load', function(){
  if(document.body && document.body.classList.contains('post-type-in3pida_faq')){
    document.querySelectorAll('.row-actions a').forEach(function(a){
      var txt=(a.textContent||'').trim();
      var href=a.getAttribute('href')||'';
      if(txt==='Su' || txt==='Giù' || txt==='Giu' || href.indexOf('in3pida_faq_move')!==-1){
        var span=a.closest('span');
        if(span) span.remove(); else a.remove();
      }
    });
  }
});

window.addEventListener('load', function(){
  var screen=document.body && document.body.classList.contains('post-type-in3pida_faq');
  var table=document.querySelector('body.post-type-in3pida_faq table.wp-list-table.posts tbody#the-list');
  if(!screen || !table || !window.jQuery || !jQuery.fn.sortable) return;
  var notice=document.createElement('div');
  notice.className='notice notice-info is-dismissible in3pida-sort-notice';
  notice.style.display='none';
  notice.innerHTML='<p></p>';
  var wrap=document.querySelector('.wrap h1');
  if(wrap && wrap.parentNode) wrap.parentNode.insertBefore(notice, wrap.nextSibling);
  function showNotice(message,isError){
    notice.className='notice '+(isError?'notice-error':'notice-success')+' is-dismissible in3pida-sort-notice';
    notice.querySelector('p').textContent=message;
    notice.style.display='block';
    setTimeout(function(){notice.style.display='none';},2500);
  }
  jQuery(table).sortable({
    items:'tr.type-in3pida_faq',
    axis:'y',
    cursor:'move',
    helper:function(e,ui){ ui.children().each(function(){ jQuery(this).width(jQuery(this).width()); }); return ui; },
    placeholder:'in3pida-faq-sort-placeholder',
    update:function(){
      var ids=[];
      table.querySelectorAll('tr.type-in3pida_faq').forEach(function(row){
        var m=(row.id||'').match(/post-(\d+)/); if(m) ids.push(m[1]);
      });
      var data=new FormData();
      data.append('action','in3pida_faq_sort');
      data.append('nonce', window.in3pidaFaqSortNonce || '');
      ids.forEach(function(id){ data.append('ids[]',id); });
      fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:data}).then(function(r){return r.json();}).then(function(res){
        if(!res || !res.success) throw new Error((res && res.data && res.data.message) ? res.data.message : 'Errore salvataggio ordine');
        showNotice(res.data.message || 'Ordine FAQ aggiornato.', false);
      }).catch(function(err){ showNotice(err.message, true); });
    }
  });
});

JS);
        if (isset($screen) && $screen && $screen->id === 'edit-' . self::CPT) {
            wp_add_inline_script('jquery-ui-sortable', 'window.in3pidaFaqSortNonce = ' . wp_json_encode(wp_create_nonce('in3pida_faq_sort')) . ';');
            wp_add_inline_style('wp-admin', '.post-type-in3pida_faq table.wp-list-table tbody tr.type-in3pida_faq{cursor:move}.in3pida-faq-sort-placeholder{height:48px;background:#fbf4f7;border:2px dashed #0D5F75}');
        }
    }

    // ─── ISI — in3pida Sito Intelligente integration ─────────────────────────

    // ── AI PROFILE ENDPOINT ───────────────────────────────────────────────────

    public function register_ai_profile_rest_route() {
        register_rest_route('in3pida/v1', '/ai-profile', [
            'methods'             => 'GET, OPTIONS',
            'callback'            => [$this, 'ai_profile_rest_handler'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function ai_profile_rest_handler($request) {
        if ($request->get_method() === 'OPTIONS') {
            $response = new WP_REST_Response(null, 200);
            $response->header('Access-Control-Allow-Origin', '*');
            $response->header('Access-Control-Allow-Methods', 'GET, OPTIONS');
            return $response;
        }
        if (!$this->retrieval_is_enabled()) {
            return new WP_Error('disabled', 'LLM ready layer non attivo.', ['status' => 403]);
        }
        $s = $this->schema_opts();
        $lines = [];
        if (!empty($s['name']))          $lines[] = 'Nome: ' . $s['name'];
        if (!empty($s['type']))          $lines[] = 'Tipologia: ' . $s['type'];
        if (!empty($s['description']))   $lines[] = 'Descrizione: ' . $s['description'];
        if (!empty($s['url']))           $lines[] = 'Sito web: ' . $s['url'];
        if (!empty($s['telephone']))     $lines[] = 'Telefono: ' . $s['telephone'];
        if (!empty($s['email']))         $lines[] = 'Email: ' . $s['email'];
        $addr_parts = array_filter([$s['street'] ?? '', ($s['postal_code'] ?? '') . ' ' . ($s['city'] ?? ''), $s['region'] ?? '', 'Italia']);
        if (array_filter([$s['street'] ?? '', $s['city'] ?? ''])) $lines[] = 'Indirizzo: ' . implode(', ', array_filter($addr_parts));
        if (!empty($s['checkin_time']))  $lines[] = 'Check-in: ' . $s['checkin_time'];
        if (!empty($s['checkout_time'])) $lines[] = 'Check-out: ' . $s['checkout_time'];
        if (!empty($s['price_range']))   $lines[] = 'Fascia di prezzo: ' . $s['price_range'];
        if (!empty($s['pets_allowed']))  $lines[] = 'Animali ammessi: ' . $s['pets_allowed'];

        $amenities = array_filter(array_map('trim', (array)($s['amenities'] ?? [])));
        if ($amenities) {
            $lines[] = '';
            $lines[] = 'SERVIZI:';
            foreach ($amenities as $a) $lines[] = '- ' . (is_array($a) ? ($a['name'] ?? '') : $a);
        }

        $rooms = array_filter((array)($s['rooms'] ?? []));
        if ($rooms) {
            $lines[] = '';
            $lines[] = 'CAMERE E APPARTAMENTI:';
            foreach ($rooms as $r) {
                $rname = is_array($r) ? ($r['name'] ?? '') : $r;
                $rdesc = is_array($r) ? ($r['description'] ?? '') : '';
                $lines[] = '- ' . $rname . ($rdesc ? ': ' . $rdesc : '');
            }
        }

        $q = new WP_Query(['post_type' => self::CPT, 'posts_per_page' => -1, 'post_status' => 'publish']);
        if ($q->have_posts()) {
            $lines[] = '';
            $lines[] = 'DOMANDE FREQUENTI:';
            while ($q->have_posts()) {
                $q->the_post();
                $lines[] = 'D: ' . get_the_title();
                $lines[] = 'R: ' . wp_strip_all_tags(get_the_content());
            }
            wp_reset_postdata();
        }

        $text = implode("\n", $lines);
        $response = new WP_REST_Response($text);
        $response->header('Content-Type', 'text/plain; charset=utf-8');
        $response->header('Access-Control-Allow-Origin', '*');
        $response->header('Cache-Control', 'public, max-age=3600');
        return $response;
    }

    // ── COMPLETENESS SCORE ────────────────────────────────────────────────────

    public function compute_completeness() {
        $s = $this->schema_opts();
        $faq_count = wp_count_posts(self::CPT)->publish ?? 0;
        $checks = [
            'Nome struttura mancante'         => !empty($s['name']),
            'Descrizione mancante'            => !empty($s['description']) && strlen($s['description']) >= 30,
            'Telefono mancante'               => !empty($s['telephone']),
            'Email mancante'                  => !empty($s['email']),
            'Indirizzo mancante'              => !empty($s['street']) && !empty($s['city']),
            'Orario check-in mancante'        => !empty($s['checkin_time']),
            'Orario check-out mancante'       => !empty($s['checkout_time']),
            'Servizi non inseriti (min. 3)'   => count(array_filter((array)($s['amenities'] ?? []))) >= 3,
            'Camere non inserite'             => count(array_filter((array)($s['rooms'] ?? []))) >= 1,
            'Fascia di prezzo mancante'       => !empty($s['price_range']),
            'FAQ insufficienti (min. 5)'      => $faq_count >= 5,
            'FAQ insufficienti (min. 10)'     => $faq_count >= 10,
        ];
        $passed = count(array_filter($checks));
        $score  = (int) round(($passed / count($checks)) * 100);
        $missing = array_keys(array_filter($checks, fn($v) => !$v));
        return ['score' => $score, 'checklist' => $missing];
    }

    // ── QUERY SET AUTOMATICO ──────────────────────────────────────────────────
    private function generate_query_set() {
        $s    = $this->schema_opts();
        $city = trim($s['city'] ?? '');
        $amenities = array_values(array_filter(array_map('sanitize_text_field', (array)($s['amenities'] ?? []))));
        $rooms     = array_values(array_filter((array)($s['rooms'] ?? []), fn($r) => !empty($r['name'])));
        $targets   = array_values(array_filter(array_map('sanitize_text_field', (array)($s['targets'] ?? []))));
        $nearby    = array_filter(array_map('trim', explode(',', $s['nearby_attractions'] ?? '')));
        $pets      = !empty($s['pets_allowed']) && strtolower(trim($s['pets_allowed'])) !== 'no';

        $queries = [];

        if ($city) {
            $queries[] = ['query' => "hotel a {$city}",           'category' => 'location', 'keywords' => [$city]];
            $queries[] = ['query' => "dove dormire a {$city}",    'category' => 'location', 'keywords' => [$city]];
            $queries[] = ['query' => "migliore hotel a {$city}",  'category' => 'location', 'keywords' => [$city]];
        }

        if ($city) {
            $amenity_map = [
                'parcheggio' => "hotel con parcheggio a {$city}",
                'spa'        => "hotel con spa a {$city}",
                'piscina'    => "hotel con piscina a {$city}",
                'colonnina'  => "hotel con colonnina di ricarica a {$city}",
                'palestra'   => "hotel con palestra a {$city}",
                'wifi'       => "hotel con wifi gratuito a {$city}",
                'colazione'  => "hotel con colazione inclusa a {$city}",
                'spiaggia'   => "hotel vicino alla spiaggia a {$city}",
                'ristorante' => "hotel con ristorante a {$city}",
            ];
            foreach ($amenities as $a) {
                $al = strtolower($a);
                foreach ($amenity_map as $kw => $tpl) {
                    if (strpos($al, $kw) !== false) $queries[] = ['query' => $tpl, 'category' => 'services', 'keywords' => [$kw, $a]];
                }
            }
            if ($pets) $queries[] = ['query' => "hotel pet friendly a {$city}", 'category' => 'services', 'keywords' => ['animali', 'pet', 'cani']];

            $target_map = [
                'famil'  => "hotel per famiglie a {$city}",
                'bambin' => "hotel per bambini a {$city}",
                'busine' => "hotel business a {$city}",
                'coppi'  => "hotel per coppie a {$city}",
                'grupp'  => "hotel per gruppi a {$city}",
            ];
            foreach ($targets as $t) {
                $tl = strtolower($t);
                foreach ($target_map as $kw => $tpl) {
                    if (strpos($tl, $kw) !== false) $queries[] = ['query' => $tpl, 'category' => 'audience', 'keywords' => [$kw, $t]];
                }
            }
        }

        foreach (array_slice($nearby, 0, 4) as $poi) {
            if ($poi) $queries[] = ['query' => "hotel vicino {$poi}", 'category' => 'location', 'keywords' => [strtolower($poi)]];
        }

        // Deduplication
        $seen = []; $out = [];
        foreach ($queries as $q) { $k = strtolower($q['query']); if (!isset($seen[$k])) { $seen[$k] = true; $out[] = $q; } }
        return $out;
    }

    // ── FRESHNESS MONITOR ─────────────────────────────────────────────────────
    private function compute_freshness() {
        $faqs = get_posts(['post_type' => self::CPT, 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'modified', 'order' => 'DESC', 'fields' => 'all']);
        $faq_count    = count($faqs);
        $faq_last_gmt = !empty($faqs) ? $faqs[0]->post_modified_gmt : null;
        $schema_saved = get_option('in3pida_schema_last_saved', null);
        $schema_data  = $this->schema_opts();
        $now          = time();

        // Se il timestamp non c'è ma i dati esistono (sync da dashboard ISI), registra ora come data di riferimento
        if (!$schema_saved && !empty($schema_data['name'])) {
            $schema_saved = gmdate('c');
            update_option('in3pida_schema_last_saved', $schema_saved, false);
        }

        $days_faq    = $faq_last_gmt ? intval(($now - strtotime($faq_last_gmt)) / DAY_IN_SECONDS) : null;
        $days_schema = $schema_saved  ? intval(($now - strtotime($schema_saved))  / DAY_IN_SECONDS) : null;

        $alerts = [];
        if ($faq_count === 0)         $alerts[] = 'Nessuna FAQ pubblicata';
        elseif ($faq_count < 5)       $alerts[] = 'Meno di 5 FAQ pubblicate';
        if ($days_faq === null || $days_faq > 180)  $alerts[] = 'FAQ non aggiornate da oltre 6 mesi';
        if ($days_schema !== null && $days_schema > 180) $alerts[] = 'Schema.org non aggiornato da oltre 6 mesi';

        return [
            'faq_count'        => $faq_count,
            'faq_last_update'  => $faq_last_gmt,
            'days_since_faq'   => $days_faq,
            'schema_last_update' => $schema_saved,
            'days_since_schema'  => $days_schema,
            'alerts'           => $alerts,
        ];
    }

    // ── MISSING ANSWER DETECTOR ───────────────────────────────────────────────
    private function compute_missing_answers() {
        $s         = $this->schema_opts();
        $queries   = $this->generate_query_set();
        $amenities = strtolower(implode(' ', array_filter((array)($s['amenities'] ?? []))));
        $descr     = strtolower(strip_tags($s['description'] ?? ''));
        $rooms_txt = '';
        foreach ((array)($s['rooms'] ?? []) as $r) $rooms_txt .= strtolower(($r['name'] ?? '') . ' ' . ($r['description'] ?? '')) . ' ';
        $pets_txt  = strtolower($s['pets_allowed'] ?? '');

        $faqs = get_posts(['post_type' => self::CPT, 'posts_per_page' => -1, 'post_status' => 'publish']);
        $faq_txt = '';
        foreach ($faqs as $f) $faq_txt .= strtolower($f->post_title . ' ' . strip_tags($f->post_content)) . ' ';

        $all = $amenities . ' ' . $descr . ' ' . $rooms_txt . ' ' . $faq_txt . ' ' . $pets_txt;

        $covered = []; $missing = [];
        foreach ($queries as $q) {
            $ok = false;
            foreach ($q['keywords'] as $kw) { if (strpos($all, strtolower($kw)) !== false) { $ok = true; break; } }
            $q['covered'] = $ok;
            if ($ok) $covered[] = $q; else $missing[] = $q;
        }

        $total = count($queries);
        $cov   = count($covered);
        $pct   = $total > 0 ? intval(($cov / $total) * 100) : 0;

        $where_map = ['services' => 'Servizi Schema.org', 'audience' => 'Target clienti Schema.org', 'location' => 'Descrizione o FAQ', 'rooms' => 'Camere Schema.org'];
        foreach ($missing as &$m) $m['suggestion'] = 'Aggiungi in: ' . ($where_map[$m['category']] ?? 'Schema.org o FAQ');
        unset($m);

        return ['total' => $total, 'covered' => $cov, 'missing' => count($missing), 'coverage_pct' => $pct, 'missing_queries' => array_slice($missing, 0, 10), 'covered_queries' => $covered];
    }

    private function isi_site_id() {
        $id = get_option(self::ISI_SITE_ID_OPTION);
        if (!$id) {
            $id = wp_generate_uuid4();
            update_option(self::ISI_SITE_ID_OPTION, $id, false);
        }
        // Riallineamento opportunistico all'ID della riga creata dal pannello (max 1 volta ogni 10 min).
        // Cosi OGNI percorso (register, heartbeat, force-heartbeat, permessi) usa l'ID giusto,
        // anche quando il sito e stato aggiunto prima dal pannello con un UUID diverso.
        if (!get_transient('in3pida_site_id_reconciled')) {
            set_transient('in3pida_site_id_reconciled', 1, 10 * MINUTE_IN_SECONDS);
            $reconciled = self::isi_lookup_site_id_by_url();
            if ($reconciled && $reconciled !== $id) {
                update_option(self::ISI_SITE_ID_OPTION, $reconciled, false);
                delete_transient('in3pida_plugin_perms');
                $id = $reconciled;
            }
        }
        return $id;
    }

    // Normalizza un URL per confronti tolleranti: minuscolo, senza schema, senza www, senza slash finale.
    public static function isi_norm_url($u) {
        $u = strtolower(trim((string) $u));
        $u = preg_replace('#^https?://#', '', $u);
        $u = preg_replace('#^www\.#', '', $u);
        return rtrim($u, '/');
    }

    // Cerca su Supabase il site_id della riga che corrisponde all'URL di questo sito,
    // confrontando in modo tollerante (ignora www, slash finale, http/https). Ritorna '' se non trovato.
    public static function isi_lookup_site_id_by_url() {
        $host = self::isi_norm_url(get_site_url());
        if ($host === '') return '';
        $domain = explode('/', $host)[0];
        $resp = wp_remote_get(self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?select=site_id,site_url&site_url=ilike.' . urlencode('%' . $domain . '%'), [
            'timeout' => 8,
            'headers' => ['apikey' => self::ISI_SUPABASE_ANON_KEY, 'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY, 'Accept' => 'application/json'],
        ]);
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) return '';
        $rows = json_decode(wp_remote_retrieve_body($resp), true);
        if (!is_array($rows) || empty($rows)) return '';
        foreach ($rows as $row) {
            if (!empty($row['site_id']) && isset($row['site_url']) && self::isi_norm_url($row['site_url']) === $host) {
                return $row['site_id'];
            }
        }
        return '';
    }

    public function isi_register() {
        // Prima installazione: se la piattaforma ha già una riga per questo sito (creata dall'admin),
        // adotta quel site_id così il PRIMO heartbeat arriva sulla riga giusta invece di restare "Mai".
        $reconciled = self::isi_lookup_site_id_by_url();
        if ($reconciled) update_option(self::ISI_SITE_ID_OPTION, $reconciled, false);
        $site_id = $this->isi_site_id();
        wp_remote_post(self::ISI_SUPABASE_URL . '/rest/v1/isi_sites', [
            'timeout' => 8,
            'blocking' => true,
            'headers' => [
                'apikey' => self::ISI_SUPABASE_ANON_KEY,
                'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                'Content-Type' => 'application/json',
                'Prefer' => 'resolution=merge-duplicates',
            ],
            'body' => wp_json_encode([
                'site_id'        => $site_id,
                'site_url'       => home_url(),
                'site_name'      => get_bloginfo('name'),
                'plugin_version' => self::VERSION,
                'wp_version'     => get_bloginfo('version'),
                'php_version'    => PHP_VERSION,
                'last_heartbeat' => gmdate('c'),
            ]),
        ]);
        delete_transient(self::ISI_PING_TRANSIENT);
    }

    // ── QUERY INTELLIGENCE ────────────────────────────────────────────────────

    private function build_schema_summary_for_ai($o) {
        $parts = [];
        if (!empty($o['name']))             $parts[] = 'Nome: ' . $o['name'];
        if (!empty($o['type']))             $parts[] = 'Tipo struttura: ' . $o['type'];
        if (!empty($o['description']))      $parts[] = 'Descrizione: ' . $o['description'];
        if (!empty($o['city']))             $parts[] = 'Città: ' . $o['city'];
        if (!empty($o['street']))           $parts[] = 'Indirizzo: ' . $o['street'] . ', ' . ($o['city'] ?? '');
        if (!empty($o['telephone']))        $parts[] = 'Telefono: ' . $o['telephone'];
        if (!empty($o['email']))            $parts[] = 'Email: ' . $o['email'];
        if (!empty($o['checkin_time']))     $parts[] = 'Check-in: ' . $o['checkin_time'];
        if (!empty($o['checkout_time']))    $parts[] = 'Check-out: ' . $o['checkout_time'];
        if (!empty($o['pets_allowed']))     $parts[] = 'Animali ammessi: ' . $o['pets_allowed'];
        if (!empty($o['price_range']))      $parts[] = 'Fascia di prezzo: ' . $o['price_range'];
        if (!empty($o['official_rating']))  $parts[] = 'Stelle: ' . $o['official_rating'];
        if (!empty($o['languages']))        $parts[] = 'Lingue parlate: ' . $o['languages'];
        if (!empty($o['nearby_attractions'])) $parts[] = 'Attrazioni vicine: ' . $o['nearby_attractions'];
        if (!empty($o['area_served']))      $parts[] = 'Zona servita: ' . $o['area_served'];
        if (!empty($o['targets']) && is_array($o['targets'])) $parts[] = 'Target clienti: ' . implode(', ', $o['targets']);
        if (!empty($o['amenities']) && is_array($o['amenities'])) $parts[] = 'Servizi: ' . implode(', ', array_slice($o['amenities'], 0, 30));
        if (!empty($o['rooms']) && is_array($o['rooms'])) {
            $rnames = array_filter(array_column($o['rooms'], 'name'));
            if ($rnames) $parts[] = 'Tipologie camere: ' . implode(', ', $rnames);
        }
        if (!empty($o['offers']) && is_array($o['offers'])) {
            $onames = array_filter(array_column($o['offers'], 'name'));
            if ($onames) $parts[] = 'Offerte: ' . implode(', ', $onames);
        }
        return implode("\n", $parts) ?: 'Nessun dato Schema.org disponibile.';
    }

    public function ajax_generate_faq_answer() {
        check_ajax_referer('in3pida_generate_faq', 'nonce');
        if (!current_user_can('manage_options')) wp_die();

        $query   = sanitize_text_field(wp_unslash($_POST['query'] ?? ''));
        $api_key = get_option(self::GEMINI_API_OPTION, '');

        if (!$query) wp_send_json_error(['code' => 'no_query', 'msg' => 'Query mancante']);
        if (!$api_key) wp_send_json_error(['code' => 'no_key', 'msg' => 'Chiave API Gemini non configurata — aggiungila in AI Layer → Attivazione.']);

        $o       = $this->schema_opts();
        $summary = $this->build_schema_summary_for_ai($o);

        $prompt = "Sei un assistente che aiuta hotel italiani a creare FAQ ottimizzate per assistenti AI.\n\n"
                . "Dati dell'hotel:\n{$summary}\n\n"
                . "Domanda da rispondere: {$query}\n\n"
                . "Scrivi una risposta concisa in italiano (2-3 frasi) basata SOLO sui dati forniti sopra. "
                . "Se i dati non contengono informazioni sufficienti, rispondi solo con la parola: DATI_INSUFFICIENTI";

        $url  = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' . urlencode($api_key);
        $resp = wp_remote_post($url, [
            'timeout' => 25,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode([
                'contents'         => [['parts' => [['text' => $prompt]]]],
                'generationConfig' => ['maxOutputTokens' => 300, 'temperature' => 0.3],
            ]),
        ]);

        if (is_wp_error($resp)) {
            wp_send_json_error(['code' => 'api_error', 'msg' => $resp->get_error_message()]);
        }

        $body = json_decode(wp_remote_retrieve_body($resp), true);
        $text = trim($body['candidates'][0]['content']['parts'][0]['text'] ?? '');

        if (!$text || strtoupper(trim($text)) === 'DATI_INSUFFICIENTI') {
            wp_send_json_success(['insufficient' => true]);
            return;
        }

        wp_send_json_success(['answer' => $text]);
    }

    private function query_library() {
        return [
            'famiglie' => [
                'label' => 'Famiglie con bambini',
                'icon'  => '👨‍👩‍👧',
                'queries' => [
                    ['q' => 'hotel con piscina per bambini',        'signals' => ['piscina', 'bambini']],
                    ['q' => 'hotel con camere comunicanti',          'signals' => ['comunicant', 'famiglie', 'family']],
                    ['q' => 'hotel con lettino per neonato',         'signals' => ['lettino', 'neonato', 'culla']],
                    ['q' => 'hotel con animazione per bambini',      'signals' => ['animazione', 'mini club', 'miniclub']],
                    ['q' => 'hotel con parco giochi',                'signals' => ['parco giochi', 'playground', 'giochi']],
                    ['q' => 'hotel family con menù bambini',         'signals' => ['menù bambini', 'menu bambini', 'family']],
                    ['q' => 'hotel con passeggino in prestito',      'signals' => ['passeggino', 'carrozzina']],
                    ['q' => 'hotel adatto a bambini piccoli',        'signals' => ['bambini', 'family', 'famiglie']],
                ],
            ],
            'coppie' => [
                'label' => 'Coppie e romantici',
                'icon'  => '💑',
                'queries' => [
                    ['q' => 'hotel romantico per anniversario',      'signals' => ['anniversario', 'romantico']],
                    ['q' => 'hotel con SPA per coppia',              'signals' => ['spa', 'coppia', 'benessere']],
                    ['q' => 'hotel con jacuzzi in camera',           'signals' => ['jacuzzi', 'vasca idromassaggio', 'idromassaggio']],
                    ['q' => 'pacchetto romantico hotel',             'signals' => ['romantico', 'pacchetto']],
                    ['q' => 'hotel per luna di miele',               'signals' => ['luna di miele', 'honeymoon']],
                    ['q' => 'hotel con cena romantica inclusa',      'signals' => ['cena romantica', 'romantico']],
                    ['q' => 'weekend romantico hotel',               'signals' => ['weekend', 'romantico', 'fuga']],
                ],
            ],
            'business' => [
                'label' => 'Business e lavoro',
                'icon'  => '💼',
                'queries' => [
                    ['q' => 'hotel con sala riunioni e conferenze',  'signals' => ['sala riunioni', 'meeting', 'conferenze', 'business']],
                    ['q' => 'hotel con parcheggio gratuito',         'signals' => ['parcheggio', 'park', 'auto']],
                    ['q' => 'hotel con wifi veloce',                 'signals' => ['wifi', 'internet', 'connessione']],
                    ['q' => 'hotel vicino alla fiera',               'signals' => ['fiera', 'centro congressi', 'business']],
                    ['q' => 'hotel con colazione presto mattina',    'signals' => ['colazione', 'mattina presto', 'early']],
                    ['q' => 'hotel con check-in anticipato',         'signals' => ['check-in', 'anticip', 'early check']],
                    ['q' => 'hotel con scrivania e area lavoro',     'signals' => ['scrivania', 'lavoro', 'business']],
                ],
            ],
            'pet' => [
                'label' => 'Animali domestici',
                'icon'  => '🐾',
                'queries' => [
                    ['q' => 'hotel pet friendly',                    'signals' => ['animali', 'pet', 'cane', 'gatto']],
                    ['q' => 'hotel che accetta cani di taglia grande','signals' => ['cane', 'animali', 'pet friendly', 'taglia']],
                    ['q' => 'hotel con area sgambamento cani',       'signals' => ['area cani', 'sgambamento', 'cane']],
                    ['q' => 'supplemento animali domestici hotel',   'signals' => ['supplemento', 'animali', 'cane', 'pet']],
                    ['q' => 'hotel ammette gatti',                   'signals' => ['gatto', 'animali', 'pet']],
                ],
            ],
            'benessere' => [
                'label' => 'Benessere e SPA',
                'icon'  => '🧘',
                'queries' => [
                    ['q' => 'hotel con SPA e trattamenti',           'signals' => ['spa', 'trattamenti', 'benessere']],
                    ['q' => 'hotel con piscina riscaldata coperta',  'signals' => ['piscina riscaldata', 'piscina coperta']],
                    ['q' => 'hotel con palestra e fitness center',   'signals' => ['palestra', 'fitness', 'gym']],
                    ['q' => 'pacchetto benessere e relax hotel',     'signals' => ['benessere', 'spa', 'wellness', 'pacchetto']],
                    ['q' => 'hotel con massaggi e percorso termale', 'signals' => ['massaggi', 'termale', 'spa']],
                ],
            ],
            'mare' => [
                'label' => 'Mare e spiaggia',
                'icon'  => '🏖️',
                'queries' => [
                    ['q' => 'hotel con accesso diretto alla spiaggia','signals' => ['spiaggia', 'accesso diretto', 'fronte mare']],
                    ['q' => 'hotel con ombrellone e lettini inclusi', 'signals' => ['ombrellone', 'lettini', 'spiaggia']],
                    ['q' => 'hotel con spiaggia privata',            'signals' => ['spiaggia privata']],
                    ['q' => 'hotel con vista mare',                  'signals' => ['vista mare', 'panorama mare']],
                    ['q' => 'hotel vicino al mare per famiglie',     'signals' => ['mare', 'spiaggia', 'famiglie']],
                ],
            ],
            'montagna' => [
                'label' => 'Montagna e natura',
                'icon'  => '🏔️',
                'queries' => [
                    ['q' => 'hotel in montagna con vista panoramica','signals' => ['montagna', 'panorama', 'vista']],
                    ['q' => 'hotel vicino alle piste da sci',        'signals' => ['sci', 'piste', 'neve', 'montagna']],
                    ['q' => 'hotel con noleggio bici e mountain bike','signals' => ['bici', 'noleggio', 'ciclismo', 'mtb']],
                    ['q' => 'hotel con escursioni guidate',          'signals' => ['escursioni', 'trekking', 'natura', 'guide']],
                ],
            ],
            'senior' => [
                'label' => 'Senior e accessibilità',
                'icon'  => '♿',
                'queries' => [
                    ['q' => 'hotel accessibile per persone con disabilità','signals' => ['accessibil', 'disabili', 'mobilità ridotta']],
                    ['q' => 'hotel con ascensore',                   'signals' => ['ascensore', 'lift', 'accessibil']],
                    ['q' => 'hotel con camere al piano terra',       'signals' => ['piano terra', 'ground floor', 'accessibil']],
                    ['q' => 'hotel con menu per celiaci e allergie', 'signals' => ['celiaci', 'allergie', 'dieta', 'senza glutine']],
                    ['q' => 'hotel tranquillo per soggiorni lunghi', 'signals' => ['tranquillo', 'lungo soggiorno', 'settimanale']],
                ],
            ],
        ];
    }

    public function compute_query_coverage() {
        $library = $this->query_library();

        // Filter audience categories based on configured targets
        $s = $this->schema_opts();
        $targets_raw = array_values(array_filter((array)($s['targets'] ?? [])));
        if (!empty($targets_raw)) {
            $target_str = strtolower(implode(' ', $targets_raw));
            $audience_filter = [
                'famiglie'  => strpos($target_str, 'famil') !== false || strpos($target_str, 'bambin') !== false,
                'coppie'    => strpos($target_str, 'coppi') !== false,
                'business'  => strpos($target_str, 'busine') !== false,
                'senior'    => strpos($target_str, 'senior') !== false || strpos($target_str, 'anzian') !== false,
            ];
            foreach ($audience_filter as $cat_key => $show) {
                if (!$show) unset($library[$cat_key]);
            }
        }

        $faqs = get_posts([
            'post_type'      => self::CPT,
            'posts_per_page' => -1,
            'post_status'    => 'publish',
        ]);

        $faq_text = '';
        foreach ($faqs as $faq) {
            $faq_text .= ' ' . strtolower(strip_tags($faq->post_title))
                       . ' ' . strtolower(strip_tags($faq->post_content));
        }

        $total   = 0;
        $covered = 0;
        $results = [];

        foreach ($library as $cat_key => $cat) {
            $cat_results = [];
            foreach ($cat['queries'] as $entry) {
                $total++;
                $is_covered = false;
                foreach ($entry['signals'] as $signal) {
                    if (strpos($faq_text, strtolower($signal)) !== false) {
                        $is_covered = true;
                        break;
                    }
                }
                if ($is_covered) $covered++;
                $cat_results[] = ['q' => $entry['q'], 'covered' => $is_covered, 'signals' => $entry['signals']];
            }
            $results[$cat_key] = [
                'label'   => $cat['label'],
                'icon'    => $cat['icon'],
                'queries' => $cat_results,
            ];
        }

        return [
            'total'      => $total,
            'covered'    => $covered,
            'uncovered'  => $total - $covered,
            'pct'        => $total > 0 ? round($covered / $total * 100) : 0,
            'categories' => $results,
        ];
    }

    public function ajax_create_faq_from_query() {
        check_ajax_referer('in3pida_create_faq', 'nonce');
        if (!current_user_can('manage_options')) wp_die();

        $query   = sanitize_text_field(wp_unslash($_POST['query'] ?? ''));
        $content = wp_kses_post(wp_unslash($_POST['content'] ?? ''));
        $publish = !empty($_POST['publish']) && $content;

        if (!$query) wp_send_json_error('Query mancante');

        $post_id = wp_insert_post([
            'post_type'    => self::CPT,
            'post_title'   => $query,
            'post_status'  => $publish ? 'publish' : 'draft',
            'post_content' => $content,
        ]);

        if (is_wp_error($post_id)) {
            wp_send_json_error($post_id->get_error_message());
        }

        update_post_meta($post_id, '_in3pida_llm_only', '1');

        wp_send_json_success([
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'status'   => $publish ? 'published' : 'draft',
        ]);
    }

    public function query_map_page() {
        if (!current_user_can('manage_options')) return;

        $coverage = $this->compute_query_coverage();
        $pct      = $coverage['pct'];
        $total    = $coverage['total'];
        $covered  = $coverage['covered'];
        $uncov    = $coverage['uncovered'];
        $cats     = $coverage['categories'];

        $pct_color  = $pct >= 70 ? '#0D5F75' : '#0D5F75';
        $pct_bg     = '#fff';
        $nonce      = wp_create_nonce('in3pida_create_faq');
        $gen_nonce  = wp_create_nonce('in3pida_generate_faq');
        $has_apikey = (bool) get_option(self::GEMINI_API_OPTION, '');

        echo '<div class="wrap in3pida-admin in3pida-admin-pro">';
        $this->admin_header('Mappa Query — AI Query Intelligence');
        echo '<div class="in3pida-grid">';

        // KPI top
        echo '<section class="in3pida-card">';
        echo '<h2>🗺️ Copertura query conversazionali</h2>';
        echo '<p class="in3pida-card-desc">Confronta le domande tipiche per tipologia di ospite con le FAQ pubblicate. Scopri quali mancano e creale con un click.</p>';
        echo '<div style="display:flex;align-items:center;gap:28px;padding:16px 0 8px">';
        echo '<div style="font-size:56px;font-weight:800;color:' . $pct_color . '">' . $pct . '<span style="font-size:22px;color:#666b84">/100</span></div>';
        echo '<div style="flex:1">';
        echo '<div style="height:10px;background:#f0f0f4;border-radius:5px"><div style="height:10px;width:' . $pct . '%;background:' . $pct_color . ';border-radius:5px"></div></div>';
        echo '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px">';
        echo '<div style="text-align:center;background:linear-gradient(135deg,#fff 55%,#fdf0f5);border:1.5px solid #0D5F75;border-radius:6px;padding:12px 14px"><div style="font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">QUERY TOTALI</div><div style="font-size:22px;font-weight:700;color:#181834">' . $total . '</div></div>';
        echo '<div style="text-align:center;background:#fff;border:1.5px solid #e4e4ec;border-radius:6px;padding:12px 14px"><div style="font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">COPERTE</div><div style="font-size:22px;font-weight:700;color:#0D5F75">' . $covered . '</div></div>';
        echo '<div style="text-align:center;background:#fff;border:1.5px solid #e4e4ec;border-radius:6px;padding:12px 14px"><div style="font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">SCOPERTE</div><div style="font-size:22px;font-weight:700;color:#b00020">' . $uncov . '</div></div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</section>';

        // Categorie
        foreach ($cats as $cat_key => $cat) {
            $cat_total   = count($cat['queries']);
            $cat_covered = count(array_filter($cat['queries'], fn($q) => $q['covered']));
            $cat_pct     = $cat_total > 0 ? round($cat_covered / $cat_total * 100) : 0;
            $cat_color   = $cat_pct >= 70 ? '#0D5F75' : '#0D5F75';

            echo '<section class="in3pida-card">';
            echo '<h2 style="display:flex;align-items:center;justify-content:space-between;gap:12px">';
            echo '<span>' . esc_html($cat['icon']) . ' ' . esc_html($cat['label']) . '</span>';
            echo '<span style="border:1px solid #0D5F75;color:#0D5F75;font-weight:700;font-size:11px;padding:2px 8px;border-radius:4px">' . $cat_covered . '/' . $cat_total . ' coperte</span>';
            echo '</h2>';
            echo '<div style="height:4px;background:#f0f0f4;border-radius:2px;margin-bottom:16px"><div style="height:4px;width:' . $cat_pct . '%;background:' . $cat_color . ';border-radius:2px"></div></div>';
            echo '<div class="in3pida-report-list">';
            foreach ($cat['queries'] as $entry) {
                $is_covered = $entry['covered'];
                echo '<div class="in3pida-repeat-box query-row" style="padding:12px 14px">';
                echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px">';
                echo '<div style="display:flex;align-items:center;gap:10px;flex:1">';
                echo '<span style="font-size:14px;color:' . ($is_covered ? '#0D5F75' : '#b00020') . ';font-weight:800">' . ($is_covered ? '✓' : '✗') . '</span>';
                echo '<span style="font-size:13px">' . esc_html($entry['q']) . '</span>';
                echo '</div>';
                if (!$is_covered) {
                    echo '<button class="btn-genera-faq" data-query="' . esc_attr($entry['q']) . '" data-nonce="' . esc_attr($nonce) . '" data-gen-nonce="' . esc_attr($gen_nonce) . '" style="flex-shrink:0;font-size:12px;padding:5px 14px;background:#0D5F75;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:600">✨ Genera risposta</button>';
                }
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
            echo '</section>';
        }

        echo '</div></div>';

        $ai_layer_url = esc_js(admin_url('admin.php?page=in3pida-ai-layer'));
        echo '<script>
(function(){

function saveFaq(query, content, publish, nonce, container) {
    const fd = new FormData();
    fd.append("action",  "in3pida_create_faq_from_query");
    fd.append("nonce",   nonce);
    fd.append("query",   query);
    fd.append("content", content);
    if (publish) fd.append("publish", "1");
    fetch(ajaxurl, { method:"POST", body:fd })
        .then(r=>r.json())
        .then(r=>{
            if (r.success) {
                const label = r.data.status === "published" ? "✓ FAQ pubblicata" : "✓ Bozza salvata";
                const color = r.data.status === "published" ? "#0D5F75" : "#0D5F75";
                container.innerHTML = `<span style="color:${color};font-weight:700;font-size:13px">${label}</span> <a href="${r.data.edit_url}" target="_blank" style="font-size:12px;color:#0D5F75;text-decoration:underline">Modifica</a>`;
            } else {
                container.innerHTML = `<span style="color:#b00020;font-size:13px">✗ Errore nel salvataggio</span>`;
            }
        })
        .catch(()=>{ container.innerHTML = `<span style="color:#b00020;font-size:13px">✗ Errore</span>`; });
}

document.addEventListener("click", function(e) {
    const btn = e.target.closest(".btn-genera-faq");
    if (!btn) return;

    const row      = btn.closest(".query-row");
    const query    = btn.dataset.query;
    const nonce    = btn.dataset.nonce;
    const genNonce = btn.dataset.genNonce;

    btn.disabled = true;
    btn.textContent = "⏳ Generazione...";

    const fd = new FormData();
    fd.append("action", "in3pida_generate_faq_answer");
    fd.append("nonce",  genNonce);
    fd.append("query",  query);

    fetch(ajaxurl, { method:"POST", body:fd })
        .then(r=>r.json())
        .then(r=>{
            btn.style.display = "none";

            if (!r.success) {
                const code = r.data && r.data.code;
                if (code === "no_key") {
                    const msg = document.createElement("div");
                    msg.style.cssText = "margin-top:8px;font-size:12px;color:#0D5F75;background:#e8f2f5;border:1px solid #ead0dc;padding:10px 14px;border-radius:6px";
                    msg.innerHTML = `<strong>Chiave API Gemini non configurata.</strong> Vai su <strong>aistudio.google.com</strong> → "Get API key" (gratuita), poi <a href="' . $ai_layer_url . '" style="color:#0D5F75;font-weight:700;text-decoration:underline">aggiungila in AI Layer → Attivazione</a>.`;
                    row.appendChild(msg);
                } else {
                    const msg = document.createElement("div");
                    msg.style.cssText = "margin-top:8px;font-size:12px;color:#b00020";
                    msg.textContent = "✗ Errore: " + (r.data && r.data.msg ? r.data.msg : "riprova");
                    row.appendChild(msg);
                }
                return;
            }

            if (r.data.insufficient) {
                const msg = document.createElement("div");
                msg.style.cssText = "margin-top:8px;font-size:12px;color:#0D5F75;background:#e8f2f5;border:1px solid #ead0dc;padding:10px 14px;border-radius:6px;display:flex;align-items:center;justify-content:space-between;gap:10px";
                msg.innerHTML = `<span><strong>Dati insufficienti in Schema.org</strong> — compila la scheda struttura e riprova, oppure scrivi la risposta manualmente.</span>`;
                const manBtn = document.createElement("button");
                manBtn.textContent = "+ Crea bozza";
                manBtn.style.cssText = "flex-shrink:0;font-size:12px;padding:5px 12px;background:#fff;color:#0D5F75;border:1px solid #0D5F75;border-radius:14px;cursor:pointer;font-weight:600";
                manBtn.onclick = () => { saveFaq(query, "", false, nonce, msg); };
                msg.appendChild(manBtn);
                row.appendChild(msg);
                return;
            }

            // Mostra preview risposta generata
            const preview = document.createElement("div");
            preview.style.cssText = "margin-top:10px";
            preview.innerHTML = `
                <div style="font-size:11px;color:#666b84;font-weight:700;letter-spacing:.04em;margin-bottom:6px">RISPOSTA GENERATA — modifica se necessario</div>
                <textarea style="width:100%;min-height:80px;border:1px solid #e4e4ec;border-radius:6px;padding:10px;font-size:13px;resize:vertical;background:#fff">${r.data.answer.replace(/</g,"&lt;")}</textarea>
                <div style="margin-top:8px;display:flex;gap:8px" class="faq-action-bar">
                    <button class="btn-pubblica" style="font-size:12px;padding:6px 16px;background:#0D5F75;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:700">✓ Pubblica FAQ</button>
                    <button class="btn-bozza" style="font-size:12px;padding:6px 16px;background:#fff;color:#0D5F75;border:1px solid #e4e4ec;border-radius:6px;cursor:pointer;font-weight:600">Salva bozza</button>
                </div>`;

            const actionBar = preview.querySelector(".faq-action-bar");
            preview.querySelector(".btn-pubblica").onclick = () => {
                const answer = preview.querySelector("textarea").value;
                actionBar.innerHTML = "<span style=\'color:#666b84;font-size:13px\'>⏳ Salvataggio...</span>";
                saveFaq(query, answer, true, nonce, actionBar);
            };
            preview.querySelector(".btn-bozza").onclick = () => {
                const answer = preview.querySelector("textarea").value;
                actionBar.innerHTML = "<span style=\'color:#666b84;font-size:13px\'>⏳ Salvataggio...</span>";
                saveFaq(query, answer, false, nonce, actionBar);
            };

            row.appendChild(preview);
        })
        .catch(()=>{
            btn.style.display = "";
            btn.textContent = "✗ Errore — riprova";
            btn.disabled = false;
        });
});

})();
</script>';
    }

    // ── END QUERY INTELLIGENCE ────────────────────────────────────────────────

    private function isi_sync_config_from_supabase() {
        $site_id = $this->isi_site_id();
        if ( ! $site_id ) return;
        $resp = wp_remote_get(
            self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode( $site_id ) . '&select=hotel_profile',
            [
                'timeout' => 5,
                'headers' => [
                    'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                    'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                ],
            ]
        );
        if ( is_wp_error( $resp ) ) return;
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $hp   = $body[0]['hotel_profile'] ?? null;
        if ( ! is_array( $hp ) ) return;

        // ── Sync LLM layer enable/disable ──────────────────────────
        $cfg = $hp['isi_config'] ?? [];
        if ( is_array( $cfg ) && isset( $cfg['llm_layer'] ) ) {
            $llm = get_option( self::LLM_OPTION, [ 'enabled' => 0 ] );
            if ( ! is_array( $llm ) ) $llm = [ 'enabled' => 0 ];
            $llm['enabled'] = $cfg['llm_layer'] ? 1 : 0;
            update_option( self::LLM_OPTION, $llm );
            $this->_llm_opts_cache = null;
        }

        // ── Sync schema.org basic fields from ISI hotel_profile ────
        // hotel_profile uses Italian field names; map them to schema WP option keys
        $schema_map = [
            'nome_hotel'     => 'name',
            'tipo_struttura' => 'type',
            'descrizione'    => 'description',
            'telefono'       => 'telephone',
            'email'          => 'email',
            'sito_web'       => 'url',
            'via'            => 'street',
            'citta'          => 'city',
            'cap'            => 'postal_code',
            'regione'        => 'region',
            'paese'          => 'country',
            'checkin_dalle'  => 'checkin_time',
            'checkout_dalle' => 'checkout_time',
            'stelle'         => 'official_rating',
            'latitudine'     => 'latitude',
            'longitudine'    => 'longitude',
            'prezzo_medio'   => 'price_range',
        ];
        $current_schema = get_option( self::SCHEMA_OPTION, [] );
        if ( ! is_array( $current_schema ) ) $current_schema = [];
        $changed = false;
        foreach ( $schema_map as $hp_field => $schema_field ) {
            if ( ! empty( $hp[ $hp_field ] ) ) {
                $current_schema[ $schema_field ] = sanitize_text_field( (string) $hp[ $hp_field ] );
                $changed = true;
            }
        }
        // Servizi (lista, campo "servizi" separato da virgola) -> amenities Schema.org
        if ( ! empty( $hp['servizi'] ) ) {
            $amen = is_array( $hp['servizi'] ) ? $hp['servizi'] : array_map( 'trim', explode( ',', (string) $hp['servizi'] ) );
            $amen = array_values( array_filter( array_map( 'sanitize_text_field', $amen ) ) );
            if ( $amen ) { $current_schema['amenities'] = $amen; $changed = true; }
        }
        // Camere (campo "camere") -> rooms Schema.org
        if ( ! empty( $hp['camere'] ) && is_array( $hp['camere'] ) ) {
            $rooms = array_values( array_filter( (array) $hp['camere'] ) );
            if ( $rooms ) { $current_schema['rooms'] = $rooms; $changed = true; }
        }
        if ( $changed ) {
            update_option( self::SCHEMA_OPTION, $current_schema );
            $this->_schema_opts_cache = null;
        }
    }

    // ── LIGHTWEIGHT PING ─────────────────────────────────────────────────────
    // Runs on every page load (init), rate-limited to once every 4 hours via transient.
    // Sends only last_heartbeat — no GEO computation, no schema build.
    public function isi_maybe_ping() {
        if ( defined('DOING_CRON') && DOING_CRON ) return;
        if ( get_transient( self::ISI_PING_TRANSIENT ) ) return;
        $site_id = $this->isi_site_id();
        if ( ! $site_id ) return;
        set_transient( self::ISI_PING_TRANSIENT, 1, 4 * HOUR_IN_SECONDS );
        wp_remote_request(
            self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode( $site_id ),
            [
                'method'   => 'PATCH',
                'timeout'  => 3,
                'blocking' => false,
                'headers'  => [
                    'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                    'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                    'Content-Type'  => 'application/json',
                ],
                'body' => wp_json_encode( [
                    'last_heartbeat' => gmdate( 'c' ),
                    'plugin_version' => self::VERSION,
                ] ),
            ]
        );
    }

    public function isi_heartbeat() {
        $this->isi_sync_config_from_supabase();
        $site_id         = $this->isi_site_id();
        $chunks          = get_transient(self::CHUNKS_TRANSIENT);
        $chunk_avg       = ($chunks !== false && $chunks) ? round(array_sum(array_column($chunks, 'citation_score')) / count($chunks)) : null;
        $citation_blocks = get_transient(self::CITATION_TRANSIENT);
        $c_scores        = ($citation_blocks !== false && $citation_blocks) ? array_column($citation_blocks, 'citability_score') : [];
        $citation_avg    = $c_scores ? round(array_sum($c_scores) / count($c_scores)) : null;
        $graph           = get_transient(self::ENTITY_GRAPH_TRANSIENT);
        $entity_nodes    = ($graph !== false && !empty($graph['nodes'])) ? count($graph['nodes']) : null;
        $layer_raw       = get_transient(self::LLM_CACHE_TRANSIENT);
        $layer           = ($layer_raw !== false && $layer_raw) ? $layer_raw : [];
        $completeness    = $this->compute_completeness();
        $freshness       = $this->compute_freshness();
        $mad             = $this->compute_missing_answers();
        $enabled         = $this->retrieval_is_enabled();
        $qmap            = $this->compute_query_coverage();
        $existing_qm     = $this->isi_fetch_current_query_map($site_id);
        $existing_sh     = $this->isi_fetch_current_score_history($site_id);
        $query_map       = $this->isi_build_query_map($existing_qm);
        $existing_geo    = $this->isi_fetch_current_geo_scores($site_id);
        $schema_has_name = !empty($this->schema_opts()['name']);

        $new_geo = [
            'chunk_avg'          => $chunk_avg,
            'citation_avg'       => $citation_avg,
            'entity_nodes'       => $entity_nodes,
            'ai_readiness'       => intval($layer['ai_readiness_score']['score'] ?? 0) ?: null,
            'answer_extraction'  => intval($layer['answer_extraction']['score'] ?? 0) ?: null,
            'quality_safety'     => intval($layer['quality_safety']['score'] ?? 0) ?: null,
            'ai_visibility'      => intval($layer['ai_visibility_monitor']['score'] ?? 0) ?: null,
            'entity_authority'   => intval($layer['entity_authority']['score'] ?? 0) ?: null,
            'completeness_score' => $schema_has_name ? $completeness['score'] : null,
            'checklist'          => $schema_has_name ? $completeness['checklist'] : null,
            'has_ai_profile'     => $enabled,
            'coverage_pct'       => $mad['coverage_pct'],
            'missing_answers'    => $mad['missing'],
            'missing_queries'    => array_column($mad['missing_queries'], 'query'),
            'freshness_alerts'   => $freshness['alerts'],
            'days_since_faq'     => $freshness['days_since_faq'],
            'days_since_schema'  => $freshness['days_since_schema'],
            'query_map_pct'      => $qmap['pct'],
            'query_uncovered'    => $qmap['uncovered'],
            'query_total'        => $qmap['total'],
        ];
        $geo_scores = $existing_geo;
        foreach ($new_geo as $k => $v) { if ($v !== null) $geo_scores[$k] = $v; }

        $sc_detection = $this->isi_detect_search_console();

        $patch_body = [
            'plugin_version' => self::VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'last_heartbeat' => gmdate('c'),
            'faq_data'       => $this->isi_build_faq_payload($query_map, $existing_sh !== null ? $this->isi_append_today_score($existing_sh, $geo_scores) : null),
            'geo_scores'     => $geo_scores,
            'sc_detection'   => $sc_detection,
        ];
        if ($schema_has_name) $patch_body['schema_data'] = $this->isi_build_schema_payload();

        $response = wp_remote_request(self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id), [
            'method'   => 'PATCH',
            'timeout'  => 10,
            'blocking' => true,
            'headers'  => [
                'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode($patch_body),
        ]);
        if (is_wp_error($response)) {
            update_option('in3pida_heartbeat_error', $response->get_error_message(), false);
        } elseif (wp_remote_retrieve_response_code($response) >= 400) {
            update_option('in3pida_heartbeat_error', 'HTTP ' . wp_remote_retrieve_response_code($response), false);
        } else {
            delete_option('in3pida_heartbeat_error');
        }
    }

    public function isi_pse_auto() {
        $site_id = $this->isi_site_id();
        if (!$site_id) return;
        $mad = $this->compute_missing_answers();
        $missing = array_slice($mad['missing_queries'] ?? [], 0, 3);
        if (empty($missing)) return;
        $schema  = $this->schema_opts();
        $faqs    = $this->llm_get_faq_items();
        $hotel_context = [
            'name'        => $schema['name'] ?? '',
            'city'        => $schema['city'] ?? '',
            'type'        => $schema['type'] ?? 'Hotel',
            'amenities'   => array_slice((array)($schema['amenities'] ?? []), 0, 10),
            'targets'     => array_slice((array)($schema['targets'] ?? []), 0, 5),
            'description' => substr((string)($schema['description'] ?? ''), 0, 500),
            'faqs'        => array_slice(array_map(function($f){ return ['q'=>$f['question'],'a'=>substr($f['answer'],0,300)]; }, $faqs), 0, 5),
        ];
        foreach ($missing as $q) {
            $query_str = is_array($q) ? ($q['query'] ?? '') : $q;
            if (!$query_str) continue;
            wp_remote_post(self::ISI_SUPABASE_URL . '/functions/v1/pse-query', [
                'method'   => 'POST',
                'timeout'  => 30,
                'blocking' => false,
                'headers'  => [
                    'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                    'Content-Type'  => 'application/json',
                ],
                'body' => wp_json_encode([
                    'site_id'       => $site_id,
                    'query'         => $query_str,
                    'hotel_context' => $hotel_context,
                ]),
            ]);
        }
    }

    // ── ISI REMOTE UPDATE ─────────────────────────────────────────────────────

    public function isi_register_update_route() {
        // Handle CORS preflight before WordPress routing
        if (
            isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS' &&
            isset($_SERVER['REQUEST_URI']) && (
                strpos($_SERVER['REQUEST_URI'], '/in3pida/v1/update') !== false ||
                strpos($_SERVER['REQUEST_URI'], '/in3pida/v1/schema') !== false ||
                strpos($_SERVER['REQUEST_URI'], '/in3pida/v1/faq') !== false ||
                strpos($_SERVER['REQUEST_URI'], '/in3pida/v1/create-faq-page') !== false
            )
        ) {
            header('Access-Control-Allow-Origin: *');
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
            header('Access-Control-Allow-Headers: Content-Type');
            http_response_code(200);
            exit;
        }

        register_rest_route('in3pida/v1', '/site-id', [
            'methods'             => 'GET',
            'callback'            => function() { return rest_ensure_response(['site_id' => $this->isi_site_id()]); },
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => function() {
                return rest_ensure_response(['active' => (bool) get_option('in3pida_isi_active', true)]);
            },
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/status', [
            'methods'             => 'POST',
            'callback'            => [$this, 'isi_rest_set_status'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/update', [
            'methods'             => 'POST',
            'callback'            => [$this, 'isi_rest_trigger_update'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/force-heartbeat', [
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'isi_rest_force_heartbeat'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'OPTIONS',
                'callback'            => function() {
                    $r = new WP_REST_Response( null, 204 );
                    $r->header( 'Access-Control-Allow-Origin',  '*' );
                    $r->header( 'Access-Control-Allow-Methods', 'POST, OPTIONS' );
                    $r->header( 'Access-Control-Allow-Headers', 'Content-Type' );
                    return $r;
                },
                'permission_callback' => '__return_true',
            ],
        ]);

        register_rest_route('in3pida/v1', '/schema', [
            'methods'             => ['GET', 'POST'],
            'callback'            => [$this, 'isi_rest_schema'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/faq', [
            'methods'             => ['GET', 'POST'],
            'callback'            => [$this, 'isi_rest_faq_manage'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/create-faq-page', [
            'methods'             => 'POST',
            'callback'            => [$this, 'isi_rest_create_faq_page'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/faq-settings', [
            'methods'             => ['POST', 'OPTIONS'],
            'callback'            => [$this, 'isi_rest_save_faq_settings'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/faq-settings', [
            'methods'             => 'GET',
            'callback'            => [$this, 'isi_rest_get_faq_settings'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('in3pida/v1', '/faq-page-status', [
            'methods'             => ['POST', 'OPTIONS', 'GET'],
            'callback'            => [$this, 'isi_rest_faq_page_status'],
            'permission_callback' => '__return_true',
        ]);

        add_filter('rest_pre_serve_request', function ($served, $result, $request) {
            if (strpos($request->get_route(), '/in3pida/v1/') !== false) {
                header('Access-Control-Allow-Origin: *');
                header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
                header('Access-Control-Allow-Headers: Content-Type');
            }
            return $served;
        }, 10, 3);
    }

    public function isi_rest_trigger_update(\WP_REST_Request $request) {
        // Reset OPcache ora (codice vecchio) così il cron installerà il nuovo codice con cache pulita
        if (function_exists('opcache_reset')) { opcache_reset(); }
        $secret       = $request->get_param('secret');
        $download_url = $request->get_param('download_url');
        $new_version  = $request->get_param('version');
        $site_id      = $this->isi_site_id();

        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }
        if (empty($download_url)) {
            return new \WP_Error('missing_url', 'download_url mancante', ['status' => 400]);
        }

        $current = get_plugin_data(__FILE__, false, false)['Version'] ?? '0';
        if ($new_version && !version_compare($new_version, $current, '>')) {
            return rest_ensure_response(['ok' => true, 'skipped' => true, 'current' => $current]);
        }

        // Risponde subito — aggiornamento in background via WP Cron
        update_option('in3pida_pending_update', ['url' => $download_url, 'version' => $new_version], false);
        wp_schedule_single_event(time(), 'in3pida_run_pending_update');
        wp_remote_get(home_url('/'), ['blocking' => false, 'timeout' => 1]);

        return rest_ensure_response(['ok' => true, 'scheduled' => true, 'version' => $new_version]);
    }

    public function run_pending_update() {
        $pending = get_option('in3pida_pending_update');
        if (empty($pending['url'])) return;
        $new_version = $pending['version'] ?? '';
        delete_option('in3pida_pending_update');
        $this->isi_install_from_url($pending['url']);

        // Heartbeat subito dopo l'aggiornamento.
        $this->isi_sync_config_from_supabase();
        $site_id         = $this->isi_site_id();
        $chunks          = get_transient(self::CHUNKS_TRANSIENT);
        $chunk_avg       = ($chunks !== false && $chunks) ? round(array_sum(array_column($chunks, 'citation_score')) / count($chunks)) : null;
        $citation_blocks = get_transient(self::CITATION_TRANSIENT);
        $c_scores        = ($citation_blocks !== false && $citation_blocks) ? array_column($citation_blocks, 'citability_score') : [];
        $citation_avg    = $c_scores ? round(array_sum($c_scores) / count($c_scores)) : null;
        $graph           = get_transient(self::ENTITY_GRAPH_TRANSIENT);
        $entity_nodes    = ($graph !== false && !empty($graph['nodes'])) ? count($graph['nodes']) : null;
        $layer_raw       = get_transient(self::LLM_CACHE_TRANSIENT);
        $layer           = ($layer_raw !== false && $layer_raw) ? $layer_raw : [];
        $completeness    = $this->compute_completeness();
        $freshness       = $this->compute_freshness();
        $mad             = $this->compute_missing_answers();
        $enabled         = $this->retrieval_is_enabled();
        $qmap            = $this->compute_query_coverage();
        $existing_qm     = $this->isi_fetch_current_query_map($site_id);
        $existing_sh     = $this->isi_fetch_current_score_history($site_id);
        $query_map       = $this->isi_build_query_map($existing_qm);
        $existing_geo    = $this->isi_fetch_current_geo_scores($site_id);
        $schema_has_name = !empty($this->schema_opts()['name']);

        $new_geo = [
            'chunk_avg'          => $chunk_avg,
            'citation_avg'       => $citation_avg,
            'entity_nodes'       => $entity_nodes,
            'ai_readiness'       => intval($layer['ai_readiness_score']['score'] ?? 0) ?: null,
            'answer_extraction'  => intval($layer['answer_extraction']['score'] ?? 0) ?: null,
            'quality_safety'     => intval($layer['quality_safety']['score'] ?? 0) ?: null,
            'ai_visibility'      => intval($layer['ai_visibility_monitor']['score'] ?? 0) ?: null,
            'entity_authority'   => intval($layer['entity_authority']['score'] ?? 0) ?: null,
            'completeness_score' => $schema_has_name ? $completeness['score'] : null,
            'checklist'          => $schema_has_name ? $completeness['checklist'] : null,
            'has_ai_profile'     => $enabled,
            'coverage_pct'       => $mad['coverage_pct'],
            'missing_answers'    => $mad['missing'],
            'missing_queries'    => array_column($mad['missing_queries'], 'query'),
            'freshness_alerts'   => $freshness['alerts'],
            'days_since_faq'     => $freshness['days_since_faq'],
            'days_since_schema'  => $freshness['days_since_schema'],
            'query_map_pct'      => $qmap['pct'],
            'query_uncovered'    => $qmap['uncovered'],
            'query_total'        => $qmap['total'],
        ];
        $geo_scores = $existing_geo;
        foreach ($new_geo as $k => $v) { if ($v !== null) $geo_scores[$k] = $v; }

        $patch_body = [
            'plugin_version' => $new_version ?: self::VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'last_heartbeat' => gmdate('c'),
            'faq_data'       => $this->isi_build_faq_payload($query_map, $existing_sh !== null ? $this->isi_append_today_score($existing_sh, $geo_scores) : null),
            'geo_scores'     => $geo_scores,
        ];
        if ($schema_has_name) $patch_body['schema_data'] = $this->isi_build_schema_payload();

        wp_remote_request(self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id), [
            'method'   => 'PATCH',
            'timeout'  => 10,
            'blocking' => true,
            'headers'  => [
                'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode($patch_body),
        ]);

        // Self-ping per svegliare WP cron sul sito aggiornato.
        wp_remote_get(home_url('/'), ['blocking' => false, 'timeout' => 1]);
    }

    public function isi_rest_set_status(\WP_REST_Request $request) {
        $secret  = $request->get_param('secret');
        $site_id = $this->isi_site_id();
        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }
        $active = (bool) $request->get_param('active');
        update_option('in3pida_isi_active', $active, false);
        return rest_ensure_response(['ok' => true, 'active' => $active]);
    }

    private function isi_install_from_url($url) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/class-automatic-upgrader-skin.php';
        WP_Filesystem();
        $upgrader = new \Plugin_Upgrader(new \Automatic_Upgrader_Skin());
        $upgrader->run([
            'package'                    => $url,
            'destination'                => WP_PLUGIN_DIR,
            'clear_destination'          => true,
            'clear_working'              => true,
            'abort_if_destination_check' => false,
            'hook_extra'                 => ['plugin' => plugin_basename(__FILE__), 'type' => 'plugin', 'action' => 'update'],
        ]);
        // Invalida OPcache per il file del plugin appena aggiornato
        $plugin_file = WP_PLUGIN_DIR . '/' . plugin_basename(__FILE__);
        if (function_exists('opcache_invalidate')) {
            opcache_invalidate($plugin_file, true);
        }
        if (function_exists('opcache_reset')) {
            opcache_reset();
        }
        // Pulisci cache WP comuni dopo aggiornamento plugin
        if (function_exists('wp_cache_flush')) { wp_cache_flush(); }
        if (function_exists('rocket_clean_domain')) { rocket_clean_domain(); }
        if (function_exists('w3tc_pgcache_flush')) { w3tc_pgcache_flush(); }
        if (function_exists('wpfc_clear_all_cache')) { wpfc_clear_all_cache(); }
        if (function_exists('sg_cachepress_purge_cache')) { sg_cachepress_purge_cache(); }
        delete_transient('in3pida_faq_page_cache');
    }

    public function isi_rest_force_heartbeat() {
        $this->isi_sync_config_from_supabase();
        delete_transient('in3pida_plugin_perms'); // Sincronizza forza il refresh immediato dei permessi
        $site_id         = $this->isi_site_id();
        $chunks          = get_transient(self::CHUNKS_TRANSIENT);
        $chunk_avg       = ($chunks !== false && $chunks) ? round(array_sum(array_column($chunks, 'citation_score')) / count($chunks)) : null;
        $citation_blocks = get_transient(self::CITATION_TRANSIENT);
        $c_scores        = ($citation_blocks !== false && $citation_blocks) ? array_column($citation_blocks, 'citability_score') : [];
        $citation_avg    = $c_scores ? round(array_sum($c_scores) / count($c_scores)) : null;
        $graph           = get_transient(self::ENTITY_GRAPH_TRANSIENT);
        $entity_nodes    = ($graph !== false && !empty($graph['nodes'])) ? count($graph['nodes']) : null;
        $layer_raw       = get_transient(self::LLM_CACHE_TRANSIENT);
        $layer           = ($layer_raw !== false && $layer_raw) ? $layer_raw : [];
        $completeness    = $this->compute_completeness();
        $freshness       = $this->compute_freshness();
        $mad             = $this->compute_missing_answers();
        $enabled         = $this->retrieval_is_enabled();
        $qmap            = $this->compute_query_coverage();
        $existing_qm     = $this->isi_fetch_current_query_map($site_id);
        $existing_sh     = $this->isi_fetch_current_score_history($site_id);
        $query_map       = $this->isi_build_query_map($existing_qm);
        $existing_geo    = $this->isi_fetch_current_geo_scores($site_id);
        $schema_has_name = !empty($this->schema_opts()['name']);

        $new_geo = [
            'chunk_avg'          => $chunk_avg,
            'citation_avg'       => $citation_avg,
            'entity_nodes'       => $entity_nodes,
            'ai_readiness'       => intval($layer['ai_readiness_score']['score'] ?? 0) ?: null,
            'answer_extraction'  => intval($layer['answer_extraction']['score'] ?? 0) ?: null,
            'quality_safety'     => intval($layer['quality_safety']['score'] ?? 0) ?: null,
            'ai_visibility'      => intval($layer['ai_visibility_monitor']['score'] ?? 0) ?: null,
            'entity_authority'   => intval($layer['entity_authority']['score'] ?? 0) ?: null,
            'completeness_score' => $schema_has_name ? $completeness['score'] : null,
            'checklist'          => $schema_has_name ? $completeness['checklist'] : null,
            'has_ai_profile'     => $enabled,
            'coverage_pct'       => $mad['coverage_pct'],
            'missing_answers'    => $mad['missing'],
            'missing_queries'    => array_column($mad['missing_queries'], 'query'),
            'freshness_alerts'   => $freshness['alerts'],
            'days_since_faq'     => $freshness['days_since_faq'],
            'days_since_schema'  => $freshness['days_since_schema'],
            'query_map_pct'      => $qmap['pct'],
            'query_uncovered'    => $qmap['uncovered'],
            'query_total'        => $qmap['total'],
        ];
        $geo_scores = $existing_geo;
        foreach ($new_geo as $k => $v) { if ($v !== null) $geo_scores[$k] = $v; }

        $patch_body = [
            'plugin_version' => self::VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'last_heartbeat' => gmdate('c'),
            'faq_data'       => $this->isi_build_faq_payload($query_map, $existing_sh !== null ? $this->isi_append_today_score($existing_sh, $geo_scores) : null),
            'geo_scores'     => $geo_scores,
        ];
        if ($schema_has_name) $patch_body['schema_data'] = $this->isi_build_schema_payload();

        $resp = wp_remote_request(self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id), [
            'method'   => 'PATCH',
            'timeout'  => 10,
            'blocking' => true,
            'headers'  => [
                'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode($patch_body),
        ]);

        // Return full payload — dashboard saves to Supabase via authenticated session (anon RLS blocks plugin writes)
        $payload = [
            'ok'             => true,
            'plugin_version' => self::VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'geo_scores'     => $geo_scores,
            'faq_data'       => $this->isi_build_faq_payload($query_map, $existing_sh !== null ? $this->isi_append_today_score($existing_sh, $geo_scores) : null),
        ];
        if ($schema_has_name) $payload['schema_data'] = $this->isi_build_schema_payload();
        $response = rest_ensure_response($payload);
        $response->header('Access-Control-Allow-Origin', '*');
        $response->header('Access-Control-Allow-Methods', 'POST, OPTIONS');
        $response->header('Access-Control-Allow-Headers', 'Content-Type');
        return $response;
    }

    // ── END ISI REMOTE UPDATE ─────────────────────────────────────────────────

    // ── ISI VISIBILITY MONITOR ────────────────────────────────────────────────

    public function isi_monitor_build_profile() {
        $schema = $this->schema_opts();
        $faqs   = get_posts(['post_type' => self::CPT, 'posts_per_page' => -1, 'post_status' => 'publish']);
        $chunks = get_transient(self::CHUNKS_TRANSIENT);
        $graph  = get_transient(self::ENTITY_GRAPH_TRANSIENT);

        return [
            'site_id'        => $this->isi_site_id(),
            'site_url'       => get_site_url(),
            'plugin_version' => self::VERSION,
            'language'       => get_bloginfo('language'),
            'profile'        => [
                'name'               => $schema['name'] ?? '',
                'type'               => $schema['type'] ?? 'Hotel',
                'description'        => $schema['description'] ?? '',
                'slogan'             => $schema['slogan'] ?? '',
                'street'             => $schema['street'] ?? '',
                'city'               => $schema['city'] ?? '',
                'region'             => $schema['region'] ?? '',
                'postal_code'        => $schema['postal_code'] ?? '',
                'country'            => $schema['country'] ?? 'IT',
                'telephone'          => $schema['telephone'] ?? '',
                'email'              => $schema['email'] ?? '',
                'checkin_time'       => $schema['checkin_time'] ?? '',
                'checkout_time'      => $schema['checkout_time'] ?? '',
                'pets_allowed'       => $schema['pets_allowed'] ?? '',
                'price_range'        => $schema['price_range'] ?? '',
                'languages'          => $schema['languages'] ?? '',
                'area_served'        => $schema['area_served'] ?? '',
                'nearby_attractions' => $schema['nearby_attractions'] ?? '',
                'targets'            => array_values(array_filter((array)($schema['targets'] ?? []))),
                'knows_about'        => array_values(array_filter((array)($schema['knows_about'] ?? []))),
                'keywords'           => $schema['keywords'] ?? '',
                'amenities'          => array_values(array_filter(array_slice((array)($schema['amenities'] ?? []), 0, 30))),
                'rooms'              => array_map(fn($r) => ['name' => $r['name'] ?? '', 'capacity' => $r['capacity'] ?? '', 'bed_type' => $r['bed_type'] ?? ''], array_slice((array)($schema['rooms'] ?? []), 0, 10)),
                'offers'             => array_map(fn($o) => ['name' => $o['name'] ?? '', 'price' => $o['price'] ?? '', 'url' => $o['url'] ?? ''], array_slice((array)($schema['offers'] ?? []), 0, 10)),
                'rating_value'       => $schema['rating_value'] ?? '',
                'review_count'       => $schema['review_count'] ?? '',
                'google_rating'      => $schema['google_rating'] ?? '',
                'tripadvisor_rating' => $schema['tripadvisor_rating'] ?? '',
                'booking_rating'     => $schema['booking_rating'] ?? '',
            ],
            'faq_count'    => count($faqs),
            'faq_titles'   => array_map(fn($f) => $f->post_title, $faqs),
            'chunk_count'  => $chunks ? count($chunks) : 0,
            'entity_nodes' => $graph ? count($graph['nodes'] ?? []) : 0,
            'qmap_pct'     => $this->compute_query_coverage()['pct'],
        ];
    }

    public function isi_monitor_sync() {
        $endpoint = get_option(self::ISI_MONITOR_ENDPOINT_OPTION, '');
        $token    = get_option(self::ISI_MONITOR_TOKEN_OPTION, '');

        if (!$endpoint || !$token) {
            $this->monitor_log('skip', 'Endpoint o token non configurati');
            return;
        }

        $resp = wp_remote_post(esc_url_raw($endpoint), [
            'timeout' => 20,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ],
            'body' => wp_json_encode($this->isi_monitor_build_profile()),
        ]);

        if (is_wp_error($resp)) {
            $this->monitor_log('error', $resp->get_error_message());
            return;
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = json_decode(wp_remote_retrieve_body($resp), true);

        if ($code !== 200) {
            $msg = is_array($body) ? ($body['error'] ?? '') : wp_remote_retrieve_body($resp);
            $this->monitor_log('error', 'HTTP ' . $code . ($msg ? ': ' . $msg : ''));
            return;
        }

        if (!is_array($body)) {
            $this->monitor_log('error', 'Risposta non valida (atteso JSON)');
            return;
        }

        update_option(self::ISI_MONITOR_CACHE_OPTION, $body, false);
        update_option(self::ISI_MONITOR_LAST_SYNC_OPTION, time(), false);

        // Merge suggestions preserving applied/dismissed state
        $new_sug  = (array)($body['suggestions'] ?? []);
        $existing = get_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, []);
        $ex_by_id = [];
        foreach ((array)$existing as $s) {
            if (!empty($s['id'])) $ex_by_id[$s['id']] = $s;
        }
        $merged = [];
        foreach ($new_sug as $s) {
            $id = $s['id'] ?? '';
            if ($id && isset($ex_by_id[$id])) {
                $s['status']  = $ex_by_id[$id]['status'] ?? 'pending';
                $s['post_id'] = $ex_by_id[$id]['post_id'] ?? null;
            } else {
                $s['status'] = 'pending';
            }
            $merged[] = $s;
        }
        update_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, $merged, false);

        $this->monitor_log('ok', 'Sync completato — ' . count($merged) . ' suggerimenti ricevuti');
    }

    private function monitor_log($type, $message) {
        $log = get_option(self::ISI_MONITOR_LOG_OPTION, []);
        if (!is_array($log)) $log = [];
        array_unshift($log, ['time' => time(), 'type' => $type, 'msg' => $message]);
        update_option(self::ISI_MONITOR_LOG_OPTION, array_slice($log, 0, 10), false);
    }

    public function ajax_monitor_sync() {
        check_ajax_referer('in3pida_monitor_sync', 'nonce');
        if (!current_user_can('manage_options')) wp_die();
        $this->isi_monitor_sync();
        $log  = get_option(self::ISI_MONITOR_LOG_OPTION, []);
        $last = $log[0] ?? null;
        if ($last && $last['type'] === 'error') {
            wp_send_json_error($last['msg']);
        }
        wp_send_json_success(['ts' => get_option(self::ISI_MONITOR_LAST_SYNC_OPTION, 0)]);
    }

    public function ajax_monitor_apply_suggestion() {
        check_ajax_referer('in3pida_monitor_suggestion', 'nonce');
        if (!current_user_can('manage_options')) wp_die();

        $id     = sanitize_text_field(wp_unslash($_POST['suggestion_id'] ?? ''));
        $action = sanitize_text_field(wp_unslash($_POST['action_type'] ?? ''));

        if (!$id) wp_send_json_error('ID mancante');

        $suggestions = get_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, []);
        $found_idx   = null;
        foreach ((array)$suggestions as $i => $s) {
            if (($s['id'] ?? '') === $id) { $found_idx = $i; break; }
        }

        if ($found_idx === null) wp_send_json_error('Suggerimento non trovato');

        $sug     = $suggestions[$found_idx];
        $post_id = null;

        if ($action === 'faq') {
            $post_id = wp_insert_post([
                'post_type'    => self::CPT,
                'post_title'   => $sug['title'] ?? 'Nuova FAQ',
                'post_content' => $sug['content'] ?? '',
                'post_status'  => 'draft',
            ]);
            if (!is_wp_error($post_id)) {
                update_post_meta($post_id, '_in3pida_llm_only', '1');
                $suggestions[$found_idx]['status']  = 'applied';
                $suggestions[$found_idx]['post_id'] = $post_id;
            }
        } elseif ($action === 'page') {
            $post_id = wp_insert_post([
                'post_type'    => 'page',
                'post_title'   => $sug['title'] ?? 'Nuova pagina',
                'post_content' => $sug['content'] ?? '',
                'post_status'  => 'draft',
            ]);
            if (!is_wp_error($post_id)) {
                $suggestions[$found_idx]['status']  = 'applied';
                $suggestions[$found_idx]['post_id'] = $post_id;
            }
        }

        update_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, $suggestions, false);

        $edit_url = ($post_id && !is_wp_error($post_id)) ? get_edit_post_link($post_id, 'raw') : null;
        wp_send_json_success(['post_id' => $post_id, 'edit_url' => $edit_url, 'status' => 'applied']);
    }

    public function ajax_monitor_dismiss_suggestion() {
        check_ajax_referer('in3pida_monitor_suggestion', 'nonce');
        if (!current_user_can('manage_options')) wp_die();

        $id      = sanitize_text_field(wp_unslash($_POST['suggestion_id'] ?? ''));
        $restore = !empty($_POST['restore']);

        if (!$id) wp_send_json_error('ID mancante');

        $suggestions = get_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, []);
        foreach ($suggestions as &$s) {
            if (($s['id'] ?? '') === $id) {
                $s['status'] = $restore ? 'pending' : 'dismissed';
                break;
            }
        }
        unset($s);

        update_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, $suggestions, false);
        wp_send_json_success(['status' => $restore ? 'pending' : 'dismissed']);
    }

    public function monitor_page_content() {
        if (!current_user_can('manage_options')) return;

        $endpoint    = get_option(self::ISI_MONITOR_ENDPOINT_OPTION, '');
        $token       = get_option(self::ISI_MONITOR_TOKEN_OPTION, '');
        $cache       = get_option(self::ISI_MONITOR_CACHE_OPTION, null);
        $last_sync   = get_option(self::ISI_MONITOR_LAST_SYNC_OPTION, 0);
        $log         = get_option(self::ISI_MONITOR_LOG_OPTION, []);
        $suggestions = get_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, []);
        $nonce_sync  = wp_create_nonce('in3pida_monitor_sync');
        $nonce_sug   = wp_create_nonce('in3pida_monitor_suggestion');

        $is_configured = $endpoint && $token;
        $has_data      = $cache && is_array($cache);
        $last_log      = is_array($log) ? ($log[0] ?? null) : null;
        $last_error    = ($last_log && $last_log['type'] === 'error') ? $last_log['msg'] : null;

        // ── Configurazione + stato ──────────────────────────────────
        echo '<section class="in3pida-card">';
        echo '<h2>👁️ Visibilità AI — Monitor iSI</h2>';
        echo '<p class="in3pida-card-desc">Il plugin invia ogni giorno il profilo della struttura a isi.in3pida.it e riceve dati di visibilità AI, query monitorate e suggerimenti operativi.</p>';
        echo '<form method="post" action="options.php" style="margin-top:8px">';
        settings_fields('in3pida_api_settings_group');
        echo '<div class="in3pida-fields">';
        echo '<div class="in3pida-field"><label>Endpoint iSI Monitor</label>';
        echo '<input type="url" name="' . esc_attr(self::ISI_MONITOR_ENDPOINT_OPTION) . '" value="' . esc_attr($endpoint) . '" style="max-width:500px;width:100%" placeholder="https://isi.in3pida.it/api/monitor/sync">';
        echo '</div>';
        echo '<div class="in3pida-field"><label>Token autenticazione</label>';
        echo '<input type="password" name="' . esc_attr(self::ISI_MONITOR_TOKEN_OPTION) . '" value="' . esc_attr($token) . '" style="max-width:360px" placeholder="Bearer token">';
        echo '</div>';
        echo '</div>';
        echo '<div class="in3pida-savebar">';
        submit_button('Salva impostazioni', 'primary in3pida-save', 'submit', false);
        if ($is_configured) {
            if ($last_error) {
                echo '<span style="background:#e8f2f5;border:1px solid #ead0dc;color:#b00020;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;margin-left:12px">⚠️ Errore ultimo sync</span>';
            } elseif ($last_sync) {
                echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;margin-left:12px">✓ Connesso</span>';
            } else {
                echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;margin-left:12px">Non ancora sincronizzato</span>';
            }
        }
        if ($is_configured) {
            echo '<button id="in3pida-monitor-sync-btn" type="button" class="button" data-nonce="' . esc_attr($nonce_sync) . '" style="background:#fbf4f7;border-color:#e4e4ec;color:#0D5F75;font-weight:700">⚡ Sincronizza ora</button>';
            echo '<span id="in3pida-monitor-sync-msg" style="font-size:12px;display:none"></span>';
        }
        echo '</div>';
        echo '</form>';
        if ($is_configured && is_array($log) && $log) {
            echo '<details style="margin-top:8px"><summary style="font-size:12px;color:#666b84;cursor:pointer">Log ultimi ' . count($log) . ' eventi</summary>';
            echo '<div style="margin-top:6px;font-size:11px;font-family:monospace;background:#fafafa;padding:8px 12px;border-radius:6px;border:1px solid #e4e4ec">';
            foreach ($log as $entry) {
                $lc = $entry['type'] === 'error' ? '#b00020' : ($entry['type'] === 'ok' ? '#0D5F75' : '#666b84');
                echo '<div style="color:' . $lc . ';padding:2px 0">[' . esc_html(date_i18n('d/m H:i', $entry['time'])) . '] ' . esc_html($entry['msg']) . '</div>';
            }
            echo '</div></details>';
        }
        echo '</section>';

        if (!$is_configured || !$has_data) {
            if (!$is_configured) {
                echo '<section class="in3pida-card"><div class="in3pida-note">Inserisci endpoint e token sopra per attivare il monitor.</div></section>';
            } else {
                echo '<section class="in3pida-card"><div class="in3pida-note">Nessun dato ricevuto ancora. Premi <strong>⚡ Sincronizza ora</strong> oppure attendi il cron giornaliero.</div></section>';
            }
            $this->monitor_page_inline_js($nonce_sync, $nonce_sug);
            return;
        }

        // ── Riepilogo + query + competitor + cluster + suggerimenti ──
        $vis_score   = intval($cache['visibility_score'] ?? 0);
        $total_q     = intval($cache['monitored_queries'] ?? 0);
        $positive_q  = (array)($cache['positive_queries'] ?? []);
        $negative_q  = (array)($cache['negative_queries'] ?? []);
        $competitors = (array)($cache['competitors'] ?? []);
        $clusters    = (array)($cache['semantic_clusters'] ?? []);
        $last_upd    = $cache['last_updated'] ?? '';
        $vis_color   = $vis_score >= 70 ? '#0D5F75' : '#0D5F75';

        echo '<section class="in3pida-card">';
        echo '<h2>📊 Riepilogo visibilità AI</h2>';
        if ($last_upd) echo '<p class="in3pida-card-desc">Dati aggiornati al ' . esc_html(date_i18n('d/m/Y H:i', strtotime($last_upd))) . '</p>';
        echo '<div style="display:flex;align-items:center;gap:28px;padding:8px 0">';
        echo '<div style="font-size:48px;font-weight:800;color:' . $vis_color . '">' . $vis_score . '<span style="font-size:20px;color:#666b84">/100</span></div>';
        echo '<div style="flex:1"><div style="height:8px;background:#f0f0f4;border-radius:4px"><div style="height:8px;width:' . min($vis_score,100) . '%;background:' . $vis_color . ';border-radius:4px"></div></div>';
        echo '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:12px">';
        echo '<div style="text-align:center;background:#fbf4f7;border-radius:8px;padding:10px"><div style="font-size:20px;font-weight:800;color:#171b33">' . $total_q . '</div><div style="font-size:10px;color:#666b84;font-weight:600">MONITORATE</div></div>';
        echo '<div style="text-align:center;background:#fafafa;border-radius:8px;padding:10px"><div style="font-size:20px;font-weight:800;color:#0D5F75">' . count($positive_q) . '</div><div style="font-size:10px;color:#666b84;font-weight:600">PRESENZE</div></div>';
        echo '<div style="text-align:center;background:#fff;border:1.5px solid #e4e4ec;border-radius:6px;padding:10px 14px"><div style="font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">ASSENZE</div><div style="font-size:20px;font-weight:700;color:#b00020">' . count($negative_q) . '</div><div style="font-size:10px;color:#666b84;font-weight:600">ASSENZE</div></div>';
        echo '</div></div></div>';
        echo '</section>';

        if ($positive_q || $negative_q) {
            echo '<section class="in3pida-card"><h2>🔍 Query monitorate</h2>';
            echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">';
            echo '<div><div style="font-size:11px;font-weight:700;color:#0D5F75;letter-spacing:.5px;margin-bottom:8px">PRESENZE (' . count($positive_q) . ')</div><ul style="margin:0;padding:0;list-style:none">';
            foreach ($positive_q as $q) echo '<li style="font-size:13px;padding:4px 0;border-bottom:1px solid #e4e4ec"><span style="color:#0D5F75;margin-right:6px">✓</span>' . esc_html($q) . '</li>';
            echo '</ul></div>';
            echo '<div><div style="font-size:11px;font-weight:700;color:#0D5F75;letter-spacing:.5px;margin-bottom:8px">ASSENZE (' . count($negative_q) . ')</div><ul style="margin:0;padding:0;list-style:none">';
            foreach ($negative_q as $q) echo '<li style="font-size:13px;padding:4px 0;border-bottom:1px solid #e4e4ec"><span style="color:#0D5F75;margin-right:6px">✗</span>' . esc_html($q) . '</li>';
            echo '</ul></div>';
            echo '</div></section>';
        }

        if ($competitors) {
            echo '<section class="in3pida-card"><h2>🏨 Competitor rilevati</h2>';
            echo '<p class="in3pida-card-desc">Strutture citate dagli assistenti AI nelle query in cui l\'hotel non compare.</p>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px">';
            foreach ($competitors as $c) {
                $cn = is_array($c) ? ($c['name'] ?? '') : $c;
                $cm = is_array($c) ? intval($c['mentions'] ?? 0) : 0;
                echo '<div style="background:#fafafa;border:1px solid #e4e4ec;border-radius:8px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">';
                echo '<span style="font-size:13px;font-weight:600;color:#171b33">' . esc_html($cn) . '</span>';
                if ($cm) echo '<span style="font-size:11px;font-weight:700;color:#0D5F75;background:#e8f2f5;padding:2px 7px;border-radius:10px">' . $cm . 'x</span>';
                echo '</div>';
            }
            echo '</div></section>';
        }

        if ($clusters) {
            echo '<section class="in3pida-card"><h2>🕸️ Cluster semantici</h2>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px">';
            foreach ($clusters as $cl) {
                $clabel = is_array($cl) ? ($cl['name'] ?? '') : $cl;
                $cscore = is_array($cl) ? intval($cl['score'] ?? 0) : 0;
                $cst    = is_array($cl) ? ($cl['status'] ?? ($cscore >= 60 ? 'strong' : 'weak')) : 'unknown';
                $strong = $cst === 'strong' || $cscore >= 60;
                $cbg = '#fff'; $cbc = $strong ? '#0D5F75' : '#e4e4ec'; $cc = $strong ? '#0D5F75' : '#0D5F75';
                echo '<div style="background:' . $cbg . ';border:1px solid ' . $cbc . ';border-radius:8px;padding:8px 12px">';
                echo '<div style="font-size:12px;font-weight:700;color:' . $cc . ';margin-bottom:4px">' . ($strong ? '💪' : '⚠️') . ' ' . esc_html($clabel) . '</div>';
                if ($cscore) echo '<div style="height:3px;background:#f0f0f4;border-radius:2px"><div style="height:3px;width:' . min($cscore,100) . '%;background:' . $cc . ';border-radius:2px"></div></div>';
                echo '</div>';
            }
            echo '</div></section>';
        }

        if (is_array($suggestions) && $suggestions) {
            $pending = count(array_filter($suggestions, fn($s) => ($s['status'] ?? 'pending') === 'pending'));
            $applied = count(array_filter($suggestions, fn($s) => ($s['status'] ?? '') === 'applied'));
            echo '<section class="in3pida-card"><h2>💡 Suggerimenti operativi</h2>';
            echo '<p class="in3pida-card-desc">Azioni consigliate da isi.in3pida.it per migliorare la visibilità AI.</p>';
            echo '<div style="display:flex;gap:10px;margin-bottom:14px">';
            echo '<span style="background:#e8f2f5;border:1px solid #ead0dc;color:#0D5F75;font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px">Da fare: ' . $pending . '</span>';
            echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px">Applicati: ' . $applied . '</span>';
            echo '</div><div id="in3pida-suggestions-list">';
            foreach ($suggestions as $sug) {
                $sid  = esc_attr($sug['id'] ?? ''); $st = $sug['status'] ?? 'pending';
                $sp   = $sug['priority'] ?? 'medium'; $sty = in_array($sug['type'] ?? '', ['page'], true) ? 'page' : 'faq';
                $pc   = $sp === 'high' ? '#0D5F75' : ($sp === 'medium' ? '#0D5F75' : '#666b84');
                $pbg  = $sp === 'high' ? '#e8f2f5' : ($sp === 'medium' ? '#fafafa' : '#fafafa');
                $pbc  = $sp === 'high' ? '#e4e4ec' : ($sp === 'medium' ? '#e4e4ec' : '#e4e4ec');
                $opa  = $st !== 'pending' ? 'opacity:.55;' : '';
                echo '<div id="sug-row-' . $sid . '" style="border:1px solid ' . $pbc . ';background:' . $pbg . ';border-radius:8px;padding:12px 14px;margin-bottom:8px;' . $opa . 'display:flex;justify-content:space-between;align-items:center;gap:12px">';
                echo '<div><div style="font-size:10px;font-weight:700;color:' . $pc . ';text-transform:uppercase;margin-bottom:4px">' . esc_html($sug['type'] ?? 'faq') . ' · ' . esc_html($sp) . '</div>';
                echo '<div style="font-size:13px;font-weight:700;color:#171b33">' . esc_html($sug['title'] ?? '') . '</div>';
                if (!empty($sug['description'])) echo '<div style="font-size:12px;color:#4b4d68;margin-top:2px">' . esc_html($sug['description']) . '</div>';
                echo '</div><div id="sug-actions-' . $sid . '" style="display:flex;flex-direction:column;gap:5px;min-width:150px;align-items:flex-end">';
                if ($st === 'pending') {
                    echo '<button class="button button-primary in3pida-sug-action" data-id="' . $sid . '" data-action="' . $sty . '" data-nonce="' . esc_attr($nonce_sug) . '" style="background:#0D5F75;border-color:#0a4d60;font-size:11px;padding:3px 10px">' . ($sty === 'page' ? '📄 Crea pagina' : '📝 Crea FAQ') . '</button>';
                    echo '<button class="button in3pida-sug-dismiss" data-id="' . $sid . '" data-nonce="' . esc_attr($nonce_sug) . '" style="font-size:11px;padding:2px 8px;color:#666b84">Ignora</button>';
                } elseif ($st === 'applied') {
                    echo '<span style="font-size:12px;color:#0D5F75;font-weight:700">✓ Applicato</span>';
                    $ep = intval($sug['post_id'] ?? 0); $eu = $ep ? get_edit_post_link($ep, 'raw') : null;
                    if ($eu) echo '<a href="' . esc_url($eu) . '" class="button" style="font-size:11px;padding:2px 8px" target="_blank">Apri bozza</a>';
                } elseif ($st === 'dismissed') {
                    echo '<span style="font-size:12px;color:#666b84">Ignorato</span>';
                    echo '<button class="button in3pida-sug-restore" data-id="' . $sid . '" data-nonce="' . esc_attr($nonce_sug) . '" style="font-size:11px;padding:2px 8px">Ripristina</button>';
                }
                echo '</div></div>';
            }
            echo '</div></section>';
        }

        $this->monitor_page_inline_js($nonce_sync, $nonce_sug);
    }

    public function monitor_page() {
        if (!current_user_can('manage_options')) return;

        $endpoint    = get_option(self::ISI_MONITOR_ENDPOINT_OPTION, '');
        $token       = get_option(self::ISI_MONITOR_TOKEN_OPTION, '');
        $cache       = get_option(self::ISI_MONITOR_CACHE_OPTION, null);
        $last_sync   = get_option(self::ISI_MONITOR_LAST_SYNC_OPTION, 0);
        $log         = get_option(self::ISI_MONITOR_LOG_OPTION, []);
        $suggestions = get_option(self::ISI_MONITOR_SUGGESTIONS_OPTION, []);
        $nonce_sync  = wp_create_nonce('in3pida_monitor_sync');
        $nonce_sug   = wp_create_nonce('in3pida_monitor_suggestion');

        $is_configured = $endpoint && $token;
        $has_data      = $cache && is_array($cache);
        $last_log      = is_array($log) ? ($log[0] ?? null) : null;
        $last_error    = ($last_log && $last_log['type'] === 'error') ? $last_log['msg'] : null;

        echo '<div class="wrap in3pida-admin in3pida-admin-pro">';
        $this->admin_header('Visibilità AI — Monitor iSI');
        echo '<div class="in3pida-grid">';

        // ── Configurazione ──────────────────────────────────────────
        echo '<section class="in3pida-card">';
        echo '<h2>🔌 Connessione con iSI</h2>';
        echo '<p class="in3pida-card-desc">Configura l\'endpoint di isi.in3pida.it e il token di accesso. Il plugin invia automaticamente il profilo dell\'hotel ogni giorno e riceve dati di visibilità AI, query monitorate e suggerimenti operativi.</p>';
        echo '<form method="post" action="options.php" style="margin-top:8px">';
        settings_fields('in3pida_api_settings_group');
        echo '<div class="in3pida-fields">';
        echo '<div class="in3pida-field"><label>Endpoint iSI Monitor</label>';
        echo '<input type="url" name="' . esc_attr(self::ISI_MONITOR_ENDPOINT_OPTION) . '" value="' . esc_attr($endpoint) . '" style="max-width:500px;width:100%" placeholder="https://isi.in3pida.it/api/monitor/sync">';
        echo '</div>';
        echo '<div class="in3pida-field"><label>Token autenticazione</label>';
        echo '<input type="password" name="' . esc_attr(self::ISI_MONITOR_TOKEN_OPTION) . '" value="' . esc_attr($token) . '" style="max-width:360px" placeholder="Bearer token">';
        echo '</div>';
        echo '</div>';
        echo '<div class="in3pida-savebar">';
        submit_button('Salva impostazioni', 'primary in3pida-save', 'submit', false);
        if ($is_configured) {
            if ($last_error) {
                echo '<span style="background:#e8f2f5;border:1px solid #ead0dc;color:#b00020;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;margin-left:12px">⚠️ Errore ultimo sync</span>';
            } elseif ($last_sync) {
                echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;margin-left:12px">✓ Connesso</span>';
            } else {
                echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:4px 12px;border-radius:20px;margin-left:12px">Non ancora sincronizzato</span>';
            }
        }
        echo '</div>';
        echo '</form>';
        echo '</section>';

        if (!$is_configured) {
            echo '<section class="in3pida-card"><div class="in3pida-note">Inserisci endpoint e token sopra per attivare il monitor. Il plugin invierà automaticamente il profilo dell\'hotel ogni giorno e riceverà dati di visibilità AI, query monitorate e suggerimenti operativi.</div></section>';
            $this->monitor_page_inline_js($nonce_sync, $nonce_sug);
            echo '</div></div>';
            return;
        }

        // ── Stato sync ──────────────────────────────────────────────
        echo '<section class="in3pida-card">';
        echo '<h2>🔄 Sincronizzazione</h2>';
        echo '<div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">';
        echo '<div>';
        if ($last_sync) {
            echo '<div style="font-size:13px;color:#666b84">Ultimo sync: <strong style="color:#171b33">' . esc_html(date_i18n('d/m/Y H:i', $last_sync)) . '</strong></div>';
        } else {
            echo '<div style="font-size:13px;color:#666b84">Nessun sync effettuato</div>';
        }
        if ($last_error) echo '<div style="font-size:12px;color:#b00020;margin-top:4px">⚠️ ' . esc_html($last_error) . '</div>';
        echo '</div>';
        echo '<button id="in3pida-monitor-sync-btn" class="button button-primary" data-nonce="' . esc_attr($nonce_sync) . '" style="background:#0D5F75;border-color:#0a4d60">⚡ Sincronizza ora</button>';
        echo '<span id="in3pida-monitor-sync-msg" style="font-size:12px;display:none"></span>';
        echo '</div>';
        if (is_array($log) && $log) {
            echo '<details style="margin-top:12px"><summary style="font-size:12px;color:#666b84;cursor:pointer">Log ultimi ' . count($log) . ' eventi</summary>';
            echo '<div style="margin-top:8px;font-size:11px;font-family:monospace;background:#fafafa;padding:8px 12px;border-radius:6px;border:1px solid #e4e4ec">';
            foreach ($log as $entry) {
                $lcolor = $entry['type'] === 'error' ? '#b00020' : ($entry['type'] === 'ok' ? '#0D5F75' : '#666b84');
                echo '<div style="color:' . $lcolor . ';padding:2px 0">[' . esc_html(date_i18n('d/m H:i', $entry['time'])) . '] ' . esc_html($entry['msg']) . '</div>';
            }
            echo '</div></details>';
        }
        echo '</section>';

        if (!$has_data) {
            echo '<section class="in3pida-card"><div class="in3pida-note">Nessun dato ricevuto ancora. Premi <strong>⚡ Sincronizza ora</strong> oppure attendi il cron giornaliero. I dati appariranno qui dopo il primo sync completato con successo.</div></section>';
            $this->monitor_page_inline_js($nonce_sync, $nonce_sug);
            echo '</div></div>';
            return;
        }

        // ── Riepilogo visibilità ─────────────────────────────────────
        $vis_score   = intval($cache['visibility_score'] ?? 0);
        $total_q     = intval($cache['monitored_queries'] ?? 0);
        $positive_q  = (array)($cache['positive_queries'] ?? []);
        $negative_q  = (array)($cache['negative_queries'] ?? []);
        $competitors = (array)($cache['competitors'] ?? []);
        $clusters    = (array)($cache['semantic_clusters'] ?? []);
        $last_upd    = $cache['last_updated'] ?? '';

        $vis_color = $vis_score >= 70 ? '#0D5F75' : '#0D5F75';
        $vis_bg    = $vis_score >= 70 ? '#e8f2f5' : '#e8f2f5';

        echo '<section class="in3pida-card">';
        echo '<h2>📊 Riepilogo visibilità AI</h2>';
        if ($last_upd) echo '<p class="in3pida-card-desc">Dati aggiornati al ' . esc_html(date_i18n('d/m/Y H:i', strtotime($last_upd))) . '</p>';
        echo '<div style="display:flex;align-items:center;gap:28px;padding:16px 0 8px">';
        echo '<div style="font-size:56px;font-weight:800;color:' . $vis_color . '">' . $vis_score . '<span style="font-size:22px;color:#666b84">/100</span></div>';
        echo '<div style="flex:1">';
        echo '<div style="height:10px;background:#f0f0f4;border-radius:5px"><div style="height:10px;width:' . min($vis_score, 100) . '%;background:' . $vis_color . ';border-radius:5px"></div></div>';
        echo '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px">';
        echo '<div style="text-align:center;background:#fbf4f7;border-radius:8px;padding:12px"><div style="font-size:24px;font-weight:800;color:#171b33">' . $total_q . '</div><div style="font-size:11px;color:#666b84;font-weight:600">QUERY MONITORATE</div></div>';
        echo '<div style="text-align:center;background:#fafafa;border-radius:8px;padding:12px"><div style="font-size:24px;font-weight:800;color:#0D5F75">' . count($positive_q) . '</div><div style="font-size:11px;color:#666b84;font-weight:600">PRESENZE</div></div>';
        echo '<div style="text-align:center;background:#fff;border:1.5px solid #e4e4ec;border-radius:6px;padding:12px 14px"><div style="font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">ASSENZE</div><div style="font-size:22px;font-weight:700;color:#b00020">' . count($negative_q) . '</div><div style="font-size:11px;color:#666b84;font-weight:600">ASSENZE</div></div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</section>';

        // ── Query monitorate ─────────────────────────────────────────
        if ($positive_q || $negative_q) {
            echo '<section class="in3pida-card">';
            echo '<h2>🔍 Query monitorate</h2>';
            echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">';
            echo '<div>';
            echo '<div style="font-size:11px;font-weight:700;color:#0D5F75;letter-spacing:.5px;margin-bottom:8px">PRESENZE (' . count($positive_q) . ')</div>';
            if ($positive_q) {
                echo '<ul style="margin:0;padding:0;list-style:none">';
                foreach ($positive_q as $q) {
                    echo '<li style="font-size:13px;color:#171b33;padding:5px 0;border-bottom:1px solid #e4e4ec"><span style="color:#0D5F75;margin-right:6px">✓</span>' . esc_html($q) . '</li>';
                }
                echo '</ul>';
            } else {
                echo '<div style="font-size:12px;color:#666b84">Nessuna presenza registrata</div>';
            }
            echo '</div>';
            echo '<div>';
            echo '<div style="font-size:11px;font-weight:700;color:#0D5F75;letter-spacing:.5px;margin-bottom:8px">ASSENZE (' . count($negative_q) . ')</div>';
            if ($negative_q) {
                echo '<ul style="margin:0;padding:0;list-style:none">';
                foreach ($negative_q as $q) {
                    echo '<li style="font-size:13px;color:#171b33;padding:5px 0;border-bottom:1px solid #e4e4ec"><span style="color:#0D5F75;margin-right:6px">✗</span>' . esc_html($q) . '</li>';
                }
                echo '</ul>';
            } else {
                echo '<div style="font-size:12px;color:#666b84">Nessuna assenza registrata</div>';
            }
            echo '</div>';
            echo '</div>';
            echo '</section>';
        }

        // ── Competitor ───────────────────────────────────────────────
        if ($competitors) {
            echo '<section class="in3pida-card">';
            echo '<h2>🏨 Competitor rilevati</h2>';
            echo '<p class="in3pida-card-desc">Strutture citate dagli assistenti AI nelle query in cui l\'hotel non compare.</p>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-top:8px">';
            foreach ($competitors as $c) {
                $cname     = is_array($c) ? ($c['name'] ?? '') : $c;
                $cmentions = is_array($c) ? intval($c['mentions'] ?? 0) : 0;
                echo '<div style="background:#fafafa;border:1px solid #e4e4ec;border-radius:8px;padding:10px 14px;display:flex;justify-content:space-between;align-items:center">';
                echo '<span style="font-size:13px;font-weight:600;color:#171b33">' . esc_html($cname) . '</span>';
                if ($cmentions) echo '<span style="font-size:11px;font-weight:700;color:#0D5F75;background:#e8f2f5;padding:2px 8px;border-radius:10px">' . $cmentions . 'x</span>';
                echo '</div>';
            }
            echo '</div>';
            echo '</section>';
        }

        // ── Cluster semantici ─────────────────────────────────────────
        if ($clusters) {
            echo '<section class="in3pida-card">';
            echo '<h2>🕸️ Cluster semantici</h2>';
            echo '<p class="in3pida-card-desc">Aree tematiche in cui la struttura risulta forte o debole nei risultati AI.</p>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-top:8px">';
            foreach ($clusters as $cl) {
                $clabel    = is_array($cl) ? ($cl['name'] ?? '') : $cl;
                $cscore    = is_array($cl) ? intval($cl['score'] ?? 0) : 0;
                $cstatus   = is_array($cl) ? ($cl['status'] ?? ($cscore >= 60 ? 'strong' : 'weak')) : 'unknown';
                $is_strong = $cstatus === 'strong' || $cscore >= 60;
                $cbg       = '#fff';
                $cbc       = $is_strong ? '#0D5F75' : '#e4e4ec';
                $ccolor    = $is_strong ? '#0D5F75' : '#0D5F75';
                $cicon     = $is_strong ? '💪' : '⚠️';
                echo '<div style="background:' . $cbg . ';border:1px solid ' . $cbc . ';border-radius:8px;padding:10px 14px">';
                echo '<div style="font-size:12px;font-weight:700;color:' . $ccolor . ';margin-bottom:6px">' . $cicon . ' ' . esc_html($clabel) . '</div>';
                if ($cscore) {
                    echo '<div style="height:4px;background:#f0f0f4;border-radius:2px"><div style="height:4px;width:' . min($cscore, 100) . '%;background:' . $ccolor . ';border-radius:2px"></div></div>';
                    echo '<div style="font-size:11px;color:#666b84;margin-top:4px">' . $cscore . '/100</div>';
                }
                echo '</div>';
            }
            echo '</div>';
            echo '</section>';
        }

        // ── Suggerimenti ─────────────────────────────────────────────
        if (is_array($suggestions) && $suggestions) {
            $pending_count   = count(array_filter($suggestions, fn($s) => ($s['status'] ?? 'pending') === 'pending'));
            $applied_count   = count(array_filter($suggestions, fn($s) => ($s['status'] ?? '') === 'applied'));
            $dismissed_count = count(array_filter($suggestions, fn($s) => ($s['status'] ?? '') === 'dismissed'));

            echo '<section class="in3pida-card">';
            echo '<h2>💡 Suggerimenti operativi</h2>';
            echo '<p class="in3pida-card-desc">Azioni consigliate da isi.in3pida.it per migliorare la visibilità AI. Crea contenuti in bozza con un click.</p>';
            echo '<div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap">';
            echo '<span style="background:#e8f2f5;border:1px solid #ead0dc;color:#0D5F75;font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px">Da fare: ' . $pending_count . '</span>';
            echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px">Applicati: ' . $applied_count . '</span>';
            if ($dismissed_count) {
                echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px">Ignorati: ' . $dismissed_count . '</span>';
            }
            echo '</div>';

            echo '<div id="in3pida-suggestions-list">';
            foreach ($suggestions as $sug) {
                $sug_id     = esc_attr($sug['id'] ?? '');
                $sug_title  = $sug['title'] ?? '—';
                $sug_desc   = $sug['description'] ?? '';
                $sug_type   = $sug['type'] ?? 'faq';
                $sug_status = $sug['status'] ?? 'pending';
                $sug_prio   = $sug['priority'] ?? 'medium';
                $sug_post   = intval($sug['post_id'] ?? 0);

                $prio_color = $sug_prio === 'high' ? '#0D5F75' : ($sug_prio === 'medium' ? '#0D5F75' : '#666b84');
                $prio_bg    = $sug_prio === 'high' ? '#e8f2f5' : ($sug_prio === 'medium' ? '#fafafa' : '#fafafa');
                $prio_bc    = $sug_prio === 'high' ? '#e4e4ec' : ($sug_prio === 'medium' ? '#e4e4ec' : '#e4e4ec');
                $card_style = $sug_status !== 'pending' ? 'opacity:.55;' : '';

                echo '<div id="sug-row-' . $sug_id . '" style="border:1px solid ' . $prio_bc . ';background:' . $prio_bg . ';border-radius:8px;padding:14px 16px;margin-bottom:10px;' . $card_style . '">';
                echo '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">';
                echo '<div style="flex:1">';
                echo '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">';
                echo '<span style="background:#fafafa;border:1px solid #e4e4ec;color:#666b84;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;text-transform:uppercase">' . esc_html($sug_type) . '</span>';
                echo '<span style="background:' . $prio_bg . ';border:1px solid ' . $prio_bc . ';color:' . $prio_color . ';font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;text-transform:uppercase">' . esc_html($sug_prio) . '</span>';
                echo '</div>';
                echo '<div style="font-size:14px;font-weight:700;color:#171b33;margin-bottom:4px">' . esc_html($sug_title) . '</div>';
                if ($sug_desc) echo '<div style="font-size:12px;color:#4b4d68">' . esc_html($sug_desc) . '</div>';
                echo '</div>';
                echo '<div style="display:flex;flex-direction:column;gap:6px;min-width:164px;align-items:flex-end" id="sug-actions-' . $sug_id . '">';
                if ($sug_status === 'pending') {
                    $action_type = in_array($sug_type, ['page'], true) ? 'page' : 'faq';
                    $action_label = $action_type === 'page' ? '📄 Crea pagina bozza' : '📝 Crea FAQ bozza';
                    echo '<button class="button button-primary in3pida-sug-action" data-id="' . $sug_id . '" data-action="' . $action_type . '" data-nonce="' . esc_attr($nonce_sug) . '" style="background:#0D5F75;border-color:#0a4d60;font-size:12px;padding:4px 12px;white-space:nowrap">' . $action_label . '</button>';
                    echo '<button class="button in3pida-sug-dismiss" data-id="' . $sug_id . '" data-nonce="' . esc_attr($nonce_sug) . '" style="font-size:11px;padding:3px 10px;color:#666b84">Ignora</button>';
                } elseif ($sug_status === 'applied') {
                    echo '<span style="font-size:12px;color:#0D5F75;font-weight:700">✓ Applicato</span>';
                    if ($sug_post) {
                        $edit_url = get_edit_post_link($sug_post, 'raw');
                        if ($edit_url) echo '<a href="' . esc_url($edit_url) . '" class="button" style="font-size:11px;padding:3px 10px" target="_blank">Apri bozza</a>';
                    }
                } elseif ($sug_status === 'dismissed') {
                    echo '<span style="font-size:12px;color:#666b84">Ignorato</span>';
                    echo '<button class="button in3pida-sug-restore" data-id="' . $sug_id . '" data-nonce="' . esc_attr($nonce_sug) . '" style="font-size:11px;padding:3px 10px">Ripristina</button>';
                }
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
            echo '</section>';
        }

        $this->monitor_page_inline_js($nonce_sync, $nonce_sug);
        echo '</div></div>';
    }

    private function monitor_page_inline_js($nonce_sync, $nonce_sug) {
        echo '<script>jQuery(function($){
            $("#in3pida-monitor-sync-btn").on("click",function(){
                var $b=$(this);
                $b.prop("disabled",true).text("Sincronizzazione...");
                $("#in3pida-monitor-sync-msg").hide();
                $.post(ajaxurl,{action:"in3pida_monitor_sync",nonce:"' . esc_js($nonce_sync) . '"},function(r){
                    $b.prop("disabled",false).text("⚡ Sincronizza ora");
                    if(r.success){
                        $("#in3pida-monitor-sync-msg").text("✓ Sincronizzato — ricarica per vedere i dati aggiornati").css("color","#0D5F75").show();
                        setTimeout(function(){location.reload();},1600);
                    } else {
                        $("#in3pida-monitor-sync-msg").text("⚠️ "+(r.data||"Errore")).css("color","#b00020").show();
                    }
                });
            });
            $(document).on("click",".in3pida-sug-action",function(){
                var $b=$(this),id=$b.data("id"),act=$b.data("action"),nc=$b.data("nonce");
                $b.prop("disabled",true).text("...");
                $.post(ajaxurl,{action:"in3pida_monitor_apply_suggestion",nonce:nc,suggestion_id:id,action_type:act},function(r){
                    if(r.success){
                        var html=\'<span style="font-size:12px;color:#0D5F75;font-weight:700">✓ Applicato</span>\';
                        if(r.data.edit_url) html+=\'<a href="\'+r.data.edit_url+\'" class="button" style="font-size:11px;padding:3px 10px" target="_blank">Apri bozza</a>\';
                        $("#sug-actions-"+id).html(html);
                        $("#sug-row-"+id).css("opacity",".55");
                    } else { $b.prop("disabled",false).text("Riprova"); }
                });
            });
            $(document).on("click",".in3pida-sug-dismiss",function(){
                var $b=$(this),id=$b.data("id"),nc=$b.data("nonce");
                $.post(ajaxurl,{action:"in3pida_monitor_dismiss_suggestion",nonce:nc,suggestion_id:id},function(r){
                    if(r.success){
                        $("#sug-actions-"+id).html(\'<span style="font-size:12px;color:#666b84">Ignorato</span>\');
                        $("#sug-row-"+id).css("opacity",".55");
                    }
                });
            });
            $(document).on("click",".in3pida-sug-restore",function(){
                var $b=$(this),id=$b.data("id"),nc=$b.data("nonce");
                $.post(ajaxurl,{action:"in3pida_monitor_dismiss_suggestion",nonce:nc,suggestion_id:id,restore:"1"},function(r){
                    if(r.success) location.reload();
                });
            });
        });</script>';
    }

    // ── END ISI VISIBILITY MONITOR ────────────────────────────────────────────

    // ── ISI REST — SCHEMA + FAQ ───────────────────────────────────────────────

    private function isi_build_schema_payload() {
        $o = $this->schema_opts();
        return [
            'name'               => $o['name']               ?? '',
            'type'               => $o['type']               ?? '',
            'description'        => $o['description']        ?? '',
            'url'                => $o['url']                ?? '',
            'telephone'          => $o['telephone']          ?? '',
            'email'              => $o['email']              ?? '',
            'street'             => $o['street']             ?? '',
            'city'               => $o['city']               ?? '',
            'region'             => $o['region']             ?? '',
            'postal_code'        => $o['postal_code']        ?? '',
            'country'            => $o['country']            ?? '',
            'official_rating'    => $o['official_rating']    ?? '',
            'price_range'        => $o['price_range']        ?? '',
            'checkin_time'       => $o['checkin_time']       ?? '',
            'checkout_time'      => $o['checkout_time']      ?? '',
            'pets_allowed'       => $o['pets_allowed']       ?? '',
            'languages'          => $o['languages']          ?? '',
            'amenities'          => $o['amenities']          ?? [],
            'nearby_attractions' => $o['nearby_attractions'] ?? '',
            'keywords'           => $o['keywords']           ?? '',
            'latitude'           => $o['latitude']           ?? '',
            'longitude'          => $o['longitude']          ?? '',
            'enabled'            => (int)($o['enabled'] ?? 1),
            'output_scope'       => $o['output_scope']       ?? 'home',
            'only_if_required'   => (int)($o['only_if_required'] ?? 0),
            'include_website'    => (int)($o['include_website'] ?? 1),
            'include_faq'        => (int)($o['include_faq'] ?? 1),
            'include_breadcrumb' => (int)($o['include_breadcrumb'] ?? 0),
            'sameas_guided'      => (array)($o['sameas_guided'] ?? []),
            'sameas'             => array_values(array_map(function($r){ return is_array($r) ? ($r['url'] ?? '') : $r; }, (array)($o['sameas'] ?? []))),
            '_synced_at'         => gmdate('c'),
            '_source'            => 'plugin',
        ];
    }

    private function isi_build_faq_payload(array $query_map = [], ?array $score_history = []) {
        $posts = get_posts([
            'post_type'      => self::CPT,
            'posts_per_page' => -1,
            'post_status'    => ['publish', 'draft'],
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ]);
        $items = [];
        foreach ($posts as $p) {
            $solo_ai = (bool) get_post_meta($p->ID, '_in3pida_llm_only', true);
            $status  = $solo_ai ? 'solo_ai' : $p->post_status;
            $items[] = [
                'id'       => $p->ID,
                'question' => $p->post_title,
                'answer'   => $p->post_content,
                'solo_ai'  => $solo_ai,
                'status'   => $status,
                'order'    => (int) $p->menu_order,
                'date'     => $p->post_date,
            ];
        }
        $payload = [
            'items'      => $items,
            'total'      => count($items),
            '_synced_at' => gmdate('c'),
            '_source'    => 'plugin',
        ];
        if (!empty($query_map)) {
            $payload['query_map'] = $query_map;
        }
        // Preserva lo storico punteggi AI — se null (fetch fallito) non sovrascrivere
        if ($score_history !== null && !empty($score_history)) {
            $payload['score_history'] = $score_history;
        }
        return $payload;
    }

    private function isi_append_today_score(array $history, array $geo_scores): array {
        $today = gmdate('Y-m-d');
        $entry = [
            'date'             => $today,
            'geo'              => $geo_scores['ai_readiness'] ?? null,
            'completeness'     => $geo_scores['completeness_score'] ?? null,
            'coverage'         => $geo_scores['coverage_pct'] ?? null,
            'ai_readiness'     => $geo_scores['ai_readiness'] ?? null,
            'answer_extraction'=> $geo_scores['answer_extraction'] ?? null,
            'quality_safety'   => $geo_scores['quality_safety'] ?? null,
            'ai_visibility'    => $geo_scores['ai_visibility'] ?? null,
        ];
        // Rimuovi la voce di oggi se esiste già (verrà sostituita con i dati freschi)
        $history = array_values(array_filter($history, fn($h) => ($h['date'] ?? '') !== $today));
        $history[] = $entry;
        // Mantieni al massimo 500 voci (oltre 1 anno di dati giornalieri)
        if (count($history) > 500) {
            $history = array_slice($history, -500);
        }
        return $history;
    }

    private function isi_fetch_current_score_history(string $site_id): ?array {
        $resp = wp_remote_get(
            self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id) . '&select=faq_data',
            [
                'timeout'  => 5,
                'blocking' => true,
                'headers'  => [
                    'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                    'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                ],
            ]
        );
        // Ritorna null se il fetch fallisce — il chiamante non sovrascriverà score_history
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) >= 300) {
            return null;
        }
        $body     = json_decode(wp_remote_retrieve_body($resp), true);
        $faq_data = $body[0]['faq_data'] ?? [];
        return is_array($faq_data) && isset($faq_data['score_history']) ? (array) $faq_data['score_history'] : [];
    }

    private function isi_fetch_current_geo_scores(string $site_id): array {
        $resp = wp_remote_get(
            self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id) . '&select=geo_scores',
            [
                'timeout'  => 5,
                'blocking' => true,
                'headers'  => [
                    'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                    'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                ],
            ]
        );
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) >= 300) {
            return [];
        }
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        $geo  = $body[0]['geo_scores'] ?? [];
        return is_array($geo) ? $geo : [];
    }

    private function isi_fetch_current_query_map(string $site_id): array {
        $resp = wp_remote_get(
            self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id) . '&select=faq_data',
            [
                'timeout'  => 5,
                'blocking' => true,
                'headers'  => [
                    'apikey'        => self::ISI_SUPABASE_ANON_KEY,
                    'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY,
                ],
            ]
        );
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) >= 300) {
            return [];
        }
        $body     = json_decode(wp_remote_retrieve_body($resp), true);
        $faq_data = $body[0]['faq_data'] ?? [];
        return is_array($faq_data) ? ($faq_data['query_map'] ?? []) : [];
    }

    private function isi_build_query_map(array $existing = []): array {
        $coverage = $this->compute_query_coverage();
        $result   = [];
        foreach ($coverage['categories'] as $cat_key => $cat_data) {
            $queries       = array_column($cat_data['queries'], 'q');
            $covered_count = count(array_filter($cat_data['queries'], fn($q) => $q['covered']));
            $existing_entry = $existing[$cat_key] ?? [];
            $answer        = $existing_entry['answer'] ?? ($existing_entry['risposta'] ?? '');
            $result[$cat_key] = [
                'queries' => $queries,
                'covered' => $covered_count > 0 || !empty($answer),
                'answer'  => $answer,
            ];
        }
        return $result;
    }

    public function isi_rest_schema(\WP_REST_Request $request) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');

        if ($request->get_method() === 'GET') {
            return rest_ensure_response($this->isi_build_schema_payload());
        }

        $secret  = $request->get_param('secret');
        $site_id = $this->isi_site_id();
        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }

        $schema = $request->get_param('schema');
        if (!is_array($schema)) {
            return new \WP_Error('invalid_data', 'Dati schema non validi', ['status' => 400]);
        }

        $current = $this->schema_opts();
        $text_fields = ['name','type','description','url','telephone','email','street','city','region','postal_code','country','official_rating','price_range','checkin_time','checkout_time','pets_allowed','languages','nearby_attractions','keywords','latitude','longitude','slogan'];
        foreach ($text_fields as $f) {
            if (array_key_exists($f, $schema)) {
                $current[$f] = sanitize_text_field((string)($schema[$f] ?? ''));
            }
        }
        if (isset($schema['amenities']) && is_array($schema['amenities'])) {
            $current['amenities'] = array_map('sanitize_text_field', $schema['amenities']);
        }
        // Impostazioni output Schema pilotate da Eletta (accensione, dove mostrarlo, ecc.)
        foreach (['enabled','only_if_required','include_website','include_faq','include_breadcrumb','disable_external_schema'] as $bk) {
            if (array_key_exists($bk, $schema)) $current[$bk] = !empty($schema[$bk]) ? 1 : 0;
        }
        if (array_key_exists('output_scope', $schema) && in_array($schema['output_scope'], ['home','all','pages'], true)) {
            $current['output_scope'] = $schema['output_scope'];
        }
        if (array_key_exists('selected_pages', $schema)) {
            $current['selected_pages'] = sanitize_text_field((string)$schema['selected_pages']);
        }
        // Profili social/ufficiali (sameAs) pilotati da Eletta
        if (isset($schema['sameas_guided']) && is_array($schema['sameas_guided'])) {
            $current['sameas_guided'] = $this->sanitize_guided_sameas($schema['sameas_guided']);
        }
        if (isset($schema['sameas']) && is_array($schema['sameas'])) {
            $current['sameas'] = $this->sanitize_url_rows($schema['sameas']);
        }
        update_option(self::SCHEMA_OPTION, $current);
        update_option('in3pida_schema_last_saved', gmdate('c'), false);
        $this->_schema_opts_cache = null;
        return rest_ensure_response(['ok' => true, 'message' => 'Schema.org aggiornato']);
    }

    // Auto-rileva la pagina FAQ e salva PAGE_OPTION se non ancora impostato
    public function maybe_set_faq_page_option() {
        if (get_option(self::PAGE_OPTION)) return;
        // Per slug (funziona anche se Elementor ha svuotato il contenuto)
        $by_slug = get_page_by_path('faq', OBJECT, 'page');
        if ($by_slug) {
            update_option(self::PAGE_OPTION, $by_slug->ID);
            $this->clear_faq_page_cache($by_slug->ID);
            return;
        }
        // Fallback per contenuto
        $pages = get_posts(['post_type' => 'page', 'post_status' => ['publish', 'draft'], 'posts_per_page' => 1, 's' => 'in3pida_faq']);
        if (!empty($pages)) {
            update_option(self::PAGE_OPTION, $pages[0]->ID);
            $this->clear_faq_page_cache($pages[0]->ID);
        }
    }

    // Intercetta la pagina FAQ prima che il tema possa uscire (VIBe 0-byte, 404, shortcode mancante)
    public function faq_page_direct_render() {
        $uri         = $_SERVER['REQUEST_URI'] ?? '/';
        $faq_page_id = absint(get_option(self::PAGE_OPTION));
        $on_faq      = ($faq_page_id && is_page($faq_page_id))
                    || is_page('faq')
                    || (is_404() && stripos($uri, '/faq') !== false);
        if (!$on_faq) return;
        $opts = $this->opts();
        $raw  = get_posts(['post_type' => self::CPT, 'posts_per_page' => -1,
                           'post_status' => ['publish', 'draft'], 'orderby' => 'menu_order',
                           'order' => 'ASC', 'suppress_filters' => true]);
        $show_solo_ai = !empty($opts['show_solo_ai']);
        $items = [];
        foreach ($raw as $p) {
            if ($show_solo_ai || get_post_meta($p->ID, '_in3pida_llm_only', true) !== '1') $items[] = $p;
        }
        if (empty($items)) return;
        if (is_404()) {
            status_header(200);
            add_filter('body_class', function($classes) {
                return array_values(array_diff($classes, ['error404', 'error-404']));
            });
        }
        wp_reset_postdata();
        get_header();
        echo '<section id="in3pida-faq-container" class="in3pida-faq-wrap"><div class="in3pida-faq-head"><span class="in3pida-faq-kicker">FAQ</span><h1 class="in3pida-faq-title">' . esc_html($opts['page_title'] ?? 'Domande frequenti') . '</h1>';
        if (!empty($opts['page_intro'])) echo '<div class="in3pida-faq-intro">' . wp_kses_post(wpautop($opts['page_intro'])) . '</div>';
        echo '</div><div class="in3pida-faq-list">';
        $schema = [];
        foreach ($items as $i => $p) {
            $open = ($i === 0 && !empty($opts['open_first'])) ? ' is-open' : '';
            echo '<article class="in3pida-faq-item' . $open . '"><button class="in3pida-faq-q" type="button" aria-expanded="' . ($open ? 'true' : 'false') . '"><span>' . esc_html($p->post_title) . '</span><span class="in3pida-faq-icon">+</span></button><div class="in3pida-faq-a">' . wp_kses_post(wpautop($p->post_content)) . '</div></article>';
            $schema[] = ['@type' => 'Question', 'name' => wp_strip_all_tags($p->post_title), 'acceptedAnswer' => ['@type' => 'Answer', 'text' => wp_strip_all_tags($p->post_content)]];
        }
        echo '</div></section>';
        if (!empty($opts['show_schema']) && $schema) echo '<script type="application/ld+json">' . wp_json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $schema]) . '</script>';
        get_footer();
        exit;
    }

    // Fallback JS: renderizza FAQ direttamente (dati embedded nel PHP, nessuna fetch)
    public function faq_js_fallback() {
        global $post;
        if (!is_a($post, 'WP_Post')) return;
        $faq_page_id = absint(get_option(self::PAGE_OPTION));
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $on_faq = ($faq_page_id && is_page($faq_page_id))
               || is_page('faq')
               || has_shortcode($post->post_content, 'in3pida_faq')
               || has_shortcode($post->post_content, 'site_faq')
               || (stripos($uri, '/faq') !== false);
        if (!$on_faq) return;
        $opts  = $this->opts();
        $posts = get_posts([
            'post_type'      => self::CPT,
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ]);
        $show_solo_ai = !empty($opts['show_solo_ai']);
        $items = [];
        foreach ($posts as $p) {
            if (!$show_solo_ai && get_post_meta($p->ID, '_in3pida_llm_only', true)) continue;
            $items[] = ['q' => $p->post_title, 'a' => $p->post_content];
        }
        if (empty($items)) return;
        $items_json = wp_json_encode($items);
        $open_first = json_encode(!empty($opts['open_first']));
        $page_title = json_encode($opts['page_title'] ?? 'Domande frequenti');
        echo "<style>
#in3pida-faq-container,#in3pida-faq-container *{box-sizing:border-box!important}
#in3pida-faq-container .in3pida-faq-a{display:none!important;height:0!important;overflow:hidden!important;padding:0!important}
#in3pida-faq-container .in3pida-faq-item.is-open .in3pida-faq-a{display:block!important;height:auto!important;overflow:visible!important;padding:0 24px 24px!important;visibility:visible!important;opacity:1!important}
</style>
<script>
(function(){
    function esc(s){var d=document.createElement('div');d.textContent=s||'';return d.innerHTML;}
    var DATA={$items_json}, openFirst={$open_first}, title={$page_title};
    function showAns(el){el.style.setProperty('display','block','important');el.style.setProperty('height','auto','important');el.style.setProperty('overflow','visible','important');el.style.setProperty('visibility','visible','important');el.style.setProperty('opacity','1','important');el.style.setProperty('padding','0 24px 24px','important');}
    function hideAns(el){el.style.setProperty('display','none','important');el.style.setProperty('height','0','important');el.style.setProperty('overflow','hidden','important');}
    function run(){
        var list=document.querySelector('.in3pida-faq-list');
        if(list&&list.children.length>0) return;
        if(!list){
            var wrap=document.getElementById('in3pida-faq-container');
            if(!wrap){
                wrap=document.createElement('section');wrap.id='in3pida-faq-container';wrap.className='in3pida-faq-wrap';
                var footer=document.querySelector('footer,#footer,.site-footer');
                var inserted=false;
                // Caso VIBe e temi simili: inserisci DOPO .sections-inclusion come fratello (non dentro)
                var si=document.querySelector('.faq-page .sections-inclusion,.faq-page .sections_inclusion');
                if(si&&(!footer||!footer.contains(si))){
                    si.parentNode.insertBefore(wrap,si.nextSibling);
                    inserted=true;
                }
                if(!inserted){
                    var target=null;
                    var candidates=['.faq-page','main .entry-content','.entry-content','#main','main','#content','.site-main'];
                    for(var ci=0;ci<candidates.length;ci++){
                        var el=document.querySelector(candidates[ci]);
                        if(el&&(!footer||!footer.contains(el))){target=el;break;}
                    }
                    if(target){target.insertBefore(wrap,target.firstChild);}
                    else if(footer&&footer.parentNode){footer.parentNode.insertBefore(wrap,footer);}
                    else{document.body.appendChild(wrap);}
                }
                // Auto-rilevamento logo sovrapposto: scatta dopo window.load (immagini caricate)
                function fixLogoOverlap(){
                    var listEl=wrap.querySelector('.in3pida-faq-list');
                    if(!listEl) return;
                    var wrapRect=wrap.getBoundingClientRect();
                    var wrapTop=wrapRect.top+window.scrollY;
                    var imgs=document.querySelectorAll('img');
                    for(var i=0;i<imgs.length;i++){
                        var img=imgs[i];
                        if(wrap.contains(img)) continue;
                        var r=img.getBoundingClientRect();
                        if(r.width<80||r.height<80) continue;
                        var imgBot=r.bottom+window.scrollY;
                        if(imgBot>wrapTop+10){
                            var mt=Math.ceil(imgBot-wrapTop+20);
                            if(mt>0) listEl.style.setProperty('margin-top',mt+'px','important');
                            break;
                        }
                    }
                }
                if(document.readyState==='complete'){fixLogoOverlap();}
                else{window.addEventListener('load',fixLogoOverlap);}
            }
            wrap.innerHTML='<div class=\"in3pida-faq-head\"><span class=\"in3pida-faq-kicker\">FAQ</span><h1 class=\"in3pida-faq-title\">'+esc(title)+'</h1></div><div class=\"in3pida-faq-list\"></div>';
            list=wrap.querySelector('.in3pida-faq-list');
        }
        list.innerHTML=DATA.map(function(f,i){
            var open=(i===0&&openFirst)?' is-open':'';
            return '<article class=\"in3pida-faq-item'+open+'\">'
                +'<button class=\"in3pida-faq-q\" type=\"button\" aria-expanded=\"'+(open?'true':'false')+'\">'
                +'<span>'+esc(f.q)+'</span><span class=\"in3pida-faq-icon\">'+(open?'−':'+')+'</span></button>'
                +'<div class=\"in3pida-faq-a\">'+esc(f.a)+'</div></article>';
        }).join('');
        list.querySelectorAll('.in3pida-faq-a').forEach(function(a){hideAns(a);});
        if(openFirst&&list.firstElementChild){showAns(list.firstElementChild.querySelector('.in3pida-faq-a'));}
        list.querySelectorAll('.in3pida-faq-q').forEach(function(btn){
            btn.addEventListener('click',function(e){
                e.stopPropagation();
                var art=this.closest('.in3pida-faq-item');
                var wasOpen=art.classList.contains('is-open');
                list.querySelectorAll('.in3pida-faq-item').forEach(function(a){
                    a.classList.remove('is-open');
                    a.querySelector('.in3pida-faq-q').setAttribute('aria-expanded','false');
                    a.querySelector('.in3pida-faq-icon').textContent='+';
                    hideAns(a.querySelector('.in3pida-faq-a'));
                });
                if(!wasOpen){
                    art.classList.add('is-open');
                    this.setAttribute('aria-expanded','true');
                    this.querySelector('.in3pida-faq-icon').textContent='−';
                    showAns(art.querySelector('.in3pida-faq-a'));
                }
            });
        });
    }
    if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',run);}else{run();}
})();
</script>";
    }

    public function isi_rest_create_faq_page(\WP_REST_Request $request) {
        header('Access-Control-Allow-Origin: *');
        $secret  = $request->get_param('secret');
        $site_id = $this->isi_site_id();
        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }
        // Se l'app indica una pagina FAQ specifica (es. quella già esistente sul sito),
        // attacca lo shortcode a QUELLA pagina invece di crearne una nuova.
        $page_path = trim((string) $request->get_param('page_path'));
        if ($page_path !== '') {
            $parsed = parse_url($page_path, PHP_URL_PATH);
            $page_path = trim($parsed !== null && $parsed !== false ? $parsed : $page_path, '/');
        }
        if ($page_path !== '') {
            $target = get_page_by_path($page_path);
            if ($target) {
                $has_sc = (stripos($target->post_content, '[in3pida_faq') !== false)
                       || (stripos($target->post_content, '[site_faq') !== false);
                if (!$has_sc) {
                    wp_update_post([
                        'ID'           => $target->ID,
                        'post_content' => rtrim($target->post_content) . "\n\n[in3pida_faq]",
                    ]);
                }
                if ($target->post_status !== 'publish') {
                    wp_update_post(['ID' => $target->ID, 'post_status' => 'publish']);
                }
                update_option(self::PAGE_OPTION, $target->ID);
                return rest_ensure_response(['ok' => true, 'url' => get_permalink($target->ID), 'created' => false, 'attached' => !$has_sc]);
            }
        }
        // Cerca pagina esistente con shortcode
        $existing = get_posts([
            'post_type'      => 'page',
            'post_status'    => ['publish', 'draft'],
            'posts_per_page' => 1,
            's'              => 'in3pida_faq',
        ]);
        if (!empty($existing)) {
            $page = $existing[0];
            if ($page->post_status !== 'publish') {
                wp_update_post(['ID' => $page->ID, 'post_status' => 'publish']);
            }
            update_option(self::PAGE_OPTION, $page->ID);
            return rest_ensure_response(['ok' => true, 'url' => get_permalink($page->ID), 'created' => false]);
        }
        // Crea nuova pagina
        $page_id = wp_insert_post([
            'post_title'   => 'FAQ',
            'post_name'    => 'faq',
            'post_content' => '[in3pida_faq]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ]);
        if (is_wp_error($page_id)) {
            return new \WP_Error('create_failed', $page_id->get_error_message(), ['status' => 500]);
        }
        update_option(self::PAGE_OPTION, $page_id);
        return rest_ensure_response(['ok' => true, 'url' => get_permalink($page_id), 'created' => true]);
    }

    // Legge impostazioni stile e le restituisce nel formato atteso da hotel.html
    public function isi_rest_get_faq_settings(\WP_REST_Request $request) {
        header('Access-Control-Allow-Origin: *');
        $o = get_option(self::OPTION, self::defaults());
        $order_by = (($o['order_by'] ?? 'menu_order') === 'post_title' && ($o['order'] ?? 'ASC') === 'ASC') ? 'asc' : 'manual';
        return rest_ensure_response([
            'page_title'           => $o['page_title']               ?? '',
            'page_subtitle'        => $o['page_intro']               ?? '',
            'color_primary'        => $o['primary_color']            ?? '#171b33',
            'color_primary_inherit'=> (bool)($o['primary_color_inherit'] ?? false),
            'color_accent'         => $o['accent_color']             ?? '#0D5F75',
            'color_accent_inherit' => (bool)($o['accent_color_inherit']  ?? false),
            'color_text'           => $o['text_color']               ?? '#171b33',
            'color_text_inherit'   => (bool)($o['text_color_inherit']    ?? false),
            'color_bg'             => $o['background_color']         ?? '#ffffff',
            'color_bg_inherit'     => (bool)($o['background_color_inherit'] ?? false),
            'color_box_bg'         => $o['card_background']          ?? '#ffffff',
            'color_box_bg_inherit' => (bool)($o['card_background_inherit'] ?? false),
            'border_radius'        => (int)($o['border_radius']      ?? 16),
            'font_family'          => $o['font_family']              ?? '',
            'show_kicker'          => (bool)($o['show_kicker'] ?? true),
            'width_type'           => $o['max_width_mode']           ?? 'custom',
            'width'                => (int)($o['max_width']          ?? 920),
            'order_by'             => $order_by,
            'open_first'           => (bool)($o['open_first']        ?? false),
            'schema_seo'           => (bool)($o['show_schema']       ?? true),
            'show_solo_ai'         => (bool)($o['show_solo_ai']      ?? false),
        ]);
    }

    // Legge o cambia lo stato (publish/draft) della pagina FAQ
    public function isi_rest_faq_page_status(\WP_REST_Request $request) {
        header('Access-Control-Allow-Origin: *');
        if ($request->get_method() === 'OPTIONS') return rest_ensure_response([]);
        $secret  = $request->get_param('site_id') ?: $request->get_param('secret');
        $site_id = $this->isi_site_id();
        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }
        $page_id = absint(get_option(self::PAGE_OPTION));
        if (!$page_id) return new \WP_Error('no_page', 'Pagina FAQ non trovata', ['status' => 404]);
        if ($request->get_method() === 'GET') {
            $post = get_post($page_id);
            return rest_ensure_response(['ok' => true, 'status' => $post ? $post->post_status : 'unknown', 'page_id' => $page_id]);
        }
        $status = $request->get_param('status');
        if (!in_array($status, ['publish', 'draft'], true)) {
            return new \WP_Error('invalid_status', 'Status non valido', ['status' => 400]);
        }
        $result = wp_update_post(['ID' => $page_id, 'post_status' => $status]);
        if (is_wp_error($result)) return $result;
        return rest_ensure_response(['ok' => true, 'status' => $status, 'page_id' => $page_id]);
    }

    // Salva impostazioni stile dal pannello ISI nel plugin WP
    public function isi_rest_save_faq_settings(\WP_REST_Request $request) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        if ($request->get_method() === 'OPTIONS') return rest_ensure_response([]);
        $secret  = $request->get_param('site_id') ?: $request->get_param('secret');
        $site_id = $this->isi_site_id();
        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }
        $cur = get_option(self::OPTION, self::defaults());
        $p = function($k) use ($request) { return $request->get_param($k); };
        if ($p('page_title') !== null)        $cur['page_title']              = sanitize_text_field($p('page_title'));
        if ($p('page_subtitle') !== null)     $cur['page_intro']              = sanitize_textarea_field($p('page_subtitle'));
        if ($p('color_primary') !== null)     $cur['primary_color']           = sanitize_hex_color($p('color_primary')) ?: $cur['primary_color'];
        $cur['primary_color_inherit'] = $p('color_primary_inherit') !== null ? (int)(bool)$p('color_primary_inherit') : ($cur['primary_color_inherit'] ?? 0);
        if ($p('color_accent') !== null)      $cur['accent_color']            = sanitize_hex_color($p('color_accent')) ?: $cur['accent_color'];
        $cur['accent_color_inherit'] = $p('color_accent_inherit') !== null ? (int)(bool)$p('color_accent_inherit') : ($cur['accent_color_inherit'] ?? 0);
        if ($p('color_text') !== null)        $cur['text_color']              = sanitize_hex_color($p('color_text')) ?: $cur['text_color'];
        $cur['text_color_inherit'] = $p('color_text_inherit') !== null ? (int)(bool)$p('color_text_inherit') : ($cur['text_color_inherit'] ?? 0);
        if ($p('color_bg') !== null)          $cur['background_color']        = sanitize_hex_color($p('color_bg')) ?: $cur['background_color'];
        $cur['background_color_inherit'] = $p('color_bg_inherit') !== null ? (int)(bool)$p('color_bg_inherit') : ($cur['background_color_inherit'] ?? 0);
        if ($p('color_box_bg') !== null)      $cur['card_background']         = sanitize_hex_color($p('color_box_bg')) ?: $cur['card_background'];
        $cur['card_background_inherit'] = $p('color_box_bg_inherit') !== null ? (int)(bool)$p('color_box_bg_inherit') : ($cur['card_background_inherit'] ?? 0);
        if ($p('border_radius') !== null)     $cur['border_radius']           = absint($p('border_radius'));
        if ($p('font_family') !== null)       $cur['font_family']             = sanitize_text_field($p('font_family'));
        if ($p('width_type') !== null)        $cur['max_width_mode']          = sanitize_text_field($p('width_type'));
        if ($p('width') !== null)             $cur['max_width']               = absint($p('width'));
        if ($p('open_first') !== null)        $cur['open_first']              = (int)(bool)$p('open_first');
        if ($p('show_kicker') !== null)       $cur['show_kicker']             = (int)(bool)$p('show_kicker');
        if ($p('schema_seo') !== null)        $cur['show_schema']             = (int)(bool)$p('schema_seo');
        if ($p('show_solo_ai') !== null)      $cur['show_solo_ai']            = (int)(bool)$p('show_solo_ai');
        $order_by = $p('order_by');
        if ($order_by === 'asc')    { $cur['order_by'] = 'post_title'; $cur['order'] = 'ASC'; }
        elseif ($order_by === 'manual') { $cur['order_by'] = 'menu_order'; $cur['order'] = 'ASC'; }
        update_option(self::OPTION, $cur);
        return rest_ensure_response(['ok' => true]);
    }

    // Disabilita cache per la pagina FAQ (WP Rocket, LiteSpeed, W3TC, ecc.)
    public function maybe_nocache_faq_page() {
        $faq_page_id = absint(get_option(self::PAGE_OPTION));
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        if (!($faq_page_id && is_page($faq_page_id)) && !is_page('faq') && stripos($uri, '/faq') === false) return;
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        if (!defined('DONOTCACHEDB'))   define('DONOTCACHEDB', true);
        nocache_headers();
    }

    // Svuota la cache per la pagina FAQ nei plugin di cache più comuni
    private function clear_faq_page_cache($page_id) {
        if (!$page_id) return;
        if (function_exists('rocket_clean_post'))       rocket_clean_post($page_id);
        if (function_exists('w3tc_flush_post'))         w3tc_flush_post($page_id);
        if (function_exists('wpsc_delete_post_cache'))  wpsc_delete_post_cache($page_id);
        do_action('litespeed_purge_post', $page_id);
        do_action('cache_enabler_clear_site_cache');
        // Tocca il post per invalidare cache che ascoltano save_post
        global $wpdb;
        $wpdb->update($wpdb->posts, ['post_modified' => current_time('mysql'), 'post_modified_gmt' => current_time('mysql', 1)], ['ID' => $page_id]);
        clean_post_cache($page_id);
    }

    public function isi_rest_faq_manage(\WP_REST_Request $request) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');

        if ($request->get_method() === 'GET') {
            header('Cache-Control: no-store, no-cache, must-revalidate');
            return rest_ensure_response($this->isi_build_faq_payload());
        }

        $secret  = $request->get_param('secret');
        $site_id = $this->isi_site_id();
        if (empty($secret) || $secret !== $site_id) {
            return new \WP_Error('unauthorized', 'Non autorizzato', ['status' => 403]);
        }

        $action = $request->get_param('action');
        $faq    = (array) ($request->get_param('faq') ?? []);

        if ($action === 'list') {
            header('Cache-Control: no-store, no-cache, must-revalidate');
            return rest_ensure_response($this->isi_build_faq_payload());
        }

        if ($action === 'add') {
            $question = sanitize_text_field($faq['question'] ?? '');
            $answer   = wp_kses_post($faq['answer'] ?? '');
            if (!$question) {
                return new \WP_Error('missing_question', 'Domanda obbligatoria', ['status' => 400]);
            }
            $id = wp_insert_post([
                'post_type'    => self::CPT,
                'post_title'   => $question,
                'post_content' => $answer,
                'post_status'  => 'publish',
                'menu_order'   => (int)($faq['order'] ?? 0),
            ]);
            if (is_wp_error($id)) {
                return new \WP_Error('insert_failed', $id->get_error_message(), ['status' => 500]);
            }
            if (!empty($faq['solo_ai'])) {
                update_post_meta($id, '_in3pida_llm_only', '1');
            }
            return rest_ensure_response(['ok' => true, 'id' => $id]);
        }

        if ($action === 'update' && !empty($faq['id'])) {
            $pid = (int) $faq['id'];
            wp_update_post([
                'ID'           => $pid,
                'post_title'   => sanitize_text_field($faq['question'] ?? ''),
                'post_content' => wp_kses_post($faq['answer'] ?? ''),
                'post_status'  => 'publish',
                'menu_order'   => (int)($faq['order'] ?? 0),
            ]);
            update_post_meta($pid, '_in3pida_llm_only', !empty($faq['solo_ai']) ? '1' : '');
            return rest_ensure_response(['ok' => true]);
        }

        if ($action === 'delete' && !empty($faq['id'])) {
            wp_delete_post((int) $faq['id'], true);
            return rest_ensure_response(['ok' => true]);
        }

        return new \WP_Error('invalid_action', 'Azione non valida: ' . esc_html($action), ['status' => 400]);
    }

    // ── SC DETECTION ──────────────────────────────────────────────────────────

    /**
     * Rileva la presenza di Google Search Console sul sito.
     * Controlla: Google Site Kit, meta tag google-site-verification, plugin SEO
     * compatibili (Yoast, Rank Math, AIOSEO, SEOPress).
     *
     * @return array { detected: bool, method: string|null }
     */
    public function isi_detect_search_console() {
        $detected = false;
        $method   = null;

        // 1. Google Site Kit attivo
        if ( is_plugin_active('google-site-kit/google-site-kit.php') ) {
            $sk_options = get_option('googlesitekit_settings', []);
            if ( !empty($sk_options['connected_account_id']) || !empty($sk_options['setup_complete']) ) {
                $detected = true;
                $method   = 'google-site-kit';
            } else {
                $detected = true;
                $method   = 'google-site-kit-installed';
            }
        }

        // 2. Meta tag google-site-verification in wp_head output
        if ( ! $detected ) {
            $sc_code = '';
            // Yoast SEO
            $yoast = get_option('wpseo', []);
            if ( ! empty($yoast['googleverify']) ) {
                $sc_code = $yoast['googleverify'];
            }
            // Rank Math
            if ( ! $sc_code ) {
                $rm = get_option('rank-math-options-general', []);
                if ( ! empty($rm['google_verify']) ) {
                    $sc_code = $rm['google_verify'];
                }
            }
            // AIOSEO
            if ( ! $sc_code ) {
                $aio = get_option('aioseo_options', []);
                $gv  = $aio['webmasterTools']['google'] ?? '';
                if ( $gv ) $sc_code = $gv;
            }
            // SEOPress
            if ( ! $sc_code ) {
                $sp = get_option('seopress_pro_option_name', []);
                if ( ! empty($sp['seopress_google_site_verification']) ) {
                    $sc_code = $sp['seopress_google_site_verification'];
                }
            }
            // Codice salvato dal nostro stesso plugin
            if ( ! $sc_code ) {
                $isi_hp = $this->isi_fetch_hotel_profile();
                $sc_code = $isi_hp['isi_config']['sc_verification_code'] ?? '';
            }
            if ( $sc_code ) {
                $detected = true;
                $method   = 'meta-tag';
            }
        }

        // 3. Plugin SEO attivi noti
        if ( ! $detected ) {
            $seo_plugins = [
                'wordpress-seo/wp-seo.php'   => 'yoast-seo',
                'seo-by-rank-math/rank-math.php' => 'rank-math',
                'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'aioseo',
                'wp-seopress/seopress.php'   => 'seopress',
            ];
            foreach ( $seo_plugins as $plugin_file => $plugin_label ) {
                if ( is_plugin_active($plugin_file) ) {
                    $detected = true;
                    $method   = $plugin_label;
                    break;
                }
            }
        }

        return [ 'detected' => $detected, 'method' => $method ];
    }

    /**
     * Helper: recupera hotel_profile da Supabase (usato in isi_detect_search_console).
     */
    private function isi_fetch_hotel_profile() {
        $site_id = $this->isi_site_id();
        if ( ! $site_id ) return [];
        $resp = wp_remote_get(
            self::ISI_SUPABASE_URL . '/rest/v1/isi_sites?site_id=eq.' . urlencode($site_id) . '&select=hotel_profile',
            [ 'headers' => [ 'apikey' => self::ISI_SUPABASE_ANON_KEY, 'Authorization' => 'Bearer ' . self::ISI_SUPABASE_ANON_KEY ], 'timeout' => 4 ]
        );
        if ( is_wp_error($resp) ) return [];
        $rows = json_decode(wp_remote_retrieve_body($resp), true);
        return is_array($rows) && isset($rows[0]['hotel_profile']) ? (array)$rows[0]['hotel_profile'] : [];
    }

    // ── ISI SIGNALS (frontend click tracking) ────────────────────────────────
    //
    // SQL per creare la tabella nel progetto Supabase:
    // CREATE TABLE isi_signals (
    //   id         uuid default gen_random_uuid() primary key,
    //   site_id    text,
    //   event_type text,
    //   page_url   text,
    //   element_text text,
    //   created_at timestamptz default now()
    // );
    //

    /**
     * Output dello script frontend che monitora i click CTA e li invia a isi_signals.
     * Rate limiting: max 1 evento ogni 5 secondi, max 50 per sessione.
     */
    public function isi_signals_script() {
        if ( is_admin() || wp_doing_ajax() ) return;
        $site_id = $this->isi_site_id();
        if ( ! $site_id ) return;
        $supabase_url = self::ISI_SUPABASE_URL;
        $anon_key     = self::ISI_SUPABASE_ANON_KEY;
        ?>
<script id="isi-signals-tracker">
(function(){
    'use strict';
    var SITE_ID    = <?php echo wp_json_encode($site_id); ?>;
    var SB_URL     = <?php echo wp_json_encode($supabase_url); ?>;
    var SB_KEY     = <?php echo wp_json_encode($anon_key); ?>;
    var RATE_MS    = 5000;
    var MAX_SESS   = 50;
    var lastSent   = 0;
    var sessCnt    = 0;

    function sendSignal(evtType, elemText) {
        var now = Date.now();
        if (sessCnt >= MAX_SESS) return;
        if (now - lastSent < RATE_MS) return;
        lastSent = now;
        sessCnt++;
        try {
            fetch(SB_URL + '/rest/v1/isi_signals', {
                method: 'POST',
                headers: {
                    'apikey': SB_KEY,
                    'Authorization': 'Bearer ' + SB_KEY,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=minimal'
                },
                body: JSON.stringify({
                    site_id:      SITE_ID,
                    event_type:   evtType,
                    page_url:     window.location.href,
                    element_text: (elemText || '').substring(0, 200)
                }),
                keepalive: true
            }).catch(function(){});
        } catch(e) {}
    }

    function onCtaClick(e) {
        var el = e.target;
        // Risali al link o bottone più vicino
        while (el && el !== document.body) {
            var tag  = el.tagName ? el.tagName.toUpperCase() : '';
            var href = el.getAttribute ? (el.getAttribute('href') || '') : '';
            var cls  = el.className ? el.className.toString() : '';
            if (
                (tag === 'A'      && (href.indexOf('preventivo') !== -1 || href.indexOf('prenota') !== -1)) ||
                (tag === 'BUTTON' && el.getAttribute('type') === 'submit') ||
                cls.indexOf('cta') !== -1
            ) {
                sendSignal('cta_click', el.innerText || el.textContent || el.value || href);
                return;
            }
            el = el.parentElement;
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            document.addEventListener('click', onCtaClick, true);
        });
    } else {
        document.addEventListener('click', onCtaClick, true);
    }
})();
</script>
        <?php
    }

    // ── END ISI REST SCHEMA + FAQ ─────────────────────────────────────────────

}

add_action('plugins_loaded', function(){ new In3pida_FAQ_Plugin(); });
register_activation_hook(__FILE__, ['In3pida_FAQ_Plugin','activate']);
register_deactivation_hook(__FILE__, ['In3pida_FAQ_Plugin','deactivate']);
