<?php
defined('ABSPATH') || exit;

class IF2_CRM_Combo {

    public static function send(array $creds, array $fields, array $meta): array {
        $smtp_host      = trim($creds['smtp_host']  ?? 'mail.offerta-hotel.com');
        $smtp_user      = trim($creds['smtp_user']  ?? '');
        $smtp_pass      = trim($creds['smtp_pass']  ?? '');
        $smtp_port      = (int)($creds['smtp_port'] ?? 587);
        $from_email     = trim($creds['from_email'] ?? $smtp_user);
        $from_name      = trim($creds['from_name']  ?? 'In3pida');
        $recipient      = trim($creds['recipient_email'] ?? '');
        $hotel_name     = trim($creds['hotel_name']     ?? '');

        if (!$smtp_user || !$smtp_pass || !$recipient) {
            return ['status' => 'error', 'code' => 0, 'message' => 'smtp_user, smtp_pass o recipient_email mancanti'];
        }

        $full    = trim($fields['fullname'] ?? '');
        $space   = strpos($full, ' ');
        $nome    = $space !== false ? substr($full, 0, $space) : $full;
        $cognome = $space !== false ? trim(substr($full, $space + 1)) : '.';
        if ($cognome === '') $cognome = '.';

        $children_ages = [];
        $children = (int)($fields['children'] ?? 0);
        if ($children > 0) {
            foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
                $eta = trim((string)($fields[$slot] ?? ''));
                if ($eta !== '') $children_ages[] = $eta;
            }
        }

        $lang = substr(get_locale(), 0, 2);

        $payload = [
            'nome'           => $nome,
            'cognome'        => $cognome,
            'email'          => trim($fields['email']     ?? ''),
            'telefono'       => trim($fields['phone']     ?? ''),
            'note'           => trim($fields['notes']     ?? ''),
            'tipo_richiesta' => '',
            'portale'        => '',
            'lingua'         => $lang,
            'checkin'        => trim($fields['checkin']   ?? ''),
            'checkout'       => trim($fields['checkout']  ?? ''),
            'trattamento'    => trim($fields['treatment'] ?? ''),
            'camere'         => [[
                'adulti'   => max(1, (int)($fields['adults'] ?? 1)),
                'bambini'  => $children_ages,
            ]],
        ];

        $json    = json_encode($payload, JSON_UNESCAPED_UNICODE);
        $subject = 'Richiesta preventivo da ' . $hotel_name;
        $message = '<div id="codice_mail">' . base64_encode($json) . '</div>';

        $smtp_cfg = compact('smtp_host', 'smtp_user', 'smtp_pass', 'smtp_port', 'from_email', 'from_name');

        $mailer_hook = function (&$phpmailer) use ($smtp_cfg) {
            $phpmailer->isSMTP();
            $phpmailer->Host       = $smtp_cfg['smtp_host'];
            $phpmailer->SMTPAuth   = true;
            $phpmailer->Username   = $smtp_cfg['smtp_user'];
            $phpmailer->Password   = $smtp_cfg['smtp_pass'];
            $phpmailer->SMTPSecure = 'tls';
            $phpmailer->Port       = $smtp_cfg['smtp_port'];
            $phpmailer->setFrom($smtp_cfg['from_email'], $smtp_cfg['from_name']);
        };

        add_action('phpmailer_init', $mailer_hook);

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
            'Reply-To: ' . $from_email,
        ];

        $sent = wp_mail($recipient, $subject, $message, $headers);

        remove_action('phpmailer_init', $mailer_hook);

        if (!$sent) {
            global $phpmailer;
            $err = isset($phpmailer) && is_object($phpmailer) ? $phpmailer->ErrorInfo : 'invio fallito';
            return ['status' => 'error', 'code' => 0, 'message' => $err ?: 'wp_mail ha restituito false'];
        }

        return ['status' => 'ok', 'code' => 200, 'message' => ''];
    }
}
