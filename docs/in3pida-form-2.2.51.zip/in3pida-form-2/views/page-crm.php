<?php
defined('ABSPATH') || exit;

// Salvataggio configurazione CRM
if (isset($_POST['if2_crm_nonce']) && wp_verify_nonce($_POST['if2_crm_nonce'], 'if2_save_crm')) {
    $raw     = (array)($_POST['crm'] ?? []);
    $drivers = IF2_CRM::get_drivers();
    $clean   = [];

    foreach ($drivers as $key => $driver) {
        $d = (array)($raw[$key] ?? []);
        $clean[$key] = ['enabled' => !empty($d['enabled'])];

        foreach (($driver['credentials'] ?? []) as $cred_key => $cred_def) {
            $val = sanitize_text_field($d[$cred_key] ?? '');
            if ($val === '' && $cred_def['type'] === 'password') {
                $existing = get_option('if2_crm_config', []);
                $val = $existing[$key][$cred_key] ?? '';
            }
            $clean[$key][$cred_key] = $val;
        }

        $mapping = [];
        foreach (array_keys($driver['slots'] ?? []) as $slot) {
            $mapping[$slot] = sanitize_text_field($d['mapping'][$slot] ?? '');
        }
        $clean[$key]['mapping'] = $mapping;
    }

    update_option('if2_crm_config', $clean);
    $saved = true;
}

$crm_config  = get_option('if2_crm_config', []);
$drivers     = IF2_CRM::get_drivers();
$all_labels  = IF2_CRM::all_labels();
$first_key   = array_key_first($drivers);
?>
<div class="if2-admin-wrap">
<div class="in3pida-settings-wrap">

    <div class="in3pida-page-header">
        <div>
            <h1>INTEGRAZIONI CRM</h1>
            <p class="in3pida-tagline">Connetti i form direttamente ai tuoi CRM hotel</p>
        </div>
        <span class="in3pida-version-badge">v<?php echo esc_html(IF2_VERSION); ?></span>
    </div>

    <?php if (!empty($saved)): ?>
    <div class="notice notice-success is-dismissible"><p>Impostazioni CRM salvate.</p></div>
    <?php endif; ?>

    <!-- Tab bar -->
    <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:0;border-bottom:2px solid #f0e8ec;padding-bottom:0">
        <?php foreach ($drivers as $key => $driver):
            $enabled = !empty(($crm_config[$key] ?? [])['enabled']);
        ?>
        <button type="button"
            id="crm-tab-<?php echo esc_attr($key); ?>"
            onclick="if2CrmTab('<?php echo esc_js($key); ?>')"
            style="display:flex;align-items:center;gap:7px;padding:9px 18px;border:none;border-bottom:3px solid transparent;background:none;cursor:pointer;font-size:.82rem;font-weight:600;color:#888;margin-bottom:-2px;transition:color .15s,border-color .15s"
            class="if2-crm-tab<?php echo $key === $first_key ? ' if2-crm-tab-active' : ''; ?>">
            <span style="width:9px;height:9px;border-radius:50%;background:<?php echo esc_attr($driver['color'] ?? '#aaa'); ?>;flex-shrink:0;display:inline-block"></span>
            <?php echo esc_html($driver['label']); ?>
            <?php if ($enabled): ?>
            <span style="background:#22c55e;color:#fff;font-size:9px;font-weight:700;padding:1px 6px;border-radius:20px;letter-spacing:.03em">ON</span>
            <?php endif; ?>
        </button>
        <?php endforeach; ?>
    </div>

    <form method="post">
        <?php wp_nonce_field('if2_save_crm', 'if2_crm_nonce'); ?>

        <?php foreach ($drivers as $key => $driver):
            $cfg     = $crm_config[$key] ?? [];
            $enabled = !empty($cfg['enabled']);
        ?>
        <div id="crm-panel-<?php echo esc_attr($key); ?>"
             class="in3pida-section if2-crm-panel"
             style="border-top:none;border-radius:0 8px 8px 8px;<?php echo $key === $first_key ? '' : 'display:none'; ?>">

            <?php if ($key === 'bookingdesigner'): ?>
            <div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;padding:10px 14px;margin-bottom:20px;font-size:.8rem;color:#92400e;line-height:1.6">
                <strong>⚠ Attenzione — campi Nome e Cognome separati</strong><br>
                Questo CRM richiede due campi distinti nel form: uno per il Nome e uno per il Cognome.
                Il campo unico "Nome e Cognome" non è supportato — aggiungi due campi separati prima di usare questa integrazione.
            </div>
            <?php endif; ?>

            <!-- Stato attivazione -->
            <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:#fafafa;border:1px solid #f0e8ec;border-radius:8px;margin-bottom:24px">
                <div>
                    <div style="font-size:.82rem;font-weight:700;color:#555;margin-bottom:2px">
                        Stato integrazione <strong><?php echo esc_html($driver['label']); ?></strong>
                    </div>
                    <div style="font-size:.75rem;color:#999">
                        Quando attivata qui, la singola risposta va abilitata anche nel tab CRM del builder form.
                    </div>
                </div>
                <label style="display:flex;align-items:center;gap:10px;cursor:pointer">
                    <span style="font-size:.82rem;font-weight:600;color:<?php echo $enabled ? '#22c55e' : '#bbb'; ?>" id="crm-lbl-<?php echo esc_attr($key); ?>">
                        <?php echo $enabled ? 'Attivata' : 'Disattivata'; ?>
                    </span>
                    <input type="checkbox"
                        name="crm[<?php echo esc_attr($key); ?>][enabled]"
                        value="1"
                        <?php checked($enabled); ?>
                        style="accent-color:#d82d6b;width:18px;height:18px;cursor:pointer"
                        onchange="
                            var lbl=document.getElementById('crm-lbl-<?php echo esc_js($key); ?>');
                            var tab=document.getElementById('crm-tab-<?php echo esc_js($key); ?>');
                            lbl.textContent=this.checked?'Attivata':'Disattivata';
                            lbl.style.color=this.checked?'#22c55e':'#bbb';
                            var badge=tab.querySelector('.if2-on-badge');
                            if(this.checked&&!badge){var b=document.createElement('span');b.className='if2-on-badge';b.style.cssText='background:#22c55e;color:#fff;font-size:9px;font-weight:700;padding:1px 6px;border-radius:20px;letter-spacing:.03em';b.textContent='ON';tab.appendChild(b);}
                            if(!this.checked&&badge){badge.remove();}
                        ">
                </label>
            </div>

            <!-- Credenziali globali -->
            <?php
            $global_creds = array_filter($driver['credentials'] ?? [], fn($c) => empty($c['per_form']));
            $perform_creds = array_filter($driver['credentials'] ?? [], fn($c) => !empty($c['per_form']));
            ?>

            <?php if (!empty($global_creds)): ?>
            <h3 style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#888;margin:0 0 10px">Credenziali</h3>
            <table class="form-table" style="margin-bottom:24px">
                <?php foreach ($global_creds as $cred_key => $cred_def):
                    $val = $cfg[$cred_key] ?? '';
                ?>
                <tr>
                    <th style="width:220px"><?php echo esc_html($cred_def['label']); ?></th>
                    <td>
                        <input type="<?php echo $cred_def['type'] === 'password' ? 'password' : 'text'; ?>"
                            name="crm[<?php echo esc_attr($key); ?>][<?php echo esc_attr($cred_key); ?>]"
                            value="<?php echo esc_attr($val); ?>"
                            autocomplete="new-password"
                            class="regular-text"
                            placeholder="<?php echo esc_attr($cred_def['placeholder'] ?? ($cred_def['type'] === 'password' ? '••••••••' : '')); ?>">
                        <?php if ($cred_def['type'] === 'password'): ?>
                        <p class="description">Lascia vuoto per mantenere il valore attuale.</p>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php endif; ?>

            <!-- Credenziali per-form (default globale) -->
            <?php if (!empty($perform_creds)): ?>
            <h3 style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#888;margin:0 0 10px">
                Credenziali struttura
                <span style="font-size:.7rem;font-weight:400;color:#bbb;text-transform:none;letter-spacing:0">
                    — valore di default, sovrascrivibile per singolo form nel builder
                </span>
            </h3>
            <table class="form-table" style="margin-bottom:24px">
                <?php foreach ($perform_creds as $cred_key => $cred_def):
                    $val = $cfg[$cred_key] ?? '';
                ?>
                <tr>
                    <th style="width:220px"><?php echo esc_html($cred_def['label']); ?></th>
                    <td>
                        <input type="<?php echo $cred_def['type'] === 'password' ? 'password' : 'text'; ?>"
                            name="crm[<?php echo esc_attr($key); ?>][<?php echo esc_attr($cred_key); ?>]"
                            value="<?php echo esc_attr($val); ?>"
                            class="regular-text"
                            autocomplete="new-password"
                            placeholder="<?php echo esc_attr($cred_def['placeholder'] ?? ''); ?>">
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php endif; ?>

            <!-- Mapping campi -->
            <h3 style="font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#888;margin:0 0 10px;border-top:1px solid #f0f0f0;padding-top:16px">
                Mappa campi
                <span style="font-size:.7rem;font-weight:400;color:#bbb;text-transform:none;letter-spacing:0">
                    — abbina ogni campo CRM al label corrispondente nel form
                </span>
            </h3>

            <?php if (empty($all_labels)): ?>
            <p style="color:#aaa;font-size:.82rem">Nessun form trovato. Crea almeno un form per configurare il mapping.</p>
            <?php else: ?>
            <table class="form-table" style="max-width:640px">
                <?php foreach (($driver['slots'] ?? []) as $slot => $slot_label):
                    $mapped = $cfg['mapping'][$slot] ?? '';
                ?>
                <tr>
                    <th style="width:210px;font-size:.78rem;font-weight:600;color:#555"><?php echo esc_html($slot_label); ?></th>
                    <td>
                        <select name="crm[<?php echo esc_attr($key); ?>][mapping][<?php echo esc_attr($slot); ?>]"
                                style="min-width:260px">
                            <option value="">— Non mappato —</option>
                            <?php foreach ($all_labels as $lbl => $lbl_display): ?>
                            <option value="<?php echo esc_attr($lbl); ?>"<?php selected($mapped, $lbl); ?>>
                                <?php echo esc_html($lbl_display); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php endif; ?>

        </div><!-- .if2-crm-panel -->
        <?php endforeach; ?>

        <div style="padding:8px 0 32px">
            <?php submit_button('Salva impostazioni CRM', 'primary', 'submit', false); ?>
        </div>

    </form>

    <!-- Note -->
    <div class="in3pida-section" style="background:#fafafa;border:1px solid #f0f0f0">
        <h2 style="margin-top:0">Come funziona</h2>
        <ol style="font-size:.82rem;color:#555;line-height:1.8;margin:0;padding-left:18px">
            <li><strong>Scegli il CRM</strong> dal tab qui sopra, inserisci le credenziali e configura il mapping una volta sola.</li>
            <li><strong>Attiva l'integrazione</strong> con la spunta "Attivata" — serve solo a questo CRM, non influisce sugli altri.</li>
            <li><strong>Nel builder di ogni form</strong>, tab CRM, spunta il CRM e inserisci eventuali credenziali specifiche (es. Property Code).</li>
            <li><strong>Il mapping</strong> usa i label dei campi: se il form ha "Arrivo" e hai mappato "Arrivo" su Check-in, funziona automaticamente.</li>
            <li><strong>Il risultato</strong> è visibile nella colonna CRM della pagina Risposte.</li>
        </ol>
    </div>

</div>
</div>

<style>
.if2-crm-tab { border-bottom-color: transparent !important; }
.if2-crm-tab-active, .if2-crm-tab:hover { color: #d82d6b !important; border-bottom-color: #d82d6b !important; }
</style>

<script>
function if2CrmTab(key) {
    document.querySelectorAll('.if2-crm-panel').forEach(function(p){ p.style.display = 'none'; });
    document.querySelectorAll('.if2-crm-tab').forEach(function(t){ t.classList.remove('if2-crm-tab-active'); });
    document.getElementById('crm-panel-' + key).style.display = '';
    document.getElementById('crm-tab-'   + key).classList.add('if2-crm-tab-active');
}
</script>
