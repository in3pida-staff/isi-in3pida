<?php
defined('ABSPATH') || exit;
$per_page = 10;
$page     = max(1, (int) ($_GET['paged'] ?? 1));
$offset   = ($page - 1) * $per_page;
$total    = IF2_Form::count_all();
$pages    = max(1, (int) ceil($total / $per_page));
$forms    = IF2_Form::get_all($per_page, $offset);
$base_url = admin_url('admin.php?page=if2-forms');

// Ultima richiesta per form
global $wpdb;
$_last_subs = $wpdb->get_results(
    "SELECT form_id, MAX(created_at) as last_sub FROM " . IF2_DB::submissions_table() . " GROUP BY form_id",
    ARRAY_A
) ?: [];
$last_sub_map = array_column($_last_subs, 'last_sub', 'form_id');
?>
<style>
.if2-panel-forms{flex:0 0 44%!important;max-width:44%!important;border-right:none!important;align-self:flex-start!important;}
.if2-panel-stats{flex:1 1 0%!important;min-width:0!important;align-self:stretch!important;}
.if2-dashboard{padding:32px!important;gap:20px!important;align-items:flex-start!important;}
.if2-panel{min-height:500px!important;}
.if2-panel-header{padding:14px 16px!important;}
.if2-table thead th{padding:10px 8px!important;font-size:.68rem!important;}
.if2-table tbody td{padding:10px 8px!important;font-size:.78rem!important;}
#if2-forms-table{table-layout:fixed;width:100%;}
#if2-forms-table th:nth-child(1),#if2-forms-table td:nth-child(1){width:34px;}
#if2-forms-table th:nth-child(3),#if2-forms-table td:nth-child(3){width:74px;white-space:nowrap;text-align:center!important;overflow:hidden;}
#if2-forms-table th:nth-child(4),#if2-forms-table td:nth-child(4){width:68px;white-space:nowrap;text-align:center!important;overflow:hidden;}
#if2-forms-table th:nth-child(5),#if2-forms-table td:nth-child(5){width:74px;white-space:nowrap;text-align:center!important;overflow:hidden;}
#if2-forms-table th:nth-child(6),#if2-forms-table td:nth-child(6){width:38px;overflow:hidden;text-align:center;padding:0 6px!important;}
#if2-forms-table td:nth-child(6) .if2-btn-delete-form{display:block;width:100%;box-sizing:border-box;padding:10px 0;min-width:0;}
#if2-forms-table td:nth-child(2){overflow:hidden;}
.if2-form-name-link{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
</style>
<div class="if2-admin-wrap">

    <div class="if2-topbar">
        <a href="#" id="if2-export-all" class="if2-topbar-link"><?php echo IF2_Lang::t('export_all'); ?></a>
        <span class="if2-topbar-brand">in3pida-form è un plugin di <strong>in3pida</strong></span>
    </div>

    <div class="if2-dashboard">

        <!-- Panel sinistro: lista form -->
        <div class="if2-panel if2-panel-forms">
            <div class="if2-panel-header">
                <span class="if2-panel-title"><?php echo IF2_Lang::t('forms_title'); ?></span>
                <div class="if2-panel-actions">
                    <div class="if2-search-wrap">
                        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0"><circle cx="5.5" cy="5.5" r="4.5" stroke="#aaa" stroke-width="1.4"/><path d="M9 9l2.5 2.5" stroke="#aaa" stroke-width="1.4" stroke-linecap="round"/></svg>
                        <input type="text" id="if2-search-forms" placeholder="<?php echo esc_attr(IF2_Lang::t('search_placeholder')); ?>" class="if2-search-input">
                    </div>
                    <button class="if2-btn-primary" id="if2-btn-new-form"><?php echo IF2_Lang::t('new_form_btn'); ?></button>
                </div>
            </div>

            <table class="if2-table" id="if2-forms-table">
                <thead>
                    <tr>
                        <th style="width:34px"><?php echo IF2_Lang::t('col_id'); ?></th>
                        <th><?php echo IF2_Lang::t('col_name'); ?></th>
                        <th id="if2-sort-created" style="cursor:pointer;user-select:none"><?php echo IF2_Lang::t('col_created_at'); ?> <span id="if2-sort-ico-created" style="font-size:10px;color:#bbb">↕</span></th>
                        <th id="if2-sort-date" style="cursor:pointer;user-select:none"><?php echo IF2_Lang::t('col_last_modified'); ?> <span id="if2-sort-ico" style="font-size:10px;color:#bbb">↕</span></th>
                        <th>Ult. richiesta</th>
                        <th style="width:38px"></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($forms)): ?>
                    <tr class="if2-empty-row"><td colspan="4"><?php echo IF2_Lang::t('no_forms'); ?></td></tr>
                <?php else:
                    foreach ($forms as $f):
                        $builder_url = admin_url('admin.php?page=if2-builder&form_id=' . $f['id']);
                ?>
                    <tr data-form-id="<?php echo esc_attr($f['id']); ?>"
                        data-builder-url="<?php echo esc_url($builder_url); ?>"
                        class="if2-form-row">
                        <td><?php echo esc_html($f['id']); ?></td>
                        <td>
                            <a href="<?php echo esc_url($builder_url); ?>" class="if2-form-name-link">
                                <?php echo esc_html($f['name']); ?>
                            </a>
                        </td>
                        <td class="if2-form-created" data-ts="<?php echo esc_attr(strtotime($f['created_at'] ?? $f['updated_at'])); ?>"><?php echo esc_html(date_i18n('d/m/Y', strtotime($f['created_at'] ?? $f['updated_at']))); ?></td>
                        <td class="if2-form-date" data-ts="<?php echo esc_attr(strtotime($f['updated_at'] ?? $f['created_at'])); ?>">
                            <?php echo esc_html(IF2_Lang::ago(strtotime($f['updated_at'] ?? $f['created_at']))); ?>
                        </td>
                        <td style="color:#888">
                            <?php
                            $ls = $last_sub_map[$f['id']] ?? null;
                            echo $ls ? esc_html(IF2_Lang::ago(strtotime($ls))) : '—';
                            ?>
                        </td>
                        <td>
                            <button class="if2-btn-delete-form" data-id="<?php echo esc_attr($f['id']); ?>" title="Elimina">✕</button>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>

            <div class="if2-panel-footer">
                <span class="if2-pagination-info" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <a href="<?php echo esc_url($base_url . ($i > 1 ? '&paged=' . $i : '')); ?>"
                       style="display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:24px;padding:0 6px;border-radius:3px;font-size:.75rem;text-decoration:none;<?php echo $i === $page ? 'background:#d82d6b;color:#fff;font-weight:700' : 'border:1px solid var(--if2-border);color:#aaa;font-weight:600'; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                </span>
                <div class="if2-accent-bar"></div>
            </div>
        </div>

        <!-- Panel destro: statistiche -->
        <div class="if2-panel if2-panel-stats">
            <div class="if2-panel-header">
                <span class="if2-panel-title"><?php echo IF2_Lang::t('stats_module_title'); ?></span>
                <div class="if2-panel-actions">
                    <label class="if2-checkbox-inline">
                        <input type="checkbox" id="if2-disable-stats"> <?php echo IF2_Lang::t('disable_stats'); ?>
                    </label>
                    <button class="if2-btn-primary" id="if2-reset-stats"><?php echo IF2_Lang::t('reset_stats'); ?></button>
                </div>
            </div>

            <div class="if2-stats-filters">
                <button class="if2-filter-btn" data-range="1s">1S</button>
                <button class="if2-filter-btn active" data-range="1m">1M</button>
                <button class="if2-filter-btn" data-range="1a">1A</button>
                <button class="if2-filter-btn" data-range="custom"><?php echo IF2_Lang::t('custom_range'); ?></button>
                <div id="if2-custom-range" style="display:none;align-items:center;gap:8px;margin-left:4px;font-size:.82rem">
                    <label style="color:#888;font-size:.78rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em"><?php echo IF2_Lang::t('from_date'); ?></label>
                    <input type="date" id="if2-date-from" style="border:1px solid var(--if2-border);border-radius:3px;padding:3px 6px;font-size:.78rem;font-family:inherit">
                    <label style="color:#888;font-size:.78rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em"><?php echo IF2_Lang::t('to_date'); ?></label>
                    <input type="date" id="if2-date-to" style="border:1px solid var(--if2-border);border-radius:3px;padding:3px 6px;font-size:.78rem;font-family:inherit">
                    <button id="if2-apply-custom-range" class="if2-btn-primary" style="padding:4px 12px;font-size:.78rem"><?php echo IF2_Lang::t('apply_range'); ?></button>
                </div>
                <div style="flex:1"></div>
                <div class="if2-search-wrap" style="padding:3px 8px;gap:4px">
                <select class="if2-select-form-stats" id="if2-stats-form-filter" style="border:none !important;background:transparent !important;padding:2px 0 !important;outline:none !important;box-shadow:none !important">
                    <option value="0"><?php echo IF2_Lang::t('all_forms'); ?></option>
                    <?php foreach ($forms as $f): ?>
                    <option value="<?php echo esc_attr($f['id']); ?>"><?php echo esc_html($f['name']); ?></option>
                    <?php endforeach; ?>
                </select>
                </div>
            </div>

            <div class="if2-stats-cards">
                <div class="if2-stat-card">
                    <span class="if2-stat-value" id="stat-views">0</span>
                    <span class="if2-stat-label" style="color:#d82d6b"><?php echo IF2_Lang::t('stat_views'); ?></span>
                </div>
                <div class="if2-stat-card">
                    <span class="if2-stat-value" id="stat-responses">0</span>
                    <span class="if2-stat-label" style="color:#009bb9"><?php echo IF2_Lang::t('stat_responses'); ?></span>
                </div>
                <div class="if2-stat-card">
                    <span class="if2-stat-value" id="stat-conversion">0%</span>
                    <span class="if2-stat-label" style="color:#009bb9"><?php echo IF2_Lang::t('stat_conversion'); ?></span>
                </div>
            </div>

            <div class="if2-chart-wrap">
                <canvas id="if2-stats-chart"></canvas>
            </div>

            <div class="if2-panel-footer">
                <div class="if2-accent-bar"></div>
            </div>
        </div>

    </div>
</div>

<!-- MODAL — CONFERMA ELIMINAZIONE FORM -->
<div class="if2-modal-overlay" id="if2-modal-delete-form">
    <div class="if2-modal-box" style="max-width:420px">
        <div class="if2-modal-header">
            <h4 class="if2-modal-title">Elimina form</h4>
            <button class="if2-modal-close" id="if2-delete-modal-close">&times;</button>
        </div>
        <div class="if2-modal-body">
            <p style="font-size:13px;color:#555;margin:0 0 20px;line-height:1.6">Sei sicuro di voler eliminare questo form e tutte le sue submissions?<br><strong style="color:#d82d6b">L'operazione è irreversibile.</strong></p>
            <div style="display:flex;gap:10px;justify-content:flex-end">
                <button id="if2-delete-form-cancel" style="padding:8px 18px;border:1px solid var(--if2-border);border-radius:4px;background:#fff;font-size:12px;font-weight:600;cursor:pointer;color:#555">Annulla</button>
                <button id="if2-delete-form-confirm" style="padding:8px 18px;border:none;border-radius:4px;background:#d82d6b;color:#fff;font-size:12px;font-weight:700;cursor:pointer">Sì, elimina</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL — NUOVO MODULO -->
<div class="if2-modal-overlay" id="if2-modal-new-form">
    <div class="if2-modal-box">
        <div class="if2-modal-header">
            <h4 class="if2-modal-title"><?php echo IF2_Lang::t('modal_title'); ?></h4>
            <button class="if2-modal-close" id="if2-modal-close">&times;</button>
        </div>
        <div class="if2-modal-body">
            <div class="if2-modal-options">
                <div class="if2-modal-option active" data-type="vuoto">
                    <span class="if2-modal-option-icon">☐</span>
                    <span class="if2-modal-option-label"><?php echo IF2_Lang::t('modal_empty'); ?></span>
                </div>
                <div class="if2-modal-option" data-type="template">
                    <span class="if2-modal-option-icon">📄</span>
                    <span class="if2-modal-option-label"><?php echo IF2_Lang::t('modal_template'); ?></span>
                </div>
                <div class="if2-modal-option" data-type="duplica">
                    <span class="if2-modal-option-icon">⎘</span>
                    <span class="if2-modal-option-label"><?php echo IF2_Lang::t('modal_duplicate'); ?></span>
                </div>
                <div class="if2-modal-option" data-type="importa">
                    <span class="if2-modal-option-icon">↑</span>
                    <span class="if2-modal-option-label"><?php echo IF2_Lang::t('modal_import'); ?></span>
                </div>
            </div>
            <div class="if2-modal-name-row">
                <input type="text" id="if2-modal-form-name" class="if2-modal-name-input" placeholder="<?php echo esc_attr(IF2_Lang::t('modal_name_ph')); ?>">
                <button class="if2-modal-create-btn" id="if2-modal-create"><?php echo IF2_Lang::t('modal_create'); ?></button>
            </div>
            <div id="if2-import-area" style="display:none;margin-top:12px">
                <label style="display:block;font-size:11px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px">Carica file JSON dal tuo PC</label>
                <label for="if2-import-file" style="display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border:1.5px solid var(--if2-border);border-radius:6px;font-size:12px;font-weight:600;color:#555;cursor:pointer;background:#fafafa;margin-bottom:10px">
                    <span style="font-size:16px">📂</span> Scegli file (.json / .txt)
                </label>
                <input type="file" id="if2-import-file" accept=".json,.txt,application/json,text/plain" style="display:none">
                <span id="if2-import-filename" style="font-size:11px;color:#aaa;margin-left:8px"></span>
                <div style="text-align:center;color:#bbb;font-size:11px;margin:8px 0;font-weight:600">— oppure incolla il JSON —</div>
                <textarea id="if2-import-json" placeholder="Incolla qui il JSON del form esportato…" style="width:100%;height:90px;padding:10px 12px;border:1.5px solid var(--if2-border);border-radius:6px;font-size:12px;font-family:inherit;resize:vertical;background:#fafafa;outline:none"></textarea>
            </div>
        </div>
    </div>
</div>
