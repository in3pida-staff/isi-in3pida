<?php
defined('ABSPATH') || exit;

if (isset($_POST['if2_settings_nonce']) && wp_verify_nonce($_POST['if2_settings_nonce'], 'if2_save_settings')) {
    update_option('if2_lang',             sanitize_text_field($_POST['if2_lang']          ?? 'it'));
    update_option('if2_supabase_url',     sanitize_text_field($_POST['supabase_url']      ?? ''));
    $raw_key = sanitize_text_field($_POST['supabase_anon_key'] ?? '');
    if ($raw_key !== '') update_option('if2_supabase_anon_key', if2_encrypt($raw_key));
    update_option('if2_hotel_id',         sanitize_text_field($_POST['hotel_id']          ?? ''));
    update_option('if2_custom_channels',  sanitize_textarea_field($_POST['custom_channels'] ?? ''));
    update_option('if2_antispam_limit',   (int) ($_POST['antispam_limit'] ?? 5));
    update_option('if2_antispam_enabled', !empty($_POST['antispam_enabled']) ? 1 : 0);
    update_option('if2_honeypot_enabled', !empty($_POST['honeypot_enabled']) ? 1 : 0);
    update_option('if2_has_crm_override',  !empty($_POST['if2_has_crm_override']) ? 1 : 0);
    update_option('if2_amelia_key',       sanitize_text_field($_POST['if2_amelia_key']    ?? ''));
    update_option('if2_amelia_secret',    sanitize_text_field($_POST['if2_amelia_secret'] ?? ''));
    update_option('if2_amelia_listid',    sanitize_text_field($_POST['if2_amelia_listid'] ?? ''));
    update_option('if2_amelia_apiurl',    esc_url_raw($_POST['if2_amelia_apiurl']          ?? 'https://api.smshosting.it/rest/api'));
    // Multi-liste per paese
    $raw_list_ids      = array_map('sanitize_text_field', (array) ($_POST['if2_amelia_list_id']      ?? []));
    $raw_list_countries= array_map('sanitize_text_field', (array) ($_POST['if2_amelia_list_country'] ?? []));
    $clean_amelia_lists = [];
    foreach ($raw_list_ids as $i => $lid) {
        $lid = trim($lid);
        $cnt = trim($raw_list_countries[$i] ?? '');
        if ($lid && $cnt) {
            $clean_amelia_lists[] = ['listid' => $lid, 'country' => $cnt];
        }
    }
    update_option('if2_amelia_lists', wp_json_encode($clean_amelia_lists));
    // Reset cache lingua dopo il salvataggio
    IF2_Lang::reset();
}

$lang             = get_option('if2_lang', 'it');
$supabase_url     = get_option('if2_supabase_url', '');
$supabase_key     = if2_decrypt( get_option('if2_supabase_anon_key', '') );
$hotel_id         = get_option('if2_hotel_id', '');
$custom_channels  = get_option('if2_custom_channels', '');
$antispam_limit   = (int) get_option('if2_antispam_limit', 5);
$antispam_enabled = (bool) get_option('if2_antispam_enabled', 1);
$honeypot_enabled = (bool) get_option('if2_honeypot_enabled', 1);
$has_crm_override = (bool) get_option('if2_has_crm_override', 0);
$amelia_key       = get_option('if2_amelia_key', '');
$amelia_secret    = get_option('if2_amelia_secret', '');
$amelia_listid    = get_option('if2_amelia_listid', '');
$amelia_apiurl    = get_option('if2_amelia_apiurl', 'https://api.smshosting.it/rest/api');
$amelia_lists     = json_decode(get_option('if2_amelia_lists', '[]'), true) ?: [];
$amelia_country_opts = [
    'IT'    => 'IT — Italia (.it)',
    'DE'    => 'DE — Germania (.de, .at, .ch)',
    'FR'    => 'FR — Francia (.fr)',
    'EN'    => 'EN — UK / Internazionale (.uk, .co.uk, .com, .ie)',
    'CZ'    => 'CZ — Repubblica Ceca (.cz)',
    'PL'    => 'PL — Polonia (.pl)',
    'RO'    => 'RO — Romania (.ro)',
    'CA'    => 'CA — Canada (.ca)',
    'ES'    => 'ES — Spagna (.es)',
    'ALTRO' => 'ALTRO — Altri',
];
?>
<div class="if2-admin-wrap">
<div class="in3pida-settings-wrap">

    <div class="in3pida-page-header">
        <div>
            <h1>IN3PIDAFORM</h1>
            <p class="in3pida-tagline"><?php echo IF2_Lang::t('tagline'); ?></p>
        </div>
        <span class="in3pida-version-badge">v<?php echo esc_html(IF2_VERSION); ?></span>
    </div>

    <?php if (isset($_POST['if2_settings_nonce'])): ?>
    <div class="notice notice-success is-dismissible"><p><?php echo IF2_Lang::t('settings_saved'); ?></p></div>
    <?php endif; ?>

    <form method="post">
        <?php wp_nonce_field('if2_save_settings', 'if2_settings_nonce'); ?>

        <!-- LINGUA -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_lang'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('lang_label'); ?></th>
                    <td>
                        <select name="if2_lang" class="in3pida-select">
                            <option value="it" <?php selected($lang, 'it'); ?>><?php echo IF2_Lang::t('lang_option_it'); ?></option>
                            <option value="en" <?php selected($lang, 'en'); ?>><?php echo IF2_Lang::t('lang_option_en'); ?></option>
                        </select>
                        <p class="description"><?php echo IF2_Lang::t('lang_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- DATABASE SUPABASE -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_supabase'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('supabase_url_label'); ?></th>
                    <td>
                        <input type="text" name="supabase_url" value="<?php echo esc_attr($supabase_url); ?>"
                               placeholder="https://xxxxxxxxxxx.supabase.co" class="regular-text">
                        <p class="description"><?php echo IF2_Lang::t('supabase_url_desc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php echo IF2_Lang::t('supabase_key_label'); ?></th>
                    <td>
                        <input type="password" name="supabase_anon_key" value="<?php echo esc_attr($supabase_key); ?>"
                               placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." class="regular-text">
                        <p class="description"><?php echo IF2_Lang::t('supabase_key_desc'); ?></p>
                    </td>
                </tr>
            </table>
            <button type="button" id="if2-test-supabase"><?php echo IF2_Lang::t('test_connection'); ?></button>
            <span id="if2-supabase-test-result" style="margin-left:12px;font-size:13px"></span>
        </div>

        <!-- IDENTIFICAZIONE HOTEL -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_hotel'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('hotel_id_label'); ?></th>
                    <td>
                        <input type="text" name="hotel_id" value="<?php echo esc_attr($hotel_id); ?>"
                               placeholder="hotel-in3pida-riccione" class="regular-text">
                        <p class="description"><?php echo IF2_Lang::t('hotel_id_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- CANALI PERSONALIZZATI -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_channels'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('channels_label'); ?></th>
                    <td>
                        <textarea name="custom_channels" rows="4" class="regular-text"
                                  placeholder="TikTok"><?php echo esc_textarea($custom_channels); ?></textarea>
                        <p class="description"><?php echo IF2_Lang::t('channels_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ANTI-SPAM -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_antispam'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('antispam_ip_label'); ?></th>
                    <td>
                        <label class="in3pida-toggle">
                            <input type="checkbox" name="antispam_enabled" <?php checked($antispam_enabled); ?>>
                            <span class="in3pida-toggle-slider"></span>
                            <span class="in3pida-toggle-label"><?php echo IF2_Lang::t($antispam_enabled ? 'antispam_active' : 'antispam_inactive'); ?></span>
                        </label>
                        <input type="number" name="antispam_limit" value="<?php echo esc_attr($antispam_limit); ?>"
                               min="1" max="100" class="in3pida-number-input">
                        <span style="margin-left:6px;font-size:13px;color:#666"><?php echo IF2_Lang::t('antispam_max_label'); ?></span>
                        <p class="description"><?php echo IF2_Lang::t('antispam_ip_desc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php echo IF2_Lang::t('honeypot_label'); ?></th>
                    <td>
                        <label class="in3pida-toggle">
                            <input type="checkbox" name="honeypot_enabled" <?php checked($honeypot_enabled); ?>>
                            <span class="in3pida-toggle-slider"></span>
                            <span class="in3pida-toggle-label"><?php echo IF2_Lang::t($honeypot_enabled ? 'antispam_active' : 'antispam_inactive'); ?></span>
                        </label>
                        <p class="description"><?php echo IF2_Lang::t('honeypot_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- CRM ESTERNO -->
        <div class="in3pida-section">
            <h2>CRM (integrazione esterna)</h2>
            <table class="form-table">
                <tr>
                    <th><label for="if2_has_crm_override">CRM collegato</label></th>
                    <td>
                        <label class="in3pida-toggle">
                            <input type="checkbox" id="if2_has_crm_override" name="if2_has_crm_override" value="1" <?php checked($has_crm_override, true); ?>>
                            <span class="in3pida-toggle-slider"></span>
                            <span class="in3pida-toggle-label"><?php echo $has_crm_override ? 'Attivo' : 'Non attivo'; ?></span>
                        </label>
                        <p class="description">Attiva se questo sito usa un CRM esterno non gestito da questo plugin (es. vecchio script). Il pallino CRM nel monitoring diventerà verde.</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- AMELIA / SMSHOSTING -->
        <div class="in3pida-section">
            <h2>Amelia / SMSHosting</h2>
            <table class="form-table">
                <tr>
                    <th><label for="if2_amelia_key">Auth Key (Client ID)</label></th>
                    <td>
                        <input type="text" id="if2_amelia_key" name="if2_amelia_key"
                               value="<?php echo esc_attr($amelia_key); ?>"
                               placeholder="il-tuo-client-id" class="regular-text">
                        <p class="description">Client ID fornito da SMSHosting/SMSTools.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="if2_amelia_secret">Auth Secret (Client Secret)</label></th>
                    <td>
                        <input type="password" id="if2_amelia_secret" name="if2_amelia_secret"
                               value="<?php echo esc_attr($amelia_secret); ?>"
                               placeholder="il-tuo-client-secret" class="regular-text">
                        <p class="description">Client Secret fornito da SMSHosting/SMSTools.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="if2_amelia_listid">List ID globale (fallback)</label></th>
                    <td>
                        <input type="text" id="if2_amelia_listid" name="if2_amelia_listid"
                               value="<?php echo esc_attr($amelia_listid); ?>"
                               placeholder="123" class="regular-text">
                        <p class="description">Lista di default se non è configurata nessuna lista per paese e il form non ha una lista specifica.</p>
                    </td>
                </tr>
                <tr>
                    <th style="vertical-align:top;padding-top:14px"><label>Liste per paese</label></th>
                    <td>
                        <table id="if2-amelia-lists-table" style="border-collapse:collapse;margin-bottom:10px;min-width:480px">
                            <thead>
                                <tr>
                                    <th style="text-align:left;font-size:11px;color:#888;font-weight:700;padding:0 0 6px;border-bottom:1px solid #e0e0e0;width:130px">List ID</th>
                                    <th style="text-align:left;font-size:11px;color:#888;font-weight:700;padding:0 0 6px 10px;border-bottom:1px solid #e0e0e0">Paese / TLD</th>
                                    <th style="border-bottom:1px solid #e0e0e0;width:30px"></th>
                                </tr>
                            </thead>
                            <tbody id="if2-amelia-lists-tbody">
                                <?php foreach ($amelia_lists as $item): ?>
                                <tr>
                                    <td style="padding:4px 0">
                                        <input type="text" name="if2_amelia_list_id[]"
                                               value="<?php echo esc_attr($item['listid'] ?? ''); ?>"
                                               placeholder="es. 42"
                                               style="width:120px;padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px">
                                    </td>
                                    <td style="padding:4px 0 4px 10px">
                                        <select name="if2_amelia_list_country[]"
                                                style="padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px">
                                            <?php foreach ($amelia_country_opts as $val => $label): ?>
                                            <option value="<?php echo esc_attr($val); ?>"
                                                    <?php selected($item['country'] ?? '', $val); ?>>
                                                <?php echo esc_html($label); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td style="padding:4px 0 4px 8px">
                                        <button type="button" class="if2-amelia-remove-list"
                                                style="background:none;border:none;color:#d82d6b;cursor:pointer;font-size:16px;padding:0 4px;line-height:1"
                                                title="Rimuovi">✕</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <button type="button" id="if2-amelia-add-list"
                                style="font-size:12px;padding:5px 12px;background:#fff;border:1px solid #d82d6b;color:#d82d6b;border-radius:3px;cursor:pointer">
                            + Aggiungi lista
                        </button>
                        <p class="description" style="margin-top:8px">
                            Configura una lista per ogni paese. Al submit, il sistema legge il TLD della email del contatto
                            e lo manda nella lista corrispondente.<br>
                            <strong>Priorità:</strong> TLD email → Lista default del form → List ID globale (fallback).
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="if2_amelia_apiurl">API URL</label></th>
                    <td>
                        <input type="text" id="if2_amelia_apiurl" name="if2_amelia_apiurl"
                               value="<?php echo esc_attr($amelia_apiurl); ?>"
                               placeholder="https://api.smshosting.it/rest/api" class="regular-text">
                        <p class="description">URL base delle API SMSHosting (senza slash finale).</p>
                    </td>
                </tr>
            </table>
            <button type="button" id="if2-test-amelia">Test connessione Amelia</button>
            <span id="if2-amelia-test-result" style="margin-left:12px;font-size:13px"></span>
            <div style="margin-top:14px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
                <input type="text" id="if2-amelia-test-phone" placeholder="+39XXXXXXXXXX" style="width:180px;padding:5px 8px;border:1px solid #ccc;border-radius:3px;font-size:13px">
                <button type="button" id="if2-test-amelia-contact">Test aggiungi contatto</button>
                <span id="if2-amelia-contact-result" style="font-size:13px;font-family:monospace"></span>
            </div>
            <p class="description" style="margin-top:10px">
                Nel builder, segna un campo <strong>Checkbox</strong> come <em>Amelia Consenso</em> e un campo testo come <em>Amelia Telefono</em>.
                La email viene rilevata automaticamente. Al submit, se il consenso è spuntato, il contatto viene aggiunto alla lista.
            </p>
        </div>

        <!-- SUBMISSIONS IN CODA -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_queue'); ?></h2>
            <?php
            global $wpdb;
            $tbl     = IF2_DB::submissions_table();
            $pending = $wpdb->get_var("SELECT COUNT(*) FROM $tbl WHERE JSON_EXTRACT(meta, '$.queued') = true");
            $failed  = $wpdb->get_var("SELECT COUNT(*) FROM $tbl WHERE JSON_EXTRACT(meta, '$.queued_retries') >= 5");
            ?>
            <table class="widefat">
                <thead><tr><th><?php echo IF2_Lang::t('queue_status'); ?></th><th><?php echo IF2_Lang::t('queue_count'); ?></th><th><?php echo IF2_Lang::t('queue_action'); ?></th></tr></thead>
                <tbody>
                    <tr>
                        <td><?php echo IF2_Lang::t('queue_pending'); ?></td>
                        <td><?php echo (int) $pending; ?></td>
                        <td><button type="button" class="button"><?php echo IF2_Lang::t('queue_retry'); ?></button></td>
                    </tr>
                    <tr>
                        <td><?php echo IF2_Lang::t('queue_failed'); ?></td>
                        <td><?php echo (int) $failed; ?></td>
                        <td><em><?php echo IF2_Lang::t('queue_manual'); ?></em></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <p class="in3pida-save-row">
            <button type="submit" id="in3pida-save-btn">
                <?php echo IF2_Lang::t('save_settings'); ?>
            </button>
        </p>

    </form>
</div><!-- .in3pida-settings-wrap -->
</div><!-- .if2-admin-wrap -->
