<?php
// ISI internal use only — accessed once to reset PHP OPcache after plugin update
if (empty($_GET['s']) || $_GET['s'] !== 'fe5e40b0-4367-48b2-a869-8c66a502e009') { http_response_code(403); exit; }
$ok = function_exists('opcache_reset') ? opcache_reset() : false;
header('Content-Type: application/json');
echo json_encode(['ok' => $ok, 'ts' => time()]);
